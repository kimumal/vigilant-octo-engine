const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data', 'database.json');
const DB_BACKUP = path.join(__dirname, 'data', 'database.backup.json');

const defaultData = {
  keys: [],
  users: [],
  uploads: { hotmail: [], mix: [], ccs: [] },
  settings: {
    adminPassword: '0KCI92JI9XOK920DKXMC299C',
    botToken: '8665268562:AAHPBqX34vef1WnKcrKmvkw2kC8tfoY3z4I',
    groupChatId: '-5159343258',
    adminId: '7490574579',
    contactUsername: '@diepvienmeobeo',
    websiteUrl: 'tretrauont.lol'
  },
  stats: {
    totalUploads: 0
  }
};

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(defaultData, null, 2));
    return JSON.parse(JSON.stringify(defaultData));
  }

  try {
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    const parsed = JSON.parse(raw);

    // Deep merge với default để không thiếu field
    return {
      ...defaultData,
      ...parsed,
      settings: {
        ...defaultData.settings,
        ...(parsed.settings || {})
      },
      uploads: {
        hotmail: Array.isArray((parsed.uploads || {}).hotmail) ? parsed.uploads.hotmail : [],
        mix:     Array.isArray((parsed.uploads || {}).mix)     ? parsed.uploads.mix     : [],
        ccs:     Array.isArray((parsed.uploads || {}).ccs)     ? parsed.uploads.ccs     : []
      },
      stats: {
        ...defaultData.stats,
        ...(parsed.stats || {})
      }
    };
  } catch (err) {
    console.error('❌ DB load error, trying backup:', err.message);

    // Thử load backup
    try {
      if (fs.existsSync(DB_BACKUP)) {
        const raw = fs.readFileSync(DB_BACKUP, 'utf8');
        return JSON.parse(raw);
      }
    } catch {}

    console.error('❌ Backup also failed, using defaults');
    return JSON.parse(JSON.stringify(defaultData));
  }
}

function saveDB(data) {
  try {
    // Backup file cũ trước khi ghi
    if (fs.existsSync(DB_PATH)) {
      fs.copyFileSync(DB_PATH, DB_BACKUP);
    }
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error('❌ DB save error:', err.message);
  }
}

module.exports = { loadDB, saveDB };