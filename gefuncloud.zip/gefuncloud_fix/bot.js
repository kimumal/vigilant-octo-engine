const TelegramBot = require('node-telegram-bot-api');
const { loadDB, saveDB } = require('./database');
const cron = require('node-cron');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');
const { v4: uuidv4 } = require('uuid');

let bot = null;

const STATE_PATH = path.join(__dirname, 'data', 'pending_state.json');

function loadState() {
  try { if (fs.existsSync(STATE_PATH)) return JSON.parse(fs.readFileSync(STATE_PATH, 'utf8')); } catch {}
  return {};
}
function saveState(state) {
  try { fs.mkdirSync(path.dirname(STATE_PATH), { recursive: true }); fs.writeFileSync(STATE_PATH, JSON.stringify(state)); } catch {}
}
function setPending(chatId, value) {
  const state = loadState();
  if (value === null) delete state[chatId]; else state[chatId] = value;
  saveState(state);
}
function getPending(chatId) { return loadState()[chatId] || null; }

function getBot() {
  if (bot) return bot;
  const db = loadDB();
  if (!db.settings.botToken) throw new Error('Bot token not configured!');
  bot = new TelegramBot(db.settings.botToken, { polling: { interval: 300, autoStart: true, params: { timeout: 10 } } });
  bot.on('polling_error', (err) => console.error('Bot polling error:', err.message));
  setupHandlers(bot);
  setupCron(bot);
  console.log('✅ Telegram Bot started');
  return bot;
}

function isAdmin(chatId) { return String(chatId) === String(loadDB().settings.adminId); }
function ensureUploadDirs() {
  ['hotmail', 'mix', 'ccs'].forEach(cat => {
    const dir = path.join(__dirname, 'uploads', cat);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  });
}
const CAT_EMOJI = { hotmail: '📧', mix: '🔀', ccs: '💳' };

function setupHandlers(bot) {
  ensureUploadDirs();

  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const db = loadDB();
    if (!db.users.find(u => u.chatId === chatId)) {
      db.users.push({ chatId, username: msg.from.username || '', joinedAt: Date.now() });
      saveDB(db);
    }
    const adminMenu = isAdmin(chatId)
      ? ``
      : '';
    bot.sendMessage(chatId,
      `👋 Welcome to *GeFunCloud* bot!\n\n🌐 Website: \`tretrauont.lol\`\n\n📋 *Commands:*\n/planx - View pricing\n/help - How to use` + adminMenu,
      { parse_mode: 'Markdown' }
    );
  });

  bot.onText(/\/help/, (msg) => {
    bot.sendMessage(msg.chat.id,
      `📖 *GeFunCloud Guide*\n\n1️⃣ Purchase a key: @diepvienmeobeo\n2️⃣ Login at: \`tretrauont.lol\`\n3️⃣ Download files from Dashboard\n\n❓ Support: @diepvienmeobeo`,
      { parse_mode: 'Markdown' }
    );
  });

  bot.onText(/\/planx/, (msg) => {
    bot.sendMessage(msg.chat.id,
      `💎 *GeFunCloud Pricing*\n\n┌ 💵 \`$10\`  → 7 Days 🔥\n├ 💵 \`$30\`  → 1 Month 🔥\n├ 💵 \`$100\` → 3 Months 🔥\n└ 💵 \`$200\` → 7 Months 🔥\n\n📩 Contact: @diepvienmeobeo\n🌐 Website: \`tretrauont.lol\``,
      { parse_mode: 'Markdown' }
    );
  });

  bot.onText(/\/stats/, (msg) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) return;
    const db = loadDB();
    const now = Date.now();
    const totalLines = [...db.uploads.hotmail, ...db.uploads.mix, ...db.uploads.ccs].reduce((s, u) => s + (u.lines || 0), 0);
    bot.sendMessage(chatId,
      `📊 *GeFunCloud Statistics*\n\n👥 Users: \`${db.users.length}\`\n🔑 Active Keys: \`${db.keys.filter(k => k.active && k.expiresAt > now).length}\`\n❌ Expired Keys: \`${db.keys.filter(k => !k.active || k.expiresAt <= now).length}\`\n\n📁 *Uploads:*\n  📧 Hotmail: \`${db.uploads.hotmail.length}\` files\n  🔀 Mix: \`${db.uploads.mix.length}\` files\n  💳 CCS: \`${db.uploads.ccs.length}\` files\n  📊 Total Lines: \`${totalLines.toLocaleString()}\``,
      { parse_mode: 'Markdown' }
    );
  });

  bot.onText(/\/users/, (msg) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) return;
    const db = loadDB();
    if (!db.users.length) return bot.sendMessage(chatId, '📭 No users yet.');
    const list = db.users.slice(0, 50).map((u, i) => `${i + 1}. @${u.username || 'unknown'} (\`${u.chatId}\`)`).join('\n');
    bot.sendMessage(chatId, `👥 *User List (${db.users.length} total):*\n\n${list}`, { parse_mode: 'Markdown' });
  });

  bot.onText(/\/broadcast (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) return;
    const db = loadDB();
    db.users.forEach(u => bot.sendMessage(u.chatId, `📢 *Announcement from GeFunCloud:*\n\n${match[1]}`, { parse_mode: 'Markdown' }).catch(() => {}));
    setTimeout(() => bot.sendMessage(chatId, `✅ Broadcast sent to ${db.users.length} users`), 1500);
  });

  bot.onText(/\/upload/, (msg) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) return bot.sendMessage(chatId, '❌ No permission.');
    setPending(chatId, null);
    bot.sendMessage(chatId, `📁 *Select upload category:*`, {
      parse_mode: 'Markdown',
      reply_markup: { inline_keyboard: [[
        { text: '📧 Hotmail', callback_data: 'up_hotmail' },
        { text: '🔀 Mix',     callback_data: 'up_mix'     },
        { text: '💳 CCS',     callback_data: 'up_ccs'     }
      ]]}
    });
  });

  bot.on('callback_query', async (query) => {
    const chatId = query.message.chat.id;
    const data = query.data;

    if (data.startsWith('up_')) {
      if (!isAdmin(chatId)) return bot.answerCallbackQuery(query.id, { text: '❌ No permission!' });
      const cat = data.replace('up_', '');
      if (!['hotmail', 'mix', 'ccs'].includes(cat)) return;
      setPending(chatId, { cat, waitingFile: true, timestamp: Date.now() });
      await bot.answerCallbackQuery(query.id);
      await bot.sendMessage(chatId,
        `✅ Category *${cat.toUpperCase()}* ${CAT_EMOJI[cat]} selected\n\n📤 Send your *.txt* file now\n⚠️ Max size: 50GB\n\n💡 _Session valid for 30 minutes_`,
        { parse_mode: 'Markdown' }
      );
      return;
    }

    if (data === 'notify_yes' || data === 'notify_no') {
      if (!isAdmin(chatId)) return bot.answerCallbackQuery(query.id);
      await bot.answerCallbackQuery(query.id);
      if (data === 'notify_yes') {
        const info = loadState()[chatId + '_last'];
        if (info) { notifyAllUsers(bot, info); await bot.sendMessage(chatId, '✅ All users have been notified!'); }
        else await bot.sendMessage(chatId, '⚠️ Upload info not found.');
      } else {
        await bot.sendMessage(chatId, '👍 Notification skipped.');
      }
    }
  });

  bot.on('document', async (msg) => {
    const chatId = msg.chat.id;
    if (!isAdmin(chatId)) return;

    const pending = getPending(chatId);

    if (!pending || !pending.waitingFile) {
      return bot.sendMessage(chatId, `⚠️ No category selected! Choose one:`, {
        reply_markup: { inline_keyboard: [[
          { text: '📧 Hotmail', callback_data: 'up_hotmail' },
          { text: '🔀 Mix',     callback_data: 'up_mix'     },
          { text: '💳 CCS',     callback_data: 'up_ccs'     }
        ]]}
      });
    }

    if (Date.now() - pending.timestamp > 30 * 60 * 1000) {
      setPending(chatId, null);
      return bot.sendMessage(chatId, `⏰ Session expired (30 min). Select again:`, {
        reply_markup: { inline_keyboard: [[
          { text: '📧 Hotmail', callback_data: 'up_hotmail' },
          { text: '🔀 Mix',     callback_data: 'up_mix'     },
          { text: '💳 CCS',     callback_data: 'up_ccs'     }
        ]]}
      });
    }

    const cat = pending.cat;
    const file = msg.document;

    if (!file.file_name.endsWith('.txt')) return bot.sendMessage(chatId, '❌ Only *.txt* files allowed.', { parse_mode: 'Markdown' });
    if (file.file_size && file.file_size > 50 * 1024 * 1024 * 1024) return bot.sendMessage(chatId, '❌ File too large! Max 50GB.');

    const progressMsg = await bot.sendMessage(chatId,
      `⏳ *Processing...*\n\n📁 File: \`${file.file_name}\`\n📂 Category: \`${cat.toUpperCase()}\` ${CAT_EMOJI[cat]}\n🔄 Downloading to server...`,
      { parse_mode: 'Markdown' }
    );

    try {
      const fileLink = await bot.getFileLink(file.file_id);
      ensureUploadDirs();
      const safeName = file.file_name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const destPath = path.join(__dirname, 'uploads', cat, Date.now() + '_' + safeName);
      const fileStream = fs.createWriteStream(destPath);
      const proto = fileLink.startsWith('https') ? https : http;

      proto.get(fileLink, (res) => {
        res.pipe(fileStream);
        fileStream.on('finish', () => {
          fileStream.close();
          let lines = 0;
          try { lines = fs.readFileSync(destPath, 'utf8').split('\n').filter(l => l.trim()).length; } catch {}

          const newUpload = {
            id: uuidv4(), filename: file.file_name, storedName: path.basename(destPath),
            category: cat, lines, size: file.file_size || 0, uploadedAt: Date.now(),
            path: `/uploads/${cat}/${path.basename(destPath)}`
          };

          const db = loadDB();
          db.uploads[cat].unshift(newUpload);
          db.stats.totalUploads++;
          saveDB(db);

          setPending(chatId, null);
          const state = loadState();
          state[chatId + '_last'] = { category: cat, filename: file.file_name, lines, id: newUpload.id };
          saveState(state);

          bot.editMessageText(
            `✅ *Upload successful!*\n\n📁 File: \`${file.file_name}\`\n📂 Category: \`${cat.toUpperCase()}\` ${CAT_EMOJI[cat]}\n📊 Lines: \`${lines.toLocaleString()}\`\n💾 Size: \`${((file.file_size || 0) / 1024).toFixed(1)} KB\`\n\n📢 Notify all users?`,
            {
              chat_id: chatId, message_id: progressMsg.message_id, parse_mode: 'Markdown',
              reply_markup: { inline_keyboard: [[
                { text: '✅ Yes, notify now', callback_data: 'notify_yes' },
                { text: '❌ No',              callback_data: 'notify_no'  }
              ]]}
            }
          ).catch(() => {
            bot.sendMessage(chatId,
              `✅ *Upload successful!*\n📁 \`${file.file_name}\`\n📊 \`${lines.toLocaleString()}\` lines\n\nNotify users?`,
              { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '✅ Yes', callback_data: 'notify_yes' }, { text: '❌ No', callback_data: 'notify_no' }]] } }
            );
          });
        });
      }).on('error', err => {
        fs.unlink(destPath, () => {});
        bot.editMessageText(`❌ Download error: ${err.message}`, { chat_id: chatId, message_id: progressMsg.message_id })
          .catch(() => bot.sendMessage(chatId, `❌ Error: ${err.message}`));
      });
    } catch (err) {
      bot.editMessageText(`❌ Error: ${err.message}`, { chat_id: chatId, message_id: progressMsg.message_id })
        .catch(() => bot.sendMessage(chatId, `❌ Error: ${err.message}`));
    }
  });
}

function notifyAllUsers(bot, info) {
  const db = loadDB();
  const msg =
    `🔥 *NEW DROP TODAY* 🔥\n\n` +
    `${CAT_EMOJI[info.category] || '📦'} Type: \`${info.category.toUpperCase()}\`\n` +
    `📊 Lines: \`${info.lines.toLocaleString()}\`\n\n` +
    `💬 Purchase: @diepvienmeobeo\n🌐 \`tretrauont.lol\``;
  if (db.settings.groupChatId) bot.sendMessage(db.settings.groupChatId, msg, { parse_mode: 'Markdown' }).catch(() => {});
  db.users.forEach(u => bot.sendMessage(u.chatId, msg, { parse_mode: 'Markdown' }).catch(() => {}));
  console.log(`📢 Notified ${db.users.length} users`);
}

function notifyNewKey(keyData) {
  if (!bot) return;
  const db = loadDB();
  const labels = { 7: '7 Days', 30: '1 Month', 90: '3 Months', 210: '7 Months' };
  const msg =
    `🔑 *New Key Generated*\n\n📦 Plan: \`${labels[keyData.days] || keyData.days + ' Days'}\`\n💰 Price: \`$${keyData.price}\`\n🔐 Key: \`${keyData.key}\`\n📅 Expires: \`${new Date(keyData.expiresAt).toLocaleDateString()}\``;
  if (db.settings.groupChatId) bot.sendMessage(db.settings.groupChatId, msg, { parse_mode: 'Markdown' }).catch(() => {});
}

function notifyDropToAll(botInstance, info) { notifyAllUsers(botInstance || bot, info); }

function setupCron(bot) {
  cron.schedule('0 8 * * *', () => {
    const db = loadDB();
    const now = Date.now();
    const expiring = db.keys.filter(k => k.active && k.expiresAt > now && k.expiresAt - now <= 3 * 86400000);
    if (!expiring.length) return;
    const msg = `⚠️ *Keys Expiring Within 3 Days*\n\n` + expiring.map(k => `🔑 \`${k.key}\` — ${Math.ceil((k.expiresAt - now) / 86400000)}d left`).join('\n');
    bot.sendMessage(db.settings.adminId, msg, { parse_mode: 'Markdown' }).catch(() => {});
    if (db.settings.groupChatId) bot.sendMessage(db.settings.groupChatId, msg, { parse_mode: 'Markdown' }).catch(() => {});
  });

  cron.schedule('0 * * * *', () => {
    try {
      const state = loadState();
      const now = Date.now();
      let changed = false;
      Object.keys(state).forEach(k => {
        if (state[k] && state[k].timestamp && now - state[k].timestamp > 30 * 60 * 1000) { delete state[k]; changed = true; }
      });
      if (changed) saveState(state);
    } catch {}
  });
}

module.exports = { getBot, notifyAllUsers, notifyDropToAll, notifyNewKey };