# GeFunCloud v2.0

## Quick Start

```bash
npm install
node main.js
# or with custom port:
PORT=5000 node main.js
```

## Credentials

| Field | Value |
|-------|-------|
| Admin URL | `/adminviplogin` |
| Admin Password | `0KCI92JI9XOK920DKXMC299C` |
| Bot Token | `8665268562:AAHPBqX34vef1WnKcrKmvkw2kC8tfoY3z4I` |
| Group Chat ID | `-5159343258` |
| Admin Telegram ID | `7490574579` |

## Features

- ✅ Admin login — password only (no 2FA)
- ✅ Key generation → auto notifies group chat `-5159343258`
- ✅ Daily cron → notifies expiring keys to group chat
- ✅ File upload (Hotmail / Mix / CCS) with member notifications
- ✅ ULP Search proxy (7 servers)
- ✅ Live dashboard — online users, stats
- ✅ Telegram bot: `/start`, `/planx`, `/upload`

## Pages

| Page | URL | Access |
|------|-----|--------|
| Landing | `/main.html` | Public |
| Key Login | `/keylogin.html` | Public |
| Admin Login | `/adminviplogin` | Public |
| Dashboard | `/dashboard.html` | Key required |
| Hotmail | `/hotmail.html` | Key required |
| Mix | `/mix.html` | Key required |
| CCS | `/ccs.html` | Key required |
| ULP Search | `/ulp-search.html` | Key required |
| Admin Panel | `/admin.html` | Admin only |

## Plans

| Price | Duration |
|-------|----------|
| $10 | 7 Days |
| $30 | 1 Month |
| $100 | 3 Months |
| $200 | 7 Months |
