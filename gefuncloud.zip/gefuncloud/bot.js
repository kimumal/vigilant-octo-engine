const TelegramBot = require('node-telegram-bot-api');
const { loadDB, saveDB } = require('./database');
const cron = require('node-cron');
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

let bot = null;
const pendingUpload = {};

function getBot() {
  if (bot) return bot;
  const db = loadDB();
  bot = new TelegramBot(db.settings.botToken, { polling: true });
  setupHandlers(bot);
  setupCron(bot);
  return bot;
}

function setupHandlers(bot) {
  bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const db = loadDB();
    if (!db.users.find(u => u.chatId === chatId)) {
      db.users.push({ chatId, username: msg.from.username || '', joinedAt: Date.now() });
      saveDB(db);
    }
    bot.sendMessage(chatId,
      `👋 Hello, this is a notification bot from *GeFunCloud*\n\n🌐 Our website: \`tretrauont.lol\`\n\nPress the command /planx for more details`,
      { parse_mode: 'Markdown' }
    );
  });

  bot.onText(/\/planx/, (msg) => {
    bot.sendMessage(msg.chat.id,
      `💎 *GeFunCloud Plans*\n\n` +
      `💵 \`10$\` - 7 DAYS 🔥\n` +
      `💵 \`30$\` - 1 MONTH 🔥\n` +
      `💵 \`100$\` - 3 MONTHS 🔥\n` +
      `💵 \`200$\` - 7 MONTHS 🔥\n\n` +
      `📩 Contact: @diepvienmeobeo`,
      { parse_mode: 'Markdown' }
    );
  });

  bot.onText(/\/upload/, (msg) => {
    const chatId = msg.chat.id;
    const db = loadDB();
    if (String(chatId) !== db.settings.adminId) return bot.sendMessage(chatId, '❌ No permission.');
    bot.sendMessage(chatId, '📁 Select upload category:', {
      reply_markup: {
        inline_keyboard: [[
          { text: '📧 Hotmail', callback_data: 'up_hotmail' },
          { text: '🔀 Mix', callback_data: 'up_mix' },
          { text: '💳 CCS', callback_data: 'up_ccs' }
        ]]
      }
    });
  });

  bot.on('callback_query', (query) => {
    const chatId = query.message.chat.id;
    const db = loadDB();
    if (String(chatId) !== db.settings.adminId) return;

    if (query.data.startsWith('up_')) {
      const cat = query.data.replace('up_', '');
      pendingUpload[chatId] = cat;
      bot.answerCallbackQuery(query.id);
      bot.sendMessage(chatId, `✅ Category *${cat.toUpperCase()}* selected\n\nSend your .txt file (max 50GB)`, { parse_mode: 'Markdown' });
    }

    if (query.data === 'notify_yes') {
      bot.answerCallbackQuery(query.id);
      const info = pendingUpload[chatId + '_last'];
      if (info) { notifyAllUsers(bot, info); bot.sendMessage(chatId, '✅ Notified all users!'); }
    }
    if (query.data === 'notify_no') {
      bot.answerCallbackQuery(query.id);
      bot.sendMessage(chatId, '👍 Skipped notification.');
    }
  });

  bot.on('document', async (msg) => {
    const chatId = msg.chat.id;
    const db = loadDB();
    if (String(chatId) !== db.settings.adminId) return;
    const cat = pendingUpload[chatId];
    if (!cat) return bot.sendMessage(chatId, '⚠️ Use /upload first to select category.');
    const file = msg.document;
    if (!file.file_name.endsWith('.txt')) return bot.sendMessage(chatId, '❌ Only .txt files allowed.');
    if (file.file_size && file.file_size > 50 * 1024 * 1024 * 1024) return bot.sendMessage(chatId, '❌ File too large! Max 50GB.');

    try {
      const fileLink = await bot.getFileLink(file.file_id);
      const destPath = path.join(__dirname, 'uploads', cat, Date.now() + '_' + file.file_name);
      const fileStream = fs.createWriteStream(destPath);
      const proto = fileLink.startsWith('https') ? https : http;
      proto.get(fileLink, (res) => {
        res.pipe(fileStream);
        fileStream.on('finish', () => {
          fileStream.close();
          const content = fs.readFileSync(destPath, 'utf8');
          const lines = content.split('\n').filter(l => l.trim()).length;
          const { v4: uuidv4 } = require('uuid');
          const newUpload = {
            id: uuidv4(), filename: file.file_name,
            storedName: path.basename(destPath),
            category: cat, lines, size: file.file_size || 0,
            uploadedAt: Date.now(),
            path: `/uploads/${cat}/${path.basename(destPath)}`
          };
          const dbNow = loadDB();
          dbNow.uploads[cat].unshift(newUpload);
          dbNow.stats.totalUploads++;
          saveDB(dbNow);
          pendingUpload[chatId] = null;
          pendingUpload[chatId + '_last'] = { category: cat, filename: file.file_name, lines, id: newUpload.id };
          bot.sendMessage(chatId,
            `✅ *Upload successful!*\n\n📁 File: \`${file.file_name}\`\n📊 Lines: \`${lines.toLocaleString()}\`\n📂 Category: \`${cat.toUpperCase()}\`\n\nNotify all users?`,
            { parse_mode: 'Markdown', reply_markup: { inline_keyboard: [[{ text: '✅ Yes', callback_data: 'notify_yes' }, { text: '❌ No', callback_data: 'notify_no' }]] } }
          );
        });
      }).on('error', err => bot.sendMessage(chatId, `❌ Download error: ${err.message}`));
    } catch (err) {
      bot.sendMessage(chatId, `❌ Error: ${err.message}`);
    }
  });
}

function notifyAllUsers(bot, info) {
  const db = loadDB();
  const msg =
    `🔥 *DROP today* 🔥\n\n` +
    `✨ - Item: \`${info.category.toUpperCase()}\`\n` +
    `✨ - Number of Lines: \`${info.lines.toLocaleString()}\`\n` +
    `✨ - Buy by contacting @diepvienmeobeo`;
  bot.sendMessage(db.settings.groupChatId, msg, { parse_mode: 'Markdown' }).catch(() => {});
  db.users.forEach(u => bot.sendMessage(u.chatId, msg, { parse_mode: 'Markdown' }).catch(() => {}));
}

function notifyNewKey(keyData) {
  if (!bot) return;
  const db = loadDB();
  const daysLabel = keyData.days === 7 ? '7 DAYS' : keyData.days === 30 ? '1 MONTH' : keyData.days === 90 ? '3 MONTHS' : keyData.days === 210 ? '7 MONTHS' : `${keyData.days} DAYS`;
  const msg =
    `🔑 *New Key Generated*\n\n` +
    `📦 Plan: \`${daysLabel}\`\n` +
    `💰 Price: \`$${keyData.price}\`\n` +
    `🔐 Key: \`${keyData.key}\`\n` +
    `📅 Expires: \`${new Date(keyData.expiresAt).toLocaleDateString()}\``;
  bot.sendMessage(db.settings.groupChatId, msg, { parse_mode: 'Markdown' }).catch(() => {});
}

function notifyDropToAll(bot, info) { notifyAllUsers(bot, info); }

function setupCron(bot) {
  cron.schedule('0 8 * * *', () => {
    const db = loadDB();
    const now = Date.now();
    const expiring = db.keys.filter(k => k.active && k.expiresAt - now > 0 && k.expiresAt - now <= 3 * 86400000);
    if (expiring.length) {
      const msg = `⚠️ *Keys Expiring Soon (3 days)*\n\n` +
        expiring.map(k => `🔑 \`${k.key}\` — ${Math.ceil((k.expiresAt - now) / 86400000)}d left`).join('\n');
      bot.sendMessage(db.settings.adminId, msg, { parse_mode: 'Markdown' }).catch(() => {});
      bot.sendMessage(db.settings.groupChatId, msg, { parse_mode: 'Markdown' }).catch(() => {});
    }
  });
}

module.exports = { getBot, notifyAllUsers, notifyDropToAll, notifyNewKey };
