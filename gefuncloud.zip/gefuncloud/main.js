const express = require('express');
const session = require('express-session');
const multer = require('multer');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');
const { loadDB, saveDB } = require('./database');
const { getBot, notifyDropToAll, notifyNewKey } = require('./bot');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Rate limiting (brute-force protection) ────────────────────────────────
const loginAttempts = new Map();
function rateLimit(req, res, next) {
  const ip = req.ip || req.connection.remoteAddress;
  const now = Date.now();
  const entry = loginAttempts.get(ip) || { count: 0, resetAt: now + 15 * 60 * 1000 };
  if (now > entry.resetAt) { entry.count = 0; entry.resetAt = now + 15 * 60 * 1000; }
  entry.count++;
  loginAttempts.set(ip, entry);
  if (entry.count > 10) {
    const wait = Math.ceil((entry.resetAt - now) / 1000 / 60);
    return res.status(429).json({ success: false, message: `Too many attempts. Try again in ${wait} minutes.` });
  }
  next();
}

app.use(cors({ origin: false })); // disable CORS for security
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(session({
  secret: process.env.SESSION_SECRET || 'gefuncloud_v2_' + Math.random().toString(36),
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 24 * 60 * 60 * 1000,
    httpOnly: true,   // prevents JS from reading cookie
    sameSite: 'strict' // CSRF protection
  }
}));

// ─── Security headers ────────────────────────────────────────────────────
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

// ─── Static files (NO .html extension needed) ────────────────────────────
app.use(express.static(path.join(__dirname, 'web'), { extensions: ['html'] }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const cat = req.params.category || 'mix';
    const dir = path.join(__dirname, 'uploads', cat);
    fs.mkdirSync(dir, { recursive: true });
    cb(null, dir);
  },
  filename: (req, file, cb) => cb(null, Date.now() + '_' + file.originalname.replace(/[^a-zA-Z0-9._-]/g, '_'))
});
const upload = multer({ storage, limits: { fileSize: 50 * 1024 * 1024 * 1024 } });

const onlineSessions = new Set();

function requireKey(req, res, next) {
  if (req.session.keyValid) return next();
  res.status(401).json({ error: 'Unauthorized' });
}
function requireAdmin(req, res, next) {
  if (req.session.isAdmin) return next();
  res.status(403).json({ error: 'Forbidden' });
}

// ─── Routes ──────────────────────────────────────────────────────────────

// Homepage → no .html
app.get('/', (req, res) => {
  if (req.session.keyValid) return res.redirect('/dashboard');
  res.sendFile(path.join(__dirname, 'web', 'main.html'));
});

// Clean URL routing (removes .html from all routes)
const pages = ['dashboard', 'hotmail', 'mix', 'ccs', 'ulp-search', 'keylogin', 'adminviplogin', 'admin'];
pages.forEach(p => {
  app.get('/' + p, (req, res) => res.sendFile(path.join(__dirname, 'web', p + '.html')));
});

// Redirect old .html links to clean URLs
app.get('*.html', (req, res) => {
  const clean = req.path.replace('.html', '');
  res.redirect(301, clean);
});

// ─── API: Key Login ───────────────────────────────────────────────────────
app.post('/api/login', rateLimit, (req, res) => {
  const { key } = req.body;
  if (!key || typeof key !== 'string' || key.length > 64) {
    return res.json({ success: false, message: 'Invalid key format' });
  }
  const db = loadDB();
  const found = db.keys.find(k => k.key === key.toUpperCase() && k.active);
  if (!found) return res.json({ success: false, message: 'Invalid or expired key' });
  if (found.expiresAt < Date.now()) {
    found.active = false; saveDB(db);
    return res.json({ success: false, message: 'Key has expired' });
  }
  // Clear rate limit on success
  loginAttempts.delete(req.ip);
  req.session.keyValid = true;
  req.session.keyData = { key: found.key, expiresAt: found.expiresAt, days: found.days };
  onlineSessions.add(req.session.id);
  res.json({ success: true, redirect: '/dashboard' });
});

app.post('/api/logout', (req, res) => {
  onlineSessions.delete(req.session.id);
  req.session.destroy();
  res.json({ success: true });
});

// ─── API: Admin Login ─────────────────────────────────────────────────────
app.post('/api/admin/login', rateLimit, (req, res) => {
  const { password } = req.body;
  if (!password || typeof password !== 'string') {
    return res.json({ success: false, message: 'Invalid input' });
  }
  const db = loadDB();
  if (password !== db.settings.adminPassword) {
    return res.json({ success: false, message: 'Wrong password' });
  }
  loginAttempts.delete(req.ip);
  req.session.isAdmin = true;
  req.session.keyValid = true;
  onlineSessions.add(req.session.id);
  res.json({ success: true, redirect: '/admin' });
});

app.get('/api/auth/status', (req, res) => {
  res.json({
    isLoggedIn: !!req.session.keyValid,
    isAdmin: !!req.session.isAdmin,
    keyData: req.session.keyData || null
  });
});

// ─── API: Key Management ──────────────────────────────────────────────────
app.get('/api/admin/keys', requireAdmin, (req, res) => {
  const db = loadDB();
  const now = Date.now();
  res.json(db.keys.map(k => ({
    ...k,
    expired: k.expiresAt < now,
    daysLeft: Math.max(0, Math.ceil((k.expiresAt - now) / 86400000))
  })));
});

app.post('/api/admin/keys/generate', requireAdmin, (req, res) => {
  const { days, count = 1, price } = req.body;
  if (!days || days < 1) return res.json({ success: false, message: 'Invalid days' });
  const db = loadDB();
  const generated = [];
  for (let i = 0; i < Math.min(parseInt(count), 100); i++) {
    const key = uuidv4().replace(/-/g, '').toUpperCase().slice(0, 24);
    const keyObj = {
      id: uuidv4(), key, days: parseInt(days), price: parseFloat(price) || 0,
      createdAt: Date.now(), expiresAt: Date.now() + parseInt(days) * 86400000,
      active: true, usedBy: null
    };
    db.keys.push(keyObj);
    generated.push(keyObj);
    try { notifyNewKey(keyObj); } catch(e) {}
  }
  saveDB(db);
  res.json({ success: true, keys: generated });
});

app.delete('/api/admin/keys/:id', requireAdmin, (req, res) => {
  const db = loadDB();
  db.keys = db.keys.filter(k => k.id !== req.params.id);
  saveDB(db);
  res.json({ success: true });
});

app.put('/api/admin/keys/:id/toggle', requireAdmin, (req, res) => {
  const db = loadDB();
  const k = db.keys.find(k => k.id === req.params.id);
  if (!k) return res.json({ success: false });
  k.active = !k.active; saveDB(db);
  res.json({ success: true, active: k.active });
});

// ─── API: Upload ──────────────────────────────────────────────────────────
app.post('/api/upload/:category', requireAdmin, upload.single('file'), (req, res) => {
  try {
    const { category } = req.params;
    if (!['hotmail', 'mix', 'ccs'].includes(category)) return res.json({ success: false, message: 'Invalid category' });
    const file = req.file;
    if (!file) return res.json({ success: false, message: 'No file provided' });
    const content = fs.readFileSync(file.path, 'utf8');
    const lines = content.split('\n').filter(l => l.trim()).length;
    const db = loadDB();
    const newUpload = {
      id: uuidv4(), filename: file.originalname, storedName: file.filename,
      category, lines, size: file.size, uploadedAt: Date.now(),
      path: `/uploads/${category}/${file.filename}`
    };
    db.uploads[category].unshift(newUpload);
    db.stats.totalUploads++;
    saveDB(db);
    res.json({ success: true, upload: newUpload });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.post('/api/admin/notify/:uploadId', requireAdmin, (req, res) => {
  const db = loadDB();
  let found = null;
  for (const cat of ['hotmail', 'mix', 'ccs']) {
    found = db.uploads[cat].find(u => u.id === req.params.uploadId);
    if (found) break;
  }
  if (!found) return res.json({ success: false, message: 'Upload not found' });
  try {
    const bot = getBot();
    notifyDropToAll(bot, { category: found.category, lines: found.lines, filename: found.filename });
    res.json({ success: true });
  } catch (e) { res.json({ success: false, message: e.message }); }
});

// ─── API: Data ────────────────────────────────────────────────────────────
app.get('/api/files/:category', requireKey, (req, res) => {
  const { category } = req.params;
  if (!['hotmail', 'mix', 'ccs'].includes(category)) return res.json([]);
  const db = loadDB();
  res.json(db.uploads[category] || []);
});

app.get('/api/stats', requireKey, (req, res) => {
  const db = loadDB();
  const now = Date.now();
  res.json({
    onlineCount: onlineSessions.size,
    totalUploads: db.stats.totalUploads,
    uploads: { hotmail: db.uploads.hotmail.length, mix: db.uploads.mix.length, ccs: db.uploads.ccs.length },
    activeKeys: db.keys.filter(k => k.active && k.expiresAt > now).length
  });
});

app.get('/api/admin/stats', requireAdmin, (req, res) => {
  const db = loadDB();
  const now = Date.now();
  res.json({
    totalKeys: db.keys.length,
    activeKeys: db.keys.filter(k => k.active && k.expiresAt > now).length,
    expiredKeys: db.keys.filter(k => !k.active || k.expiresAt <= now).length,
    expiring3Days: db.keys.filter(k => k.active && k.expiresAt > now && k.expiresAt - now <= 3 * 86400000).length,
    totalRevenue: db.keys.reduce((s, k) => s + (k.price || 0), 0),
    dailyRevenue: db.keys.filter(k => k.createdAt > now - 86400000).reduce((s, k) => s + (k.price || 0), 0),
    totalUsers: db.users.length,
    onlineCount: onlineSessions.size,
    totalUploads: db.stats.totalUploads,
    uploads: { hotmail: db.uploads.hotmail.length, mix: db.uploads.mix.length, ccs: db.uploads.ccs.length }
  });
});

// ─── API: ULP Search proxy ────────────────────────────────────────────────
app.get('/api/ulp-search', requireKey, (req, res) => {
  const { keyword, total = 100, server = 1 } = req.query;
  if (!keyword) return res.json({ error: 'Missing keyword' });
  // Sanitize inputs
  const safeKeyword = String(keyword).slice(0, 200);
  const safeTotal = Math.min(Math.max(parseInt(total) || 100, 1), 1000);
  const safeServer = Math.min(Math.max(parseInt(server) || 1, 1), 7);
  const url = `http://205.209.110.82:5119/api/search?keyword=${encodeURIComponent(safeKeyword)}&timeout=10&format=ulp&total=${safeTotal}&mode=regex&username=ducdz122&password=phuvanduc&server=${safeServer}`;
  require('http').get(url, (response) => {
    let data = '';
    response.on('data', c => data += c);
    response.on('end', () => { try { res.json(JSON.parse(data)); } catch { res.send(data); } });
  }).on('error', err => res.json({ error: err.message }));
});

// ─── 404 fallback ─────────────────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).redirect('/');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n██████████████████████████████████████`);
  console.log(`  GEFUNCLOUD v2.0`);
  console.log(`  Running → http://0.0.0.0:${PORT}`);
  console.log(`██████████████████████████████████████\n`);
  try { getBot(); console.log('  BOT → Online ✓\n'); } catch (e) { console.log('  BOT → Error:', e.message); }
});