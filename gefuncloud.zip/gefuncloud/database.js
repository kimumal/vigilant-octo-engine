const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'data', 'database.json');

const defaultData = {
  keys: [],
  users: [],
  uploads: { hotmail: [], mix: [], ccs: [] },
  settings: {
    adminPassword: '0KCI92JI9XOK920DKXMC299C',
    botToken: '8665268562:AAHPBqX34vef1WnKcrKmvkw2kC8tfoY3z4I',
    groupChatId: '-5159343258',
    adminId: '7490574579',
    contactUsername: '@diepvienmeobeo',
    websiteUrl: 'tretrauont.lol'
  },
  stats: { totalUploads: 0 }
};

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, JSON.stringify(defaultData, null, 2));
    return JSON.parse(JSON.stringify(defaultData));
  }
  try {
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    const parsed = JSON.parse(raw);
    return {
      ...defaultData, ...parsed,
      settings: { ...defaultData.settings, ...(parsed.settings || {}) },
      uploads: {
        hotmail: (parsed.uploads || {}).hotmail || [],
        mix: (parsed.uploads || {}).mix || [],
        ccs: (parsed.uploads || {}).ccs || []
      }
    };
  } catch {
    return JSON.parse(JSON.stringify(defaultData));
  }
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = { loadDB, saveDB };
