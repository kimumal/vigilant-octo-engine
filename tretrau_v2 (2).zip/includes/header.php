<?php
if (!defined('DB_HOST')) require_once __DIR__ . '/../config.php';
if (!function_exists('url')) require_once __DIR__ . '/../router.php';
$user = currentUser();
$currentPage = $GLOBALS['page'] ?? ($_GET['page'] ?? 'home');
$csrf = generateCSRF();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="csrf" content="<?= $csrf ?>">
  <meta name="robots" content="noindex, nofollow">
  <title><?= SITE_NAME ?></title>
  <link rel="icon" type="image/jpeg" href="/assets/dragon-icon.jpg">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/variables.css">
  <link rel="stylesheet" href="/assets/css/layout.css">
  <?php if (in_array($currentPage, ['chat','global-chat'])): ?>
  <link rel="stylesheet" href="/assets/css/chat.css">
  <?php endif; ?>
  <script src="/assets/js/lang.js"></script>
  <style>
    @keyframes fadeOut { to { opacity: 0; transform: translateY(-8px); } }
    .user-dropdown { display: none; }
    .user-dropdown.show { display: block; }
  </style>
</head>
<body>

<!-- SITE HEADER -->
<header class="site-header">
  <a href="/dashboard" class="header-logo">
    <div class="logo-mark">
      <img src="/assets/dragon-icon.jpg" alt="TreTrau" style="width:32px;height:32px;border-radius:6px;object-fit:cover;display:block;">
    </div>
    <span class="hide-mobile"><?= SITE_NAME ?></span>
  </a>

  <div class="header-search">
    <span class="search-icon icon-search"></span>
    <input type="text" placeholder="Search products..." id="global-search" data-lang-placeholder="search_placeholder"
      autocomplete="off" oninput="handleSearch(this.value)">
  </div>

  <div class="header-actions">
    <?php if ($user): ?>
      <a href="/post" class="header-icon-btn" data-lang-title="nav_post">
        <span class="icon-plus"></span>
      </a>
      <a href="/chat" class="header-icon-btn <?= in_array($currentPage, ['chat','global-chat']) ? 'active' : '' ?>" data-lang-title="nav_messages" id="header-chat-btn" style="position:relative;">
        <span class="icon-chat"></span>
      </a>
      <div class="user-dropdown-wrap">
        <img src="<?= htmlspecialchars(getAvatarUrl($user['avatar'])) ?>"
             class="header-avatar"
             data-dropdown-trigger="user-menu"
             alt="Avatar">
        <div class="user-dropdown" id="user-menu">
          <div class="dropdown-info">
            <div class="dropdown-username"><?= htmlspecialchars($user['username']) ?></div>
            <div class="dropdown-role"><?= ucfirst($user['role']) ?> account</div>
          </div>
          <a href="/profile/<?= $user['id'] ?>" class="dropdown-item">
            <span class="icon-user"></span> <span data-lang="dropdown_profile">My Profile</span>
          </a>
          <a href="/account" class="dropdown-item">
            <span class="icon-settings"></span> <span data-lang="dropdown_settings">Account Settings</span>
          </a>
          <a href="/chat" class="dropdown-item">
            <span class="icon-chat"></span> <span data-lang="dropdown_messages">Messages &amp; Chat</span>
          </a>
          <div class="dropdown-divider"></div>
          <?php if ($user['role'] === 'admin'): ?>
          <a href="/admin/admin.php" class="dropdown-item" target="_blank">
            <span class="icon-shield"></span> <span data-lang="dropdown_admin">Admin Panel</span>
          </a>
          <div class="dropdown-divider"></div>
          <?php endif; ?>
          <a href="/logout" class="dropdown-item danger">
            <span class="icon-logout"></span> <span data-lang="dropdown_logout">Logout</span>
          </a>
        </div>
      </div>
    <?php else: ?>
      <a href="/login" class="btn btn-ghost btn-sm" data-lang="btn_login">Login</a>
      <a href="/register" class="btn btn-primary btn-sm" data-lang="btn_register">Register</a>
    <?php endif; ?>
  </div>
</header>

<!-- MOBILE SEARCH BAR -->
<div class="mobile-search-bar" id="mobile-search-bar">
  <div class="mobile-search-bar-inner">
    <span class="mobile-search-icon icon-search"></span>
    <input type="text" placeholder="Search products..." id="mobile-search-input" data-lang-placeholder="search_placeholder"
      autocomplete="off" oninput="handleSearch(this.value)">
  </div>
</div>

<!-- TOAST CONTAINER -->
<div class="toast-wrap" id="toast-wrap"></div>

<script>
window.CURRENT_USER_ID = <?= $user ? (int)$user['id'] : 'null' ?>;
</script>

<?php
$sidebarPages = ['home','profile','account','post-product'];
if (in_array($currentPage, $sidebarPages)):
?>
<div class="page-layout-sidebar">
  <aside>
    <nav class="side-nav">
      <span class="side-nav-section" data-lang="nav_explore">Explore</span>
      <a href="/dashboard" class="side-nav-item <?= $currentPage==='home'?'active':'' ?>">
        <span class="icon-home"></span> <span data-lang="nav_home">Home</span>
      </a>
      <?php if ($user): ?>
      <a href="/post" class="side-nav-item <?= $currentPage==='post-product'?'active':'' ?>">
        <span class="icon-plus"></span> <span data-lang="nav_post">Post Item</span>
      </a>
      <span class="side-nav-section" data-lang="nav_personal">Personal</span>
      <a href="/profile/<?= $user['id'] ?>" class="side-nav-item <?= $currentPage==='profile'?'active':'' ?>">
        <span class="icon-user"></span> <span data-lang="nav_profile">Profile</span>
      </a>
      <a href="/account" class="side-nav-item <?= $currentPage==='account'?'active':'' ?>">
        <span class="icon-settings"></span> <span data-lang="nav_account">Account</span>
      </a>
      <span class="side-nav-section" data-lang="nav_community">Community</span>
      <a href="/chat" class="side-nav-item <?= in_array($currentPage, ['chat','global-chat'])?'active':'' ?>">
        <span class="icon-chat"></span> <span data-lang="nav_messages">Messages</span>
      </a>
      <?php endif; ?>
    </nav>
  </aside>
  <main>
<?php else: ?>
<?php if (!in_array($currentPage, ['login','register','chat','global-chat'])): ?>
<div class="page-layout">
<?php endif; ?>
<?php endif; ?>
