<?php
/**
 * fix_avatars.php — Regenerate missing avatars for all users
 * 
 * Chạy: php fix_avatars.php
 * Hoặc truy cập qua browser (chỉ admin): https://domain.com/fix_avatars.php
 * SAU KHI CHẠY XONG → XÓA FILE NÀY!
 */

require_once __DIR__ . '/config.php';

// Nếu chạy qua web → check admin
if (php_sapi_name() !== 'cli') {
    startSession();
    $u = currentUser();
    if (!$u || $u['role'] !== 'admin') {
        http_response_code(403);
        die('Admin only. Hoặc chạy: php fix_avatars.php');
    }
    header('Content-Type: text/plain; charset=utf-8');
}

$db = getDB();

echo "=== FIX AVATARS ===\n\n";

// 1. Tạo thư mục avatars nếu chưa có
$avatarDir = UPLOAD_DIR . 'avatars/';
if (!is_dir($avatarDir)) {
    mkdir($avatarDir, 0755, true);
    echo "[OK] Created avatars directory\n";
}

// 2. Lấy tất cả users
$users = $db->query("SELECT id, username, avatar FROM users ORDER BY id")->fetchAll();
echo "Found " . count($users) . " users\n\n";

$fixed = 0;
$skipped = 0;
$errors = 0;

foreach ($users as $u) {
    $uid = $u['id'];
    $uname = $u['username'];
    $avatar = $u['avatar'];
    
    // Check if avatar exists
    $avatarExists = false;
    if ($avatar) {
        $fullPath = __DIR__ . '/' . ltrim($avatar, '/');
        $avatarExists = file_exists($fullPath) && filesize($fullPath) > 0;
    }
    
    if ($avatarExists) {
        echo "[SKIP] User #{$uid} ({$uname}) — avatar OK: {$avatar}\n";
        $skipped++;
        continue;
    }
    
    // Generate new avatar
    try {
        $colors = ['#e74c3c','#3498db','#2ecc71','#9b59b6','#f39c12','#1abc9c','#e67e22','#e91e63'];
        $bg = $colors[$uid % count($colors)];
        $letter = strtoupper(mb_substr($uname, 0, 1));
        
        // Nếu letter là ký tự đặc biệt → dùng "?"  ... à không, dùng emoji hoặc default
        if (!preg_match('/[A-Z0-9\p{L}]/u', $letter)) {
            $letter = '?';
        }
        
        $svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80">
  <rect width="80" height="80" rx="40" fill="{$bg}"/>
  <text x="40" y="54" font-size="36" font-family="Arial,sans-serif" font-weight="bold"
        fill="white" text-anchor="middle">{$letter}</text>
</svg>
SVG;
        
        $fname = 'avatar_' . $uid . '_' . time() . '.svg';
        $destPath = $avatarDir . $fname;
        
        // Xóa avatar cũ nếu có (file không tồn tại nhưng DB còn path)
        if ($avatar) {
            $oldPath = __DIR__ . '/' . ltrim($avatar, '/');
            if (file_exists($oldPath)) @unlink($oldPath);
        }
        
        file_put_contents($destPath, $svg);
        
        $relPath = 'uploads/avatars/' . $fname;
        $db->prepare("UPDATE users SET avatar=? WHERE id=?")->execute([$relPath, $uid]);
        
        echo "[FIXED] User #{$uid} ({$uname}) — new avatar: {$relPath}\n";
        $fixed++;
        
    } catch (\Throwable $e) {
        echo "[ERROR] User #{$uid} ({$uname}) — " . $e->getMessage() . "\n";
        $errors++;
    }
}

echo "\n=== DONE ===\n";
echo "Fixed: {$fixed}\n";
echo "Skipped (already OK): {$skipped}\n";
echo "Errors: {$errors}\n";
echo "\n⚠️  DELETE THIS FILE: rm fix_avatars.php\n";
