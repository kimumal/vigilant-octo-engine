<?php
require_once 'config.php';
require_once 'router.php';

startSession();
$user = currentUser();

// Resolve route từ clean URL
$route = resolveRoute();
$page  = $route['page'];

// Valid pages
$validPages = ['home','login','register','logout','product','profile','account','chat','global-chat','post-product','404'];
if (!in_array($page, $validPages)) $page = '404';

// Log traffic
logTraffic($page);

// Auto-upgrade accounts
if ($user && $user['role'] === 'new' && isAccountMature($user)) {
    $db = getDB();
    $db->prepare("UPDATE users SET role='user' WHERE id=?")->execute([$user['id']]);
    $user['role'] = 'user';
}

// Auth guard
$authRequired = ['account', 'post-product', 'chat', 'global-chat'];
if (in_array($page, $authRequired) && !$user) {
    header('Location: /login');
    exit;
}

include 'includes/header.php';

switch ($page) {
    case 'home':         include 'pages/home.php'; break;
    case 'login':        include 'pages/login.php'; break;
    case 'register':     include 'pages/register.php'; break;
    case 'logout':
        session_destroy();
        header('Location: /dashboard');
        exit;
    case 'product':      include 'pages/product.php'; break;
    case 'profile':      include 'pages/profile.php'; break;
    case 'account':      include 'pages/account.php'; break;
    case 'chat':
    case 'global-chat':  include 'pages/chat.php'; break;
    case 'post-product': include 'pages/post_product.php'; break;
    default:
        http_response_code(404);
        echo '<div style="text-align:center;padding:4rem;"><h1>404</h1><p>Page not found.</p><a href="/dashboard">&#8592; Back</a></div>';
        break;
}

include 'includes/footer.php';
