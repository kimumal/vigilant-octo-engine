<?php
/**
 * admin/verify_token.php
 * ─────────────────────────────────────────────────────────────
 * Endpoint chuyên dụng cho Python bot (start.py) để verify/deny
 * admin token MÀ KHÔNG qua webhook.php.
 *
 * POST params:
 *   token  = admin token cần xử lý
 *   secret = TELEGRAM_WEBHOOK_SECRET
 *   action = "verify" | "deny"
 */
require_once '../config.php';
header('Content-Type: application/json; charset=utf-8');

// Only POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

// Auth bằng secret
$secret = $_POST['secret'] ?? '';
if ($secret !== TELEGRAM_WEBHOOK_SECRET) {
    http_response_code(403);
    echo json_encode(['ok' => false, 'error' => 'Unauthorized']);
    exit;
}

$token  = preg_replace('/[^a-zA-Z0-9]/', '', $_POST['token'] ?? '');
$action = $_POST['action'] ?? '';

if (!$token || !in_array($action, ['verify', 'deny'])) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'error' => 'Invalid params: token + action required']);
    exit;
}

$db = getDB();

if ($action === 'verify') {
    // Đánh dấu token used=1 — admin sẽ được vào panel
    $stmt = $db->prepare(
        "UPDATE admin_tokens SET used=1 WHERE token=? AND used=0 AND expires_at > NOW()"
    );
    $stmt->execute([$token]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(['ok' => true, 'success' => true, 'action' => 'verified']);
    } else {
        // Token không tìm thấy, đã used, hoặc hết hạn
        echo json_encode(['ok' => false, 'error' => 'Token not found, already used, or expired']);
    }
    exit;
}

if ($action === 'deny') {
    // Xóa token — admin sẽ bị từ chối
    $stmt = $db->prepare("DELETE FROM admin_tokens WHERE token=?");
    $stmt->execute([$token]);

    // Kể cả không có token thì vẫn coi là "thành công" (idempotent)
    echo json_encode(['ok' => true, 'success' => true, 'action' => 'denied', 'rows' => $stmt->rowCount()]);
    exit;
}
