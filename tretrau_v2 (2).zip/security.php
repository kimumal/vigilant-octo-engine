<?php
/**
 * security.php — TreTrau Web Application Firewall (WAF)
 * 
 * Include this FIRST in config.php to block attacks before any code runs.
 * 
 * Features:
 * - Anti SQL Injection (request params + headers)
 * - Anti LFI/RFI/Path Traversal
 * - Anti PHP file read/source disclosure
 * - Anti database dump via web
 * - Anti defacement (file integrity monitoring)
 * - Anti webshell upload detection
 * - Anti brute force (IP-based)
 * - Anti scanner/bot detection
 * - Request sanitization
 */

// Prevent direct access
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === 'security.php') {
    http_response_code(403);
    die('Forbidden');
}

class TreTrauFirewall {
    
    private static bool $initialized = false;
    private static string $logFile;
    private static string $blockFile;
    
    // ============================================================
    // INIT
    // ============================================================
    public static function init(): void {
        if (self::$initialized) return;
        self::$initialized = true;
        
        self::$logFile = __DIR__ . '/logs/security.log';
        self::$blockFile = __DIR__ . '/logs/blocked_ips.json';
        
        // Create log directory
        $logDir = dirname(self::$logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0750, true);
            // Block web access to logs
            file_put_contents($logDir . '/.htaccess', "Order deny,allow\nDeny from all\n");
        }
        
        // Run all checks
        self::checkBlockedIP();
        self::checkRequestMethod();
        self::checkQueryString();
        self::checkPostData();
        self::checkHeaders();
        self::checkURI();
        self::checkUserAgent();
        self::antiPhpRead();
        self::antiDatabaseDump();
        self::rateLimitCheck();
    }
    
    // ============================================================
    // IP BLOCKING
    // ============================================================
    private static function getIP(): string {
        foreach (['HTTP_CF_CONNECTING_IP','HTTP_X_FORWARDED_FOR','HTTP_X_REAL_IP','REMOTE_ADDR'] as $k) {
            if (!empty($_SERVER[$k])) {
                $ip = trim(explode(',', $_SERVER[$k])[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
            }
        }
        return '0.0.0.0';
    }
    
    private static function checkBlockedIP(): void {
        if (!file_exists(self::$blockFile)) return;
        $blocked = json_decode(file_get_contents(self::$blockFile), true) ?: [];
        $ip = self::getIP();
        if (isset($blocked[$ip])) {
            $entry = $blocked[$ip];
            // Auto-unblock after 1 hour
            if (time() - ($entry['time'] ?? 0) > 3600) {
                unset($blocked[$ip]);
                file_put_contents(self::$blockFile, json_encode($blocked));
                return;
            }
            http_response_code(403);
            die('<!DOCTYPE html><html><body><h1>403 Forbidden</h1><p>Your IP has been temporarily blocked due to suspicious activity.</p></body></html>');
        }
    }
    
    private static function blockIP(string $reason): void {
        $ip = self::getIP();
        $blocked = [];
        if (file_exists(self::$blockFile)) {
            $blocked = json_decode(file_get_contents(self::$blockFile), true) ?: [];
        }
        $blocked[$ip] = [
            'time' => time(),
            'reason' => $reason,
            'strikes' => ($blocked[$ip]['strikes'] ?? 0) + 1,
        ];
        file_put_contents(self::$blockFile, json_encode($blocked));
    }
    
    // ============================================================
    // SQL INJECTION DETECTION
    // ============================================================
    private static array $sqlPatterns = [
        '/union\s+(all\s+)?select/i',
        '/select\s+.*\s+from\s+/i',
        '/insert\s+into\s+/i',
        '/drop\s+(table|database|column|index)/i',
        '/update\s+.*\s+set\s+/i',
        '/delete\s+from\s+/i',
        '/alter\s+table/i',
        '/load_file\s*\(/i',
        '/into\s+(out|dump)file/i',
        '/information_schema/i',
        '/mysql\.(user|db|tables_priv)/i',
        '/benchmark\s*\(/i',
        '/sleep\s*\(\s*\d/i',
        '/waitfor\s+delay/i',
        '/group_concat\s*\(/i',
        '/extractvalue\s*\(/i',
        '/updatexml\s*\(/i',
        '/exp\s*\(\s*~\s*\(/i',
        '/0x[0-9a-f]{8,}/i',
        '/char\s*\(\s*\d+/i',
        '/ord\s*\(\s*mid\s*\(/i',
        '/\/\*!?\d*\*\//i',  // MySQL version comments
        '/;\s*(drop|alter|create|truncate|rename)/i',
        '/\'\s*(or|and)\s+[\'\d]/i', // ' or 1=1, ' and '1'='1
        '/"\s*(or|and)\s+["\d]/i',
        '/\bexec\s+(master|xp_)/i',
    ];
    
    private static function hasSQLInjection(string $input): bool {
        // Decode URL encoding layers
        $decoded = urldecode(urldecode($input));
        foreach (self::$sqlPatterns as $pattern) {
            if (preg_match($pattern, $decoded)) return true;
        }
        return false;
    }
    
    // ============================================================
    // LFI/RFI/PATH TRAVERSAL DETECTION
    // ============================================================
    private static array $lfiPatterns = [
        '/\.\.\//i',
        '/\.\.\\\\/i',
        '/\.\.%2f/i',
        '/\.\.%5c/i',
        '/etc\/(passwd|shadow|hosts|group|crontab)/i',
        '/proc\/(self|version|cmdline|environ)/i',
        '/var\/(log|mail|spool)/i',
        '/windows\/(system32|win\.ini)/i',
        '/boot\.ini/i',
        '/(php|file|data|expect|zip|phar|glob|ftp|gopher|input|filter):\/\//i',
        '/php:\/\/filter/i',
        '/convert\.base64/i',
        '/resource=/i',
        '/allow_url_include/i',
    ];
    
    private static function hasLFI(string $input): bool {
        $decoded = urldecode(urldecode($input));
        foreach (self::$lfiPatterns as $pattern) {
            if (preg_match($pattern, $decoded)) return true;
        }
        return false;
    }
    
    // ============================================================
    // XSS DETECTION
    // ============================================================
    private static array $xssPatterns = [
        '/<script[\s>]/i',
        '/javascript\s*:/i',
        '/vbscript\s*:/i',
        '/on(load|error|click|mouseover|submit|focus|blur|change)\s*=/i',
        '/<iframe/i',
        '/<object/i',
        '/<embed/i',
        '/<applet/i',
        '/<meta[\s>]/i',
        '/<link[\s>].*href/i',
        '/expression\s*\(/i',
        '/url\s*\(\s*(javascript|data):/i',
        '/document\.(cookie|domain|write|location)/i',
        '/window\.(location|open|eval)/i',
    ];
    
    private static function hasXSS(string $input): bool {
        $decoded = html_entity_decode(urldecode($input), ENT_QUOTES, 'UTF-8');
        foreach (self::$xssPatterns as $pattern) {
            if (preg_match($pattern, $decoded)) return true;
        }
        return false;
    }
    
    // ============================================================
    // WEBSHELL DETECTION PATTERNS
    // ============================================================
    private static array $shellPatterns = [
        '/eval\s*\(\s*(\$_(GET|POST|REQUEST|COOKIE)|base64_decode|gzinflate|gzuncompress|str_rot13)/i',
        '/assert\s*\(\s*\$_(GET|POST|REQUEST)/i',
        '/system\s*\(\s*\$_(GET|POST|REQUEST)/i',
        '/passthru\s*\(/i',
        '/shell_exec\s*\(/i',
        '/exec\s*\(\s*\$_(GET|POST|REQUEST)/i',
        '/proc_open\s*\(/i',
        '/popen\s*\(/i',
        '/preg_replace\s*\(.*\/e/i',
        '/create_function\s*\(/i',
        '/call_user_func(_array)?\s*\(\s*\$_(GET|POST|REQUEST)/i',
        '/\$\{.*\$_(GET|POST|REQUEST)/i',
        '/\b(c99|r57|b374k|wso|alfa|FilesMan|Mini Shell)\b/i',
    ];
    
    // ============================================================
    // REQUEST CHECKS
    // ============================================================
    private static function checkRequestMethod(): void {
        $allowed = ['GET', 'POST', 'HEAD', 'OPTIONS'];
        if (!in_array($_SERVER['REQUEST_METHOD'] ?? 'GET', $allowed)) {
            self::denyRequest('Blocked HTTP method: ' . ($_SERVER['REQUEST_METHOD'] ?? ''));
        }
    }
    
    private static function checkQueryString(): void {
        $qs = $_SERVER['QUERY_STRING'] ?? '';
        if (empty($qs)) return;
        
        if (self::hasSQLInjection($qs)) {
            self::denyRequest('SQLi in query string', true);
        }
        if (self::hasLFI($qs)) {
            self::denyRequest('LFI/RFI in query string', true);
        }
        if (self::hasXSS($qs)) {
            self::denyRequest('XSS in query string');
        }
        
        // Check individual GET params
        foreach ($_GET as $key => $value) {
            if (is_array($value)) $value = implode(' ', $value);
            if (self::hasSQLInjection($key . ' ' . $value)) {
                self::denyRequest('SQLi in GET param: ' . $key, true);
            }
            if (self::hasLFI($value)) {
                self::denyRequest('LFI in GET param: ' . $key, true);
            }
        }
    }
    
    private static function checkPostData(): void {
        if (empty($_POST)) return;
        
        // Whitelist certain POST fields that might contain code-like content (like descriptions)
        $skipFields = ['description', 'content', 'bio'];
        
        foreach ($_POST as $key => $value) {
            if (in_array($key, $skipFields)) continue;
            if (is_array($value)) $value = implode(' ', $value);
            
            if (self::hasSQLInjection($value)) {
                self::denyRequest('SQLi in POST param: ' . $key, true);
            }
            if (self::hasLFI($value)) {
                self::denyRequest('LFI in POST param: ' . $key, true);
            }
        }
    }
    
    private static function checkHeaders(): void {
        // Check for injection in common headers
        $headersToCheck = [
            'HTTP_REFERER',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_HOST',
        ];
        
        foreach ($headersToCheck as $header) {
            if (empty($_SERVER[$header])) continue;
            $value = $_SERVER[$header];
            if (self::hasSQLInjection($value)) {
                self::denyRequest('SQLi in header: ' . $header, true);
            }
        }
        
        // Block requests with too-long headers (buffer overflow attempts)
        foreach ($_SERVER as $key => $value) {
            if (str_starts_with($key, 'HTTP_') && is_string($value) && strlen($value) > 4096) {
                self::denyRequest('Oversized header: ' . $key);
            }
        }
    }
    
    private static function checkURI(): void {
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        
        // Block null bytes
        if (str_contains($uri, "\0") || str_contains($uri, '%00')) {
            self::denyRequest('Null byte in URI', true);
        }
        
        // Block path traversal in URI
        if (self::hasLFI($uri)) {
            self::denyRequest('Path traversal in URI', true);
        }
        
        // Block access to common sensitive paths
        $blockedPaths = [
            '/wp-admin', '/wp-login', '/wp-content', '/wordpress',
            '/phpmyadmin', '/pma', '/myadmin', '/mysqladmin',
            '/adminer', '/phpinfo', '/info.php', '/test.php',
            '/shell', '/cmd', '/eval', '/backdoor',
            '/etc/passwd', '/proc/', '/var/log',
            '/.git/', '/.svn/', '/.env',
            '/vendor/', '/node_modules/',
            '/debug/', '/trace/',
        ];
        
        $uriLower = strtolower($uri);
        foreach ($blockedPaths as $path) {
            if (str_contains($uriLower, $path)) {
                self::denyRequest('Blocked path probe: ' . $path);
            }
        }
    }
    
    private static function checkUserAgent(): void {
        $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
        if (empty($ua)) return; // Allow empty UA (some legitimate tools)
        
        $blockedAgents = [
            'sqlmap', 'nikto', 'nessus', 'openvas', 'w3af',
            'acunetix', 'netsparker', 'havij', 'appscan',
            'burpsuite', 'dirbuster', 'gobuster', 'wfuzz',
            'ffuf', 'masscan', 'zgrab', 'censys', 'nmap',
            'shodan', 'python-requests/0', 'go-http-client',
            'scrapy', 'nuclei', 'subfinder', 'httpx',
        ];
        
        foreach ($blockedAgents as $agent) {
            if (str_contains($ua, $agent)) {
                self::denyRequest('Blocked scanner: ' . $agent, true);
            }
        }
    }
    
    // ============================================================
    // ANTI PHP FILE READ (config.php, etc.)
    // ============================================================
    private static function antiPhpRead(): void {
        $uri = strtolower(urldecode($_SERVER['REQUEST_URI'] ?? ''));
        $qs = strtolower(urldecode($_SERVER['QUERY_STRING'] ?? ''));
        $combined = $uri . ' ' . $qs . ' ' . implode(' ', array_map('strval', $_GET));
        
        // Detect attempts to read PHP source
        $sourcePatterns = [
            'php://filter',
            'convert.base64',
            'read=',
            'resource=config',
            'resource=backup',
            'resource=api',
            '.php.bak',
            '.php~',
            '.php.old',
            '.php.save',
            '.php.swp',
            '.php.orig',
            'view-source:',
            'phpsource',
            'filesource',
            'file=config',
            'file=backup',
            'path=config',
            'include=',
            'require=',
            'page=../config',
            'page=config',
            'page=backup',
            'page=setup',
        ];
        
        foreach ($sourcePatterns as $pattern) {
            if (str_contains($combined, $pattern)) {
                self::denyRequest('PHP source read attempt: ' . $pattern, true);
            }
        }
    }
    
    // ============================================================
    // ANTI DATABASE DUMP
    // ============================================================
    private static function antiDatabaseDump(): void {
        $combined = strtolower(
            ($_SERVER['QUERY_STRING'] ?? '') . ' ' .
            implode(' ', array_map('strval', $_POST)) . ' ' .
            implode(' ', array_map('strval', $_GET))
        );
        $combined = urldecode(urldecode($combined));
        
        $dumpPatterns = [
            'mysqldump',
            'pg_dump',
            'into outfile',
            'into dumpfile',
            'load_file(',
            'load data infile',
            'select.*into.*file',
            'information_schema.tables',
            'information_schema.columns',
            'information_schema.schemata',
            'table_schema',
            'table_name',
            'column_name',
            'mysql.user',
            'mysql.db',
            'show databases',
            'show tables',
            'show columns',
            'describe ',
            'desc ',
            'explain ',
        ];
        
        foreach ($dumpPatterns as $pattern) {
            if (str_contains($combined, $pattern)) {
                self::denyRequest('Database dump attempt: ' . $pattern, true);
            }
        }
    }
    
    // ============================================================
    // RATE LIMITING (IP-based, file-based)
    // ============================================================
    private static function rateLimitCheck(): void {
        $ip = self::getIP();
        $rateFile = __DIR__ . '/logs/rate_' . md5($ip) . '.json';
        $now = time();
        $window = 10; // 10 seconds
        $maxRequests = 30; // max 30 requests per 10 seconds
        
        $data = ['requests' => [], 'blocked_until' => 0];
        if (file_exists($rateFile)) {
            $data = json_decode(file_get_contents($rateFile), true) ?: $data;
        }
        
        // Check if temporarily blocked
        if ($data['blocked_until'] > $now) {
            http_response_code(429);
            die('<!DOCTYPE html><html><body><h1>429 Too Many Requests</h1><p>Please slow down.</p></body></html>');
        }
        
        // Clean old entries
        $data['requests'] = array_filter($data['requests'], fn($t) => $t > $now - $window);
        $data['requests'][] = $now;
        
        if (count($data['requests']) > $maxRequests) {
            $data['blocked_until'] = $now + 60; // Block for 60 seconds
            self::logAttack('Rate limit exceeded', false);
        }
        
        @file_put_contents($rateFile, json_encode($data));
    }
    
    // ============================================================
    // FILE INTEGRITY MONITORING
    // ============================================================
    public static function checkIntegrity(): array {
        $hashFile = __DIR__ . '/logs/file_hashes.json';
        $criticalFiles = [
            __DIR__ . '/index.php',
            __DIR__ . '/config.php',
            __DIR__ . '/api.php',
            __DIR__ . '/security.php',
            __DIR__ . '/.htaccess',
        ];
        
        $changes = [];
        $currentHashes = [];
        
        foreach ($criticalFiles as $file) {
            if (file_exists($file)) {
                $currentHashes[$file] = hash_file('sha256', $file);
            }
        }
        
        if (file_exists($hashFile)) {
            $storedHashes = json_decode(file_get_contents($hashFile), true) ?: [];
            foreach ($currentHashes as $file => $hash) {
                if (isset($storedHashes[$file]) && $storedHashes[$file] !== $hash) {
                    $changes[] = $file;
                    self::logAttack("INTEGRITY ALERT: File modified: $file", false);
                }
            }
        }
        
        // Update stored hashes
        file_put_contents($hashFile, json_encode($currentHashes));
        
        return $changes;
    }
    
    /**
     * Initialize file hashes (run once after deployment)
     */
    public static function initHashes(): void {
        $hashFile = __DIR__ . '/logs/file_hashes.json';
        $criticalFiles = [
            __DIR__ . '/index.php',
            __DIR__ . '/config.php', 
            __DIR__ . '/api.php',
            __DIR__ . '/security.php',
            __DIR__ . '/.htaccess',
        ];
        
        $hashes = [];
        foreach ($criticalFiles as $file) {
            if (file_exists($file)) {
                $hashes[$file] = hash_file('sha256', $file);
            }
        }
        
        $logDir = dirname($hashFile);
        if (!is_dir($logDir)) mkdir($logDir, 0750, true);
        file_put_contents($hashFile, json_encode($hashes));
    }
    
    // ============================================================
    // SCAN UPLOADS FOR WEBSHELLS
    // ============================================================
    public static function scanFile(string $filepath): bool {
        if (!file_exists($filepath)) return true;
        
        $content = file_get_contents($filepath);
        if ($content === false) return true;
        
        // Check for PHP code in non-PHP files
        if (preg_match('/<\?php|<\?=|<\?[\s\n]|<script\s+language\s*=\s*["\']?php/i', $content)) {
            return false; // Dangerous
        }
        
        // Check for webshell patterns
        foreach (self::$shellPatterns as $pattern) {
            if (preg_match($pattern, $content)) {
                self::logAttack("Webshell detected in file: $filepath", false);
                return false;
            }
        }
        
        return true; // Clean
    }
    
    // ============================================================
    // DENY REQUEST & LOGGING
    // ============================================================
    private static function denyRequest(string $reason, bool $blockIp = false): void {
        self::logAttack($reason, $blockIp);
        
        if ($blockIp) {
            self::blockIP($reason);
        }
        
        http_response_code(403);
        // Generic error — don't reveal what was detected
        die('<!DOCTYPE html><html><head><title>403</title></head><body><h1>403 Forbidden</h1><p>Access denied.</p></body></html>');
    }
    
    private static function logAttack(string $reason, bool $blocked): void {
        $logDir = dirname(self::$logFile);
        if (!is_dir($logDir)) {
            mkdir($logDir, 0750, true);
            file_put_contents($logDir . '/.htaccess', "Order deny,allow\nDeny from all\n");
        }
        
        $entry = sprintf(
            "[%s] IP=%s | %s | URI=%s | UA=%s | %s\n",
            date('Y-m-d H:i:s'),
            self::getIP(),
            $blocked ? 'BLOCKED+BAN' : 'BLOCKED',
            substr($_SERVER['REQUEST_URI'] ?? '', 0, 200),
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 100),
            $reason
        );
        
        @file_put_contents(self::$logFile, $entry, FILE_APPEND | LOCK_EX);
        @error_log("TRETRAU_WAF: " . $reason . " | IP=" . self::getIP());
        
        // Auto-rotate log (max 5MB)
        if (file_exists(self::$logFile) && filesize(self::$logFile) > 5 * 1024 * 1024) {
            @rename(self::$logFile, self::$logFile . '.' . date('Ymd'));
        }
    }
    
    // ============================================================
    // CLEAN UP OLD RATE LIMIT FILES (call periodically)
    // ============================================================
    public static function cleanup(): void {
        $logDir = __DIR__ . '/logs/';
        if (!is_dir($logDir)) return;
        
        foreach (glob($logDir . 'rate_*.json') as $file) {
            if (filemtime($file) < time() - 3600) {
                @unlink($file);
            }
        }
        
        // Clean old blocked IPs (over 24 hours)
        if (file_exists(self::$blockFile)) {
            $blocked = json_decode(file_get_contents(self::$blockFile), true) ?: [];
            $cleaned = array_filter($blocked, fn($entry) => time() - ($entry['time'] ?? 0) < 86400);
            if (count($cleaned) !== count($blocked)) {
                file_put_contents(self::$blockFile, json_encode($cleaned));
            }
        }
    }
}

// ============================================================
// AUTO-INITIALIZE FIREWALL
// ============================================================
TreTrauFirewall::init();

// ============================================================
// ADDITIONAL: Anti-Hotlink & Source Disclosure via HTTP headers
// ============================================================
// Ẩn PHP version, server info
header_remove('X-Powered-By');
header_remove('Server');
header('X-Powered-By: '); // Override
