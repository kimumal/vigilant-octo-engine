<?php
/**
 * Clear PHP OPcache — chạy sau khi upload file mới
 * Truy cập: https://domain.com/clear_cache.php
 * SAU KHI CHẠY → XÓA FILE NÀY!
 */
header('Content-Type: text/plain; charset=utf-8');
echo "=== CLEAR PHP CACHE ===\n\n";

if (function_exists('opcache_reset')) {
    opcache_reset();
    echo "✅ opcache_reset() — ALL cache cleared!\n";
} else {
    echo "⚠️  opcache not available\n";
}

// Also invalidate specific files
$files = [
    __DIR__ . '/pages/product.php',
    __DIR__ . '/pages/home.php',
    __DIR__ . '/pages/chat.php',
    __DIR__ . '/config.php',
    __DIR__ . '/index.php',
    __DIR__ . '/security.php',
];

foreach ($files as $f) {
    if (file_exists($f) && function_exists('opcache_invalidate')) {
        opcache_invalidate($f, true);
        echo "✅ Invalidated: " . basename($f) . "\n";
    }
}

// Verify product.php version
echo "\n--- PRODUCT.PHP CHECK ---\n";
$pf = __DIR__ . '/pages/product.php';
if (file_exists($pf)) {
    $content = file_get_contents($pf);
    
    // Check version marker
    if (preg_match('/PRODUCT_PAGE_VERSION=([^\s]+)/', $content, $m)) {
        echo "Version: " . $m[1] . "\n";
    } else {
        echo "Version: ❌ NO VERSION MARKER — OLD FILE!\n";
    }
    
    // Check for the old bug
    if (str_contains($content, "AND p.status='active'") || str_contains($content, "AND status='active'")) {
        echo "❌ BUG DETECTED: Old status filter still present!\n";
        echo "   You need to upload the NEW product.php from the zip!\n";
    } else {
        echo "✅ No status filter — correct!\n";
    }
    
    // Check JOIN type
    if (str_contains($content, "LEFT JOIN users")) {
        echo "✅ LEFT JOIN — handles orphan products\n";
    } elseif (str_contains($content, "JOIN users")) {
        echo "⚠️  INNER JOIN — orphan products will fail\n";
    }
    
    echo "File modified: " . date('Y-m-d H:i:s', filemtime($pf)) . "\n";
    echo "File size: " . filesize($pf) . " bytes\n";
}

echo "\n=== DONE — DELETE THIS FILE: rm clear_cache.php ===\n";
