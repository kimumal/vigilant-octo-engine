﻿

    'use strict';

    // ── SESSION MANAGER ─────────────────────────────────────────────────────────
    // Session is stored in localStorage (X-API-Key pattern, no cookies needed).
    // On every page load we verify the key with /api/auth/session before rendering.
    // This handles: key expiry, key revocation, server restart, domain change.

    const SESSION_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000; // 30 days local expiry

    function _clearSession(reason) {
      console.info('[session] cleared:', reason);
      localStorage.removeItem('mk');
      localStorage.removeItem('mk_ts');
      localStorage.removeItem('mk_tier');
    }

    function _redirectLogin() {
      // Prevent redirect loop: if already on /login don't redirect again
      if (window.location.pathname === '/login') return;
      location.replace('/login');
    }

    // ── Step 1: Fast local check (before any network call) ──────────────────────
    const K = localStorage.getItem('mk');

    if (!K) {
      _redirectLogin();
      // Halt JS — page will navigate away
      throw Object.assign(new Error('no_session'), { silent: true });
    }

    // Sanity check timestamp — local session max age
    const _ts = parseInt(localStorage.getItem('mk_ts') || '0');
    if (_ts > 0 && (Date.now() - _ts) > SESSION_MAX_AGE_MS) {
      _clearSession('local_expiry');
      _redirectLogin();
      throw Object.assign(new Error('session_expired'), { silent: true });
    }

    // ── Core helpers ─────────────────────────────────────────────────────────────
    const $ = id => document.getElementById(id);
    const esc = s => { const d = document.createElement('div'); d.textContent = s || ''; return d.innerHTML; };
    const tog = id => { const e = $(id); e.style.display = e.style.display === 'none' ? 'block' : 'none'; };
    const cf = () => $('set-cf')?.checked !== false;

    // Always same-origin — works on any domain without configuration
    const API_BASE = window.location.origin;

    // ── API Client ────────────────────────────────────────────────────────────────
    const API = {
      _h() {
        return {
          'X-API-Key': K,
          'Content-Type': 'application/json',
          'Authorization': 'Bearer ' + K,  // fallback for some proxy configs
        };
      },

      _onAuthFail(status, path) {
        // Only redirect on definitive auth failures, not server errors
        if (status === 401 || status === 403) {
          console.warn('[auth] rejected by server on', path, '— status', status);
          _clearSession('server_rejected');
          _redirectLogin();
          return true;
        }
        return false;
      },

      // Safe JSON parse — guards against server returning HTML (e.g. 502, nginx error page)
      async _json(r, label) {
        const ct = r.headers.get('content-type') || '';
        if (!ct.includes('application/json')) {
          const body = await r.text().catch(() => '');
          console.error(`[API] ${label} returned non-JSON (${r.status}): ${body.substring(0, 120)}`);
          throw new Error(`Server error ${r.status} — expected JSON`);
        }
        return r.json();
      },

      async get(u) {
        let r;
        try {
          r = await fetch(API_BASE + u, {
            method: 'GET',
            headers: this._h(),
            credentials: 'same-origin',
          });
        } catch (e) {
          throw new Error('Network error: ' + e.message);
        }
        if (this._onAuthFail(r.status, u)) return null;
        if (!r.ok) {
          let msg = r.status;
          try { msg = (await this._json(r, u)).error || r.status; } catch (_) { }
          throw new Error(String(msg));
        }
        return this._json(r, u);
      },

      async post(u, d) {
        let r;
        try {
          r = await fetch(API_BASE + u, {
            method: 'POST',
            headers: this._h(),
            credentials: 'same-origin',
            body: JSON.stringify(d),
          });
        } catch (e) {
          throw new Error('Network error: ' + e.message);
        }
        if (this._onAuthFail(r.status, u)) return null;
        if (!r.ok) {
          let msg = r.status;
          try { msg = (await this._json(r, u)).error || r.status; } catch (_) { }
          throw new Error(String(msg));
        }
        return this._json(r, u);
      },

      async del(u) {
        let r;
        try {
          r = await fetch(API_BASE + u, {
            method: 'DELETE',
            headers: this._h(),
            credentials: 'same-origin',
          });
        } catch (e) {
          throw new Error('Network error: ' + e.message);
        }
        if (this._onAuthFail(r.status, u)) return null;
        if (!r.ok) throw new Error(r.status);
        return this._json(r, u);
      },
    };

    function toast(msg, type = 'info') { const c = $('toasts'), d = document.createElement('div'); d.className = `toast ${type}`; const ic = { success: '✓', error: '✕', warn: '!', info: '·' }; d.innerHTML = `<span>${ic[type] || '·'}</span><span>${esc(msg)}</span>`; c.appendChild(d); setTimeout(() => { d.style.opacity = '0'; d.style.transition = '.3s'; setTimeout(() => d.remove(), 300); }, 3500); }
    function logout() {
      _clearSession('user_logout');
      location.replace('/login');
    }
    function resetAll() { if (cf() && !confirm('Delete ALL data?')) return; Promise.all([API.del('/api/smtp'), API.del('/api/mail'), API.del('/api/logs')]).then(() => { toast('Reset complete', 'success'); loadDash(); }).catch(() => { }); }

    // NAV
    let curPage = 'dashboard', arIv = null;
    function go(p) {
      curPage = p;
      document.querySelectorAll('.nb').forEach(function(b) { b.classList.toggle('active', b.dataset.p === p); });
      // Hide ALL known page sections by ID (bypasses CSS nesting/specificity issues)
      var PAGE_IDS = ['dashboard','live-stats','logs','smtp','webmail','accounts',
        'smtp-sender','wm-sender','schedule','mail','cleaner','inbox','blacklist',
        'domcheck','warmup','proxy','templates','email-bl','support','pricing','admin','guide'];
      PAGE_IDS.forEach(function(id) {
        var el = document.getElementById('page-' + id);
        if (el) { el.style.display = 'none'; el.classList.remove('active'); }
      });
      document.querySelectorAll('.page').forEach(function(s) {
        s.style.display = 'none'; s.classList.remove('active');
      });
      // Show target page
      var target = document.getElementById('page-' + p);
      if (target) { target.style.display = 'block'; target.classList.add('active'); }

      if (p === 'dashboard') loadDash();
      else if (p === 'smtp') loadSmtp();
      else if (p === 'webmail') loadWM();
      else if (p === 'accounts') loadAccounts();
      else if (p === 'mail') loadMail();
      else if (p === 'schedule') loadScheds();
      else if (p === 'warmup') { loadWarmupSess(); loadWarmupSmtp(); }
      else if (p === 'proxy') loadProxy();
      else if (p === 'blacklist') loadBLCache();
      else if (p === 'admin') loadAdmin();
      else if (p === 'smtp-sender') loadProxyCnt();
      else if (p === 'live-stats') { _lsLabels=[]; _lsSentHistory=[]; _lsFailHistory=[]; setTimeout(function(){ _initLSCharts(); loadLiveStats(); }, 100); if (liveStatsIv) clearInterval(liveStatsIv); liveStatsIv = setInterval(loadLiveStats, 4000); }
      else if (p === 'templates') loadTemplates();
      else if (p === 'email-bl') loadBlacklist();
      else if (p === 'support') { loadTickets(); }
      else if (p === 'pricing') loadPricing();
      else if (p === 'logs') loadLogs();
      else if (p === 'wm-sender') loadWMSenderState();
      if (p !== 'live-stats' && liveStatsIv) { clearInterval(liveStatsIv); liveStatsIv = null; }
    }

    // Set data-p on all nav buttons (they already have text set)
    document.querySelectorAll('.nb').forEach(b => { b.dataset.p = b.dataset.p || b.getAttribute('onclick')?.match(/go\('([^']+)'\)/)?.[1] || ''; });

    function startAR() { if (arIv) clearInterval(arIv); arIv = setInterval(() => { if (curPage === 'dashboard') loadDash(); }, 8000); }
    function togAR() { if ($('set-ar').checked) startAR(); else { if (arIv) clearInterval(arIv); arIv = null; } }

    document.addEventListener('keydown', e => {
      if (e.ctrlKey || e.metaKey) {
        const m = { '1': 'dashboard', '2': 'smtp', '3': 'mail', '4': 'smtp-sender', '5': 'webmail', '6': 'schedule' };
        if (m[e.key]) { e.preventDefault(); go(m[e.key]); }
      }
    });

    // LANG
    const L18N = { en: { dash_sub: 'System overview — auto-refresh every 8s' }, vi: { dash_sub: 'Tổng quan hệ thống — tự động cập nhật mỗi 8s' }, zh: { dash_sub: '系统概览 — 每8秒自动刷新' } };
    let lang = localStorage.getItem('mlang') || 'en';
    function setLang(l) { lang = l; localStorage.setItem('mlang', l);['en', 'vi', 'zh'].forEach(x => { const b = $('lb-' + x); if (b) b.classList.toggle('on', x === l); }); const t = L18N[l] || L18N.en; if ($('dash-sub')) $('dash-sub').textContent = t.dash_sub; }

    // PROFILE
    async function loadProfile() {
      // ── Step 2: Server-side session validation ─────────────────────────────────
      // This is the definitive check. Even if localStorage has a key,
      // the server may have expired or revoked it.
      try {
        const r = await fetch(API_BASE + '/api/auth/session', {
          method: 'GET',
          headers: {
            'X-API-Key': K,
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + K,
          },
          credentials: 'same-origin',
        });

        // 401/403 = definitively invalid — clear and redirect
        if (r.status === 401 || r.status === 403) {
          console.warn('[auth] /api/auth/session returned', r.status);
          _clearSession('server_rejected');
          _redirectLogin();
          return;
        }

        // 5xx or network issue — DON'T logout. Server may be restarting.
        // User keeps their session; next reload will retry.
        if (!r.ok) {
          console.warn('[auth] session check HTTP error:', r.status, '— keeping session');
          _renderProfileFallback();
          return;
        }

        const p = await r.json();

        if (!p.authenticated) {
          _clearSession('not_authenticated');
          _redirectLogin();
          return;
        }

        // ── Valid session — refresh timestamp ─────────────────────────────────────
        localStorage.setItem('mk_ts', Date.now().toString());
        localStorage.setItem('mk_tier', p.is_admin ? 'admin' : (p.tier || 'pro'));

        // ── Render sidebar ─────────────────────────────────────────────────────────
        const kd = p.key_display || K.substring(0, 18) || '—';
        if ($('sb-key')) $('sb-key').textContent = kd;
        if ($('sb-av')) $('sb-av').textContent = (kd[0] || 'U').toUpperCase();

        // Expiry display
        let meta = (p.tier || 'PRO').toUpperCase();
        if (p.days_remaining !== null && p.days_remaining !== undefined) {
          meta = p.days_remaining > 0
            ? p.days_remaining + 'd remaining'
            : 'Expires today';
        } else if (p.expires_at) {
          meta = 'Exp: ' + new Date(p.expires_at).toLocaleDateString();
        }
        if ($('sb-meta')) $('sb-meta').textContent = meta;

        if (p.is_admin && $('nav-admin')) $('nav-admin').style.display = 'block';

      } catch (e) {
        // Pure network error (fetch threw) — server unreachable
        // Keep session alive; don't logout on network flap
        console.warn('[auth] session check network error:', e.message, '— keeping session');
        _renderProfileFallback();
      }
    }

    function _renderProfileFallback() {
      // Show cached info from localStorage while server is unreachable
      const tier = localStorage.getItem('mk_tier') || 'pro';
      if ($('sb-key')) $('sb-key').textContent = K ? K.substring(0, 18) + '...' : '—';
      if ($('sb-av')) $('sb-av').textContent = 'U';
      if ($('sb-meta')) $('sb-meta').textContent = tier.toUpperCase();
    }

    // DASHBOARD
    let chartD = null, chartL = null;
    async function loadDash() {
      try {
        const s = await API.get('/api/stats');
        if (!s) return;
        const smtp = s.smtp || { total: 0, live: 0, die: 0, limited: 0, unchecked: 0 };
        const mail = s.mail || { total: 0 };
        const wm = s.webmail || { total: 0, live: 0 };
        const sent = s.totalSent || 0;
        const failed = s.totalFailed || 0;
        const total = sent + failed;
        const rate = total > 0 ? ((sent / total) * 100).toFixed(1) : null;
        const rateTxt = rate !== null ? rate + '%' : '—';
        const smtpHealthPct = smtp.total > 0 ? Math.round(smtp.live / smtp.total * 100) : 0;

        if ($('b-smtp')) $('b-smtp').textContent = smtp.total;
        if ($('b-mail')) $('b-mail').textContent = mail.total;
        if ($('b-wm')) $('b-wm').textContent = wm.live || 0;

        // Fill upgraded stat cards
        const dc = $('dash-cards');
        if (dc) {
          const cards = dc.querySelectorAll('.sc');
          // Helper: set card value + sub + bar
          function fillCard(card, val, sub, barPct) {
            const sv = card.querySelector('.sv');
            if (sv) { sv.className = 'sv'; sv.textContent = val; }
            const ss = card.querySelector('.ss');
            if (ss) ss.textContent = sub;
            const bf = card.querySelector('.sc-bar-fill');
            if (bf) bf.style.width = Math.min(100, Math.max(0, barPct || 0)) + '%';
          }
          if (cards[0]) fillCard(cards[0], smtp.live || 0,
            (smtp.die || 0) + ' dead · ' + (smtp.limited || 0) + ' limited', smtpHealthPct);
          if (cards[1]) fillCard(cards[1], sent.toLocaleString(),
            sent > 0 ? 'All time total' : 'No campaigns yet',
            Math.min(100, sent / Math.max(1, sent + failed) * 100));
          if (cards[2]) fillCard(cards[2], failed,
            total > 0 ? rateTxt + ' success rate' : '—',
            total > 0 ? failed / total * 100 : 0);
          if (cards[3]) fillCard(cards[3], mail.total.toLocaleString(),
            mail.total > 0 ? mail.total + ' recipients' : 'Import emails first',
            Math.min(100, mail.total / Math.max(1, mail.total) * 100));
          if (cards[4]) fillCard(cards[4], wm.live || 0,
            (wm.total || 0) + ' total accounts',
            wm.total > 0 ? (wm.live || 0) / wm.total * 100 : 0);
          if (cards[5]) fillCard(cards[5], rateTxt,
            total > 0 ? total.toLocaleString() + ' total' : ' No data yet',
            rate !== null ? parseFloat(rate) : 0);
        }

        // Announcements
        if ($('ann-area')) $('ann-area').innerHTML = (s.announcements || []).map(a => `<div style="background:var(--b06);border:1px solid var(--b22);border-radius:10px;padding:12px 16px;margin-bottom:10px;font-size:12px;display:flex;gap:10px;align-items:flex-start"><i data-lucide="megaphone" style="color:var(--bl3);width:20px;height:20px"></i><div><strong style="color:var(--tx)">${esc(a.title)}</strong><span style="color:var(--tx3);margin-left:8px">${esc(a.content || '')}</span></div></div>`).join('');

        // smtp-dist-sub
        const sds = $('smtp-dist-sub');
        if (sds) sds.textContent = smtp.live + 'L · ' + smtp.die + 'D · ' + (smtp.limited || 0) + 'Lim';

        // Charts — only if Chart.js is loaded
        if (typeof Chart !== 'undefined') {
          const dc2 = $('ch-donut')?.getContext('2d');
          if (dc2) {
            if (chartD) chartD.destroy();
            const dd = [smtp.live, smtp.die, smtp.limited || 0, mail.total];
            chartD = new Chart(dc2, { type: 'doughnut', data: { labels: ['Live SMTP', 'Dead SMTP', 'Limited', 'Mail List'], datasets: [{ data: dd.some(v => v > 0) ? dd : [1], backgroundColor: ['#10d981', '#f43f5e', '#f59e0b', '#3b82f6'], borderColor: 'transparent', borderWidth: 0, hoverOffset: 8 }] }, options: { responsive: true, maintainAspectRatio: false, cutout: '72%', plugins: { legend: { position: 'bottom', labels: { color: '#7c8db5', font: { size: 10 }, padding: 14, usePointStyle: true, pointStyleWidth: 8 } } } } });
          }
          const lc = $('ch-line')?.getContext('2d');
          if (lc) {
            if (chartL) chartL.destroy();
            const hrs = Array.from({ length: 24 }, (_, i) => String(i).padStart(2, '0'));
            const sb = {}, fb = {}; hrs.forEach(h => { sb[h] = 0; fb[h] = 0; });
            (s.hourly || []).forEach(r => { if (r.status === 'sent') sb[r.hour] = (sb[r.hour] || 0) + r.c; else fb[r.hour] = (fb[r.hour] || 0) + r.c; });
            chartL = new Chart(lc, {
              type: 'line', data: {
                labels: hrs.map(h => h + ':00'), datasets: [
                  { label: 'Sent', data: hrs.map(h => sb[h]), borderColor: '#10d981', backgroundColor: 'rgba(16,217,129,.07)', tension: .4, fill: true, pointRadius: 0, pointHoverRadius: 4, borderWidth: 2 },
                  { label: 'Failed', data: hrs.map(h => fb[h]), borderColor: '#f43f5e', backgroundColor: 'rgba(244,63,94,.07)', tension: .4, fill: true, pointRadius: 0, pointHoverRadius: 4, borderWidth: 2 }
                ]
              }, options: { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, plugins: { legend: { labels: { color: '#7c8db5', font: { size: 10 }, usePointStyle: true, pointStyleWidth: 8 } } }, scales: { x: { grid: { color: 'rgba(255,255,255,.02)' }, ticks: { color: '#3d506e', font: { size: 9 }, maxTicksLimit: 8 } }, y: { grid: { color: 'rgba(255,255,255,.02)' }, ticks: { color: '#3d506e', font: { size: 9 } }, border: { display: false } } } }
            });
          }
        }

        // System log
        if ($('syslog')) $('syslog').innerHTML = (s.recentLogs || []).length
          ? (s.recentLogs || []).map(l => `<div class="lr"><span class="lt">${(l.created_at || '').replace('T', ' ').substring(5, 16)}</span><span class="ltag ${l.level || 'info'}">${(l.level || 'info').toUpperCase()}</span><span class="lsmtp">[${esc(l.module || 'sys')}]</span><span class="lmsg">${esc(l.message || '')}</span></div>`).join('')
          : '<div class="empty">No logs yet</div>';

        // Domains
        const de = $('doms');
        if (de) {
          const ds = s.domainStats || [];
          if (!ds.length) { de.innerHTML = '<div class="empty">No domain data yet — import emails first</div>'; }
          else {
            const mx = ds[0].count;
            if ($('dom-count')) $('dom-count').textContent = ds.length + ' domains';
            de.innerHTML = ds.map(d => `<div style="display:flex;align-items:center;gap:10px;margin-bottom:7px">
          <span style="font-size:11px;color:var(--tx2);width:130px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:'JetBrains Mono',monospace">${esc(d.domain)}</span>
          <div style="flex:1;height:3px;background:var(--bg4);border-radius:2px;overflow:hidden">
            <div style="width:${(d.count / mx * 100).toFixed(1)}%;height:100%;background:linear-gradient(90deg,#1d4ed8,#3b82f6);border-radius:2px;transition:width .5s"></div>
          </div>
          <span style="font-size:11px;color:var(--tx3);width:36px;text-align:right;font-family:'JetBrains Mono',monospace">${d.count}</span>
        </div>`).join('');
          }
        }
      } catch (e) {
        console.error('[loadDash] error:', e);
        const dc2 = $('dash-cards');
        if (dc2) dc2.innerHTML = `<div style="grid-column:1/-1;background:var(--rd2);border:1px solid var(--rd3);border-radius:10px;padding:18px;color:var(--rd);font-size:12px;display:flex;gap:12px;align-items:flex-start">
      <i data-lucide="triangle-alert" style="width:24px;height:24px;color:var(--rd)"></i>
      <div><strong>Dashboard load failed</strong><br><span style="font-size:11px;color:var(--tx3);margin-top:4px;display:block">${esc(String(e))}</span></div>
    </div>`;
      }
    }
    async function clearLog() { await API.del('/api/logs').catch(() => { }); $('syslog').innerHTML = '<div class="empty">Cleared</div>'; toast('Cleared', 'success'); }

    // SMTP
    let smtpData = [], smtpFilter = 'live';
    async function smtpImport() { const lines = $('smtp-inp').value.trim().split('\n').filter(Boolean); if (!lines.length) return toast('Paste SMTP first', 'error'); const r = await API.post('/api/smtp/import', { lines }).catch(e => { toast(e.message, 'error'); return null; }); if (r) { toast(`${r.imported} imported, ${r.skipped} skipped`, 'success'); $('smtp-inp').value = ''; loadSmtp(); } }
    async function smtpCheck() { const threads = parseInt($('smtp-threads').value) || 5; const use_proxy = $('smtp-use-proxy')?.checked || false; const r = await API.post('/api/smtp/check', { test_email: $('smtp-te').value.trim(), threads, use_proxy }).catch(e => { toast(e.message, 'error'); return null; }); if (!r || !r.total) return toast('No SMTP to validate', 'info'); toast(r.message, 'info'); $('btn-ck-stop').style.display = 'inline-flex'; pollSmtp(); }
    async function smtpCheckStop() { await API.post('/api/smtp/check/stop', {}).catch(() => null); $('btn-ck-stop').style.display = 'none'; toast('Stopped', 'warn'); }
    async function smtpRecheck() { if (cf() && !confirm('Re-check all?')) return; await API.post('/api/smtp/recheck', {}).catch(() => null); smtpCheck(); }
    function pollSmtp() { const bar = $('smtp-prog'); bar.style.display = 'block'; $('btn-ck').disabled = true; const iv = setInterval(async () => { const s = await API.get('/api/smtp/status').catch(() => null); if (!s) return; const t = s.live + s.die + (s.limited || 0) + s.pending + s.unchecked, c = s.live + s.die + (s.limited || 0); bar.querySelector('.fill').style.width = (t > 0 ? c / t * 100 : 0) + '%'; $('smtp-ckst').textContent = `Live: ${s.live} · Dead: ${s.die} · Limited: ${s.limited || 0} · Checking: ${s.pending}`; if (!s.running) { clearInterval(iv); bar.style.display = 'none'; $('btn-ck').disabled = false; $('btn-ck-stop').style.display = 'none'; toast(`Done: ${s.live} live, ${s.die} dead`, 'success'); loadSmtp(); } }, 1500); }
    async function loadSmtp() { const url = '/api/smtp' + (smtpFilter && smtpFilter !== 'all' ? `?status=${smtpFilter}` : ''); const r = await API.get(url).catch(() => []); smtpData = r || []; renderSmtp(smtpData); }
    function renderSmtp(rows) {
      const tb = $('smtp-tb');
      if (!rows || !rows.length) { tb.innerHTML = '<tr><td colspan="10"><div class="empty">No accounts in this filter</div></td></tr>'; return; }
      tb.innerHTML = rows.map((r, i) => {
        const hs = r.health_score ?? 100;
        const hc = hs >= 70 ? 'var(--gn)' : hs >= 40 ? 'var(--yw)' : 'var(--rd)';
        const hasId = r.from_email || r.from_name;
        const statusCls = r.status === 'live' ? 'live' : r.status === 'die' || r.status === 'dead' ? 'dead' : 'lim';
        return `<tr>
      <td style="font-family:'JetBrains Mono',monospace;color:var(--tx4)">${i + 1}</td>
      <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:'JetBrains Mono',monospace;font-size:11px">${esc(r.host)}</td>
      <td style="font-family:'JetBrains Mono',monospace;font-size:11px">${r.port}</td>
      <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px">${esc(r.username)}</td>
      <td><span class="bs ${statusCls}">${(r.status || '?').toUpperCase()}</span></td>
      <td><span class="health-bar"><span class="health-fill" style="width:${hs}%;background:${hc}"></span></span> <span style="font-size:10px;color:${hc};font-family:'JetBrains Mono',monospace">${hs}</span></td>
      <td style="font-size:10px;color:var(--bl)">${esc(r.ssl_info || '—')}</td>
      <td style="font-size:10px;font-family:'JetBrains Mono',monospace">${r.response_time ? Number(r.response_time).toFixed(1) + 's' : '—'}</td>
      <td style="max-width:110px;overflow:hidden;font-size:10px;color:var(--tx3)">${esc(r.error_msg || '')}</td>
      <td style="display:flex;gap:3px">
        <button class="ebtn" onclick="openId(${r.id},'${esc(r.from_name || '')}','${esc(r.from_email || '')}','${esc(r.reply_to || '')}')">ID</button>
        <button class="xbtn" onclick="delSmtp(${r.id})">×</button>
      </td>
    </tr>`;
      }).join('');
    }
    function filterSmtp(q) { renderSmtp(smtpData.filter(r => (r.host + r.username).toLowerCase().includes(q.toLowerCase()))); }
    function smtpTab(b, f) { smtpFilter = f; b.parentElement.querySelectorAll('.tab').forEach(x => x.classList.remove('active')); b.classList.add('active'); loadSmtp(); }
    async function delSmtp(id) { await API.del('/api/smtp/' + id).catch(() => null); loadSmtp(); }
    async function smtpDelDie() { if (cf() && !confirm('Remove all dead SMTP?')) return; const r = await API.del('/api/smtp/die').catch(() => null); if (r) toast(r.deleted + ' removed', 'success'); loadSmtp(); }
    async function smtpClear() { if (cf() && !confirm('Delete ALL SMTP?')) return; await API.del('/api/smtp').catch(() => null); toast('Cleared', 'success'); loadSmtp(); }
    function smtpExport(s) { window.open('/api/smtp/export?status=' + s + '&key=' + K); }
    function openId(id, fn, fe, rt) { $('id-sid').value = id; $('id-fn').value = fn; $('id-fe').value = fe; $('id-rt').value = rt; $('id-modal').style.display = 'flex'; }
    function closeId() { $('id-modal').style.display = 'none'; }
    async function saveId() { try { await API.post('/api/smtp/identity', { id: $('id-sid').value, from_name: $('id-fn').value.trim(), from_email: $('id-fe').value.trim(), reply_to: $('id-rt').value.trim() }); toast('Saved', 'success'); closeId(); loadSmtp(); } catch (e) { toast(e.message, 'error'); } }

    // WEBMAIL
    let wmFilter = 'live';
    async function wmImport() { const r = await API.post('/api/webmail/import', { lines: $('wm-inp').value.trim().split('\n').filter(Boolean) }).catch(e => { toast(e.message, 'error'); return null; }); if (r) { toast(r.imported + ' imported', 'success'); $('wm-inp').value = ''; loadWM(); } }
    async function wmCheck() { const te = $('wm-te').value.trim(); const th = parseInt($('wm-threads')?.value) || 3; const r = await API.post('/api/webmail/check', { test_email: te, threads: th }).catch(e => { toast(e.message, 'error'); return null; }); if (!r || !r.total) return; $('btn-wck').disabled = true; const bar = $('wm-prog'); bar.style.display = 'block'; const iv = setInterval(async () => { const s = await API.get('/api/webmail/status').catch(() => null); if (!s) return; const t = s.live + s.die + s.pending, c = s.live + s.die; bar.querySelector('.fill').style.width = (t > 0 ? c / t * 100 : 0) + '%'; if (!s.running) { clearInterval(iv); bar.style.display = 'none'; $('btn-wck').disabled = false; toast(s.live + ' live', 'success'); loadWM(); } }, 2000); }
    async function wmRecheck() { await API.post('/api/webmail/recheck', {}).catch(() => null); wmCheck(); }
    async function loadWM() { const r = await API.get('/api/webmail' + (wmFilter !== 'all' ? '?status=' + wmFilter : '')).catch(() => []); $('b-wm').textContent = (r || []).filter(x => x.status === 'live').length; renderWM(r || []); }
    function renderWM(rows) { const tb = $('wm-tb'); if (!rows.length) { tb.innerHTML = '<tr><td colspan="8"><div class="empty">No webmail accounts yet</div></td></tr>'; return; } tb.innerHTML = rows.map((r, i) => `<tr><td>${i + 1}</td><td style="max-width:120px;overflow:hidden;text-overflow:ellipsis;font-size:11px">${esc(r.url)}</td><td style="font-size:11px">${esc(r.email)}</td><td><span class="bs ${r.status}">${r.status.toUpperCase()}</span></td><td style="font-size:10px">${esc(r.server_info || '')}</td><td style="font-size:10px;font-family:monospace">${r.response_time ? r.response_time.toFixed(1) + 's' : '—'}</td><td style="font-size:10px;color:var(--tx3)">${esc(r.error_msg || '')}</td><td><button class="xbtn" onclick="delWM(${r.id})">×</button></td></tr>`).join(''); }
    function wmTab(b, f) { wmFilter = f; b.parentElement.querySelectorAll('.tab').forEach(x => x.classList.remove('active')); b.classList.add('active'); loadWM(); }
    async function delWM(id) { await API.del('/api/webmail/' + id).catch(() => null); loadWM(); }
    async function wmDelDie() { const r = await API.del('/api/webmail/die').catch(() => null); if (r) toast(r.deleted + ' removed', 'success'); loadWM(); }
    async function wmClear() { if (cf() && !confirm('Delete all webmail?')) return; await API.del('/api/webmail').catch(() => null); toast('Cleared', 'success'); loadWM(); }

    // ACCOUNT OVERVIEW
    let acctMode = 'smtp';
    function acctTab(b, m) { acctMode = m; b.parentElement.querySelectorAll('.tab').forEach(x => x.classList.remove('active')); b.classList.add('active'); loadAccounts(); }
    async function loadAccounts() {
      const el = $('acct-content');
      if (!el) return;
      try {
        if (acctMode === 'smtp') {
          const r = await API.get('/api/smtp').catch(() => []);
          if (!(r || []).length) { el.innerHTML = '<div class="empty">No SMTP accounts</div>'; return; }
          el.innerHTML = '<div class="tw"><table><thead><tr><th>Email</th><th>Provider</th><th>Status</th><th>Health</th><th>SSL</th><th>Last Checked</th><th>Cooldown</th></tr></thead><tbody>' +
            r.map(s => { const hs = s.health_score ?? 100, hc = hs >= 70 ? 'var(--gn)' : hs >= 40 ? 'var(--yw)' : 'var(--rd)'; return `<tr><td style="font-size:11px">${esc(s.username)}</td><td style="font-size:11px;color:var(--tx3)">${esc(s.host)}</td><td><span class="bs ${s.status}">${s.status.toUpperCase()}</span></td><td><span class="health-bar"><span class="health-fill" style="width:${hs}%;background:${hc}"></span></span> <span style="font-size:10px;color:${hc}">${hs}</span></td><td style="font-size:10px;color:var(--bl)">${esc(s.ssl_info || '—')}</td><td style="font-size:10px;color:var(--tx3)">${s.last_checked ? s.last_checked.substring(5, 16) : '—'}</td><td style="font-size:10px;color:${s.status === 'die' ? 'var(--rd)' : 'var(--gn)'}">${s.status === 'die' ? 'In cooldown' : 'Ready'}</td></tr>`; }).join('') + '</tbody></table></div>';
        } else {
          const r = await API.get('/api/webmail').catch(() => []);
          if (!(r || []).length) { el.innerHTML = '<div class="empty">No webmail accounts</div>'; return; }
          el.innerHTML = '<div class="tw"><table><thead><tr><th>Email</th><th>Provider</th><th>Status</th><th>Server</th><th>Last Checked</th><th>Quota</th></tr></thead><tbody>' +
            r.map(s => `<tr><td style="font-size:11px">${esc(s.email)}</td><td style="font-size:11px;color:var(--tx3)">${esc(s.url.replace(/https?:\/\//, '').split(':')[0])}</td><td><span class="bs ${s.status}">${s.status.toUpperCase()}</span></td><td style="font-size:10px">${esc(s.server_info || '—')}</td><td style="font-size:10px;color:var(--tx3)">${s.last_checked ? s.last_checked.substring(5, 16) : '—'}</td><td style="font-size:10px;color:${s.status === 'live' ? 'var(--gn)' : 'var(--rd)'}">—</td></tr>`).join('') + '</tbody></table></div>';
        }
      } catch (e) { el.innerHTML = `<div class="empty">Error loading accounts: ${esc(String(e))}</div>`; }
    }

    // SMTP SENDER
    let sMode = 'rotate', sMails = [];
    function setSMTPMode(m) { sMode = m;['rotate', 'single', 'o365'].forEach(x => { const e = $('sm-' + x); if (e) e.style.display = m === x ? 'block' : 'none'; }); document.querySelectorAll('#smtp-mode-tabs .tab').forEach((t, i) => t.classList.toggle('active', ['rotate', 'single', 'o365'][i] === m)); }
    function parseAccts(raw) { return (raw || '').trim().split('\n').filter(Boolean).map(l => { const sep = l.includes('|') ? '|' : ':'; const i = l.indexOf(sep); return i < 0 ? null : { user: l.slice(0, i).trim(), pass: l.slice(i + 1).trim() }; }).filter(Boolean); }
    async function loadLiveSMTP() { const l = await API.get('/api/smtp?status=live').catch(() => []); $('r-cnt').textContent = (l || []).length; toast((l || []).length + ' SMTP loaded', 'success'); }
    async function loadMailDB() { const l = await API.get('/api/mail').catch(() => []); sMails = (l || []).map(m => m.email); $('s-cnt').textContent = sMails.length; toast(sMails.length + ' recipients loaded', 'success'); }
    function loadManMail() {
      const raw = $('mail-man-inp').value.trim(); if (!raw) return;
      // Keep full "email|name" format for personalization — filter by valid email in first part
      const lines = raw.split('\n').map(l => l.trim()).filter(l => {
        const email = l.split('|')[0].split(':')[0].trim();
        return email.includes('@');
      });
      sMails = lines; $('s-cnt').textContent = lines.length; toast(lines.length + ' loaded', 'success');
    }
    async function loadProxyCnt() { const r = await API.get('/api/proxy/status').catch(() => null); if (r) { if ($('s-proxy-cnt')) $('s-proxy-cnt').textContent = `(${r.live || 0} live)`; if ($('b-proxy')) $('b-proxy').textContent = r.live || 0; } }

    async function startSender() {
      // Get HTML from editor — prefer multi-template field if filled
      const html_single = $('s-html')?.value?.trim() || '';
      const letters_raw = $('s-letters')?.value?.trim() || '';
      const ms = ($('s-subjects')?.value?.trim() || '').split('\n').filter(Boolean);
      const subj = $('s-subj')?.value?.trim() || '';

      // Parse multi-template: split on === (allowing whitespace around it)
      const ml = letters_raw
        ? letters_raw.split(/^===\s*$/m).map(t => t.trim()).filter(Boolean)
        : [];

      // Subjects list
      const subjects_list = ms.length ? ms : [subj || 'No Subject'];

      // Templates list — multi-template takes priority over single editor
      const letters_list = ml.length > 0
        ? ml
        : html_single
          ? [html_single]
          : ['<p>Hello</p>'];

      if (!subj && !ms.length) return toast('Enter subject line', 'error');
      if (!html_single && !ml.length) return toast('Enter HTML content in the editor', 'error');
      if (!sMails.length) return toast('Load recipients first', 'error');

      let p = {
        mode: sMode,
        subject: subj || subjects_list[0],
        subjects: subjects_list,
        from_name: $('s-fn')?.value?.trim() || '',
        from_email: $('s-fe')?.value?.trim() || '',
        reply_to: $('s-rt')?.value?.trim() || '',
        from_names: $('s-fn-list')?.value?.trim() || '',
        html: letters_list[0],
        letters: letters_list,
        emails: sMails,
        delay_min: parseFloat($('s-dmin')?.value) || 2,
        delay_max: parseFloat($('s-dmax')?.value) || 8,
        mails_per_smtp: parseInt($('s-mper')?.value) || 50,
        campaign: $('s-tag')?.value?.trim() || '',
        threads: Math.min(parseInt($('s-threads')?.value) || 1, 10),
        batch_size: parseInt($('s-batch')?.value) || 0,
        batch_delay: parseFloat($('s-batch-delay')?.value) || 30,
        daily_limit: 0,
        hourly_limit: 0,
        bounce_pause: $('s-bounce-pause')?.checked || false,
        bounce_thresh: parseInt($('s-bounce-thresh')?.value) || 10,
        use_proxy: $('s-proxy')?.checked || false
      };
      if (sMode === 'rotate') { const m = $('r-inp').value.trim(); if (m) { p.smtp_source = 'manual'; p.smtp_manual = m.split('\n').filter(Boolean); } else p.smtp_source = 'live'; }
      else if (sMode === 'single') { p.single_host = $('s1h').value.trim(); p.single_port = $('s1p').value; p.single_user = $('s1u').value.trim(); p.single_pass = $('s1pw').value.trim(); if (!p.single_host || !p.single_user) return toast('Fill SMTP fields', 'error'); }
      else if (sMode === 'o365') { const accts = parseAccts($('o365-inp').value); if (!accts.length) return toast('No Office 365 accounts (MAIL:PASS or MAIL|PASS)', 'error'); p.o365_list = accts.map(a => `${a.user}|${a.pass}`); }
      $('btn-ss').style.display = 'none'; $('btn-sc').style.display = 'inline-flex'; $('s-prog').style.display = 'block'; $('slog').innerHTML = '';
      $('live-stats').style.display = 'block'; $('export-btns').style.display = 'flex';
      const r = await API.post('/api/sender/start', p).catch(e => { toast(e.message, 'error'); doneSend(); return null; });
      if (!r) return; toast(`Campaign started — ${r.total} recipients, ${r.smtp_count} accounts`, 'success');
      const iv = setInterval(async () => {
        const s = await API.get('/api/sender/status').catch(() => null); if (!s) return;
        $('ss-sent').textContent = s.sent; $('ss-fail').textContent = s.failed; $('ss-pend').textContent = s.pending;
        $('ss-rate').textContent = s.total > 0 ? Math.round(s.sent / s.total * 100) + '%' : '0%';
        $('ss-spd').textContent = s.speed || 0; $('ss-smtp').textContent = s.cur_smtp || '—';
        $('s-prog').querySelector('.fill').style.width = s.total > 0 ? (s.sent + s.failed) / s.total * 100 + '%' : '0%';
        if ((s.logs || []).length) $('slog').innerHTML = s.logs.map(l => `<div class="lr"><span class="lt">${l.time}</span><span class="ltag ${l.status}">${(l.status || '').toUpperCase()}</span><span class="lsmtp">${esc(l.smtp || '')}</span><span class="lmsg">${esc(l.to)}${l.error ? ' — ' + esc(l.error) : ''}</span></div>`).join('');
        if (!s.running) { clearInterval(iv); doneSend(); toast(`Complete: ${s.sent} sent, ${s.failed} failed`, s.sent > 0 ? 'success' : 'warn'); }
      }, 2000);
    }
    async function cancelSender() { if (cf() && !confirm('Cancel campaign?')) return; await API.post('/api/sender/cancel', {}).catch(() => null); doneSend(); toast('Campaign cancelled', 'warn'); }
    function doneSend() { $('btn-ss').style.display = 'inline-flex'; $('btn-sc').style.display = 'none'; }
    function saveAsSched() { if (!sMails.length) return toast('Load recipients first', 'error'); go('schedule'); $('sch-emails').value = sMails.join('\n'); $('sch-subj').value = $('s-subj').value; $('sch-html').value = $('s-html').value; toast('Content copied to Schedule — set time and create', 'info'); }

    // WEBMAIL SENDER (uses same sender API in webmail mode)
    let wmsMails = [];
    async function loadLiveWM() { const r = await API.get('/api/webmail?status=live').catch(() => []); $('wms-cnt').textContent = (r || []).length; toast((r || []).length + ' webmail loaded', 'success'); }
    async function loadMailDBwm() { const l = await API.get('/api/mail').catch(() => []); wmsMails = (l || []).map(m => m.email); $('wms-m-cnt').textContent = wmsMails.length; toast(wmsMails.length + ' recipients', 'success'); }
    function loadWMSMail() { const raw = $('wms-mail-inp').value.trim(); if (!raw) return; const e = raw.split('\n').map(l => l.trim().split(':')[0].split('|')[0].trim()).filter(l => l.includes('@')); wmsMails = e; $('wms-m-cnt').textContent = e.length; toast(e.length + ' loaded', 'success'); }
    async function startWMSender() {
      if (!wmsMails.length) return toast('Load recipients first', 'error');
      const subj = $('wms-subj').value.trim(), html = $('wms-html').value.trim();
      if (!subj) return toast('Enter subject', 'error'); if (!html) return toast('Enter HTML content', 'error');
      const wm = $('wms-inp').value.trim();
      let p = { mode: 'webmail', subject: subj, subjects: [subj], from_name: $('wms-fn').value.trim(), reply_to: $('wms-rt').value.trim(), html, letters: [html], emails: wmsMails, delay_min: parseFloat($('wms-dmin').value) || 3, delay_max: parseFloat($('wms-dmax').value) || 8, mails_per_smtp: parseInt($('wms-mper').value) || 30, campaign: $('wms-tag').value.trim(), threads: Math.min(parseInt($('wms-threads').value) || 1, 5) };
      if (wm) { p.webmail_source = 'manual'; p.webmail_manual = wm.split('\n').filter(Boolean); } else p.webmail_source = 'live';
      $('btn-wss').style.display = 'none'; $('btn-wsc').style.display = 'inline-flex'; $('wms-prog').style.display = 'block'; $('wmslog').innerHTML = ''; $('wms-live').style.display = 'block';
      const r = await API.post('/api/sender/start', p).catch(e => { toast(e.message, 'error'); $('btn-wss').style.display = 'inline-flex'; $('btn-wsc').style.display = 'none'; return null; });
      if (!r) return; toast(`Campaign started — ${r.total} recipients`, 'success');
      const iv = setInterval(async () => {
        const s = await API.get('/api/sender/status').catch(() => null); if (!s) return;
        $('wss-sent').textContent = s.sent; $('wss-fail').textContent = s.failed; $('wss-pend').textContent = s.pending;
        $('wss-rate').textContent = s.total > 0 ? Math.round(s.sent / s.total * 100) + '%' : '0%';
        $('wss-spd').textContent = s.speed || 0; $('wss-smtp').textContent = s.cur_smtp || '—';
        $('wms-prog').querySelector('.fill').style.width = s.total > 0 ? (s.sent + s.failed) / s.total * 100 + '%' : '0%';
        if ((s.logs || []).length) $('wmslog').innerHTML = s.logs.map(l => `<div class="lr"><span class="lt">${l.time}</span><span class="ltag ${l.status}">${(l.status || '').toUpperCase()}</span><span class="lsmtp">${esc(l.smtp || '')}</span><span class="lmsg">${esc(l.to)}${l.error ? ' — ' + esc(l.error) : ''}</span></div>`).join('');
        if (!s.running) { clearInterval(iv); $('btn-wss').style.display = 'inline-flex'; $('btn-wsc').style.display = 'none'; toast(`Complete: ${s.sent} sent`, s.sent > 0 ? 'success' : 'warn'); }
      }, 2000);
    }

    // MAIL
    let mailData = [];
    async function mailImport() { const lines = $('mail-inp').value.trim().split('\n').filter(Boolean); const r = await API.post('/api/mail/import', { lines }).catch(e => { toast(e.message, 'error'); return null; }); if (r) { toast(`${r.imported} imported`, 'success'); $('mail-inp').value = ''; loadMail(); } }
    async function loadMail() { const doms = await API.get('/api/mail/domains').catch(() => []); const total = (doms || []).reduce((s, d) => s + d.count, 0); $('mail-count').textContent = `(${total})`; $('mail-doms').innerHTML = (doms || []).slice(0, 15).map(d => `<span style="background:var(--bg3);border:1px solid var(--bd);border-radius:4px;padding:2px 8px;font-size:10px;color:var(--tx2)">${esc(d.domain)}: ${d.count}</span>`).join(''); const rows = await API.get('/api/mail').catch(() => []); mailData = rows || []; renderMail(mailData); }
    function renderMail(rows) { const tb = $('mail-tb'); if (!rows.length) { tb.innerHTML = '<tr><td colspan="5"><div class="empty">No emails yet</div></td></tr>'; return; } tb.innerHTML = rows.slice(0, 500).map((r, i) => `<tr><td>${i + 1}</td><td style="font-size:11px">${esc(r.email)}</td><td style="color:var(--tx3);font-size:11px">${esc(r.domain)}</td><td style="font-size:10px">${(r.created_at || '').substring(5, 16)}</td><td><button class="xbtn" onclick="delMail(${r.id})">×</button></td></tr>`).join('') + (rows.length > 500 ? `<tr><td colspan="5" style="text-align:center;color:var(--tx3);font-size:11px;padding:8px">+${rows.length - 500} more</td></tr>` : ''); }
    function filterMail(q) { renderMail(mailData.filter(r => (r.email + r.domain).toLowerCase().includes(q.toLowerCase()))); }
    async function delMail(id) { await API.del('/api/mail/' + id).catch(() => null); loadMail(); }
    async function mailClear() { if (cf() && !confirm('Delete ALL emails?')) return; await API.del('/api/mail').catch(() => null); toast('Cleared', 'success'); loadMail(); }
    function mailExport() { window.open('/api/mail/export?key=' + K); }
    async function mailClean() { const r = await API.post('/api/mail/clean', {}).catch(e => { toast(e.message, 'error'); return null; }); if (r) toast(`Kept: ${r.clean} — removed ${(r.removed_invalid || 0) + (r.removed_disposable || 0) + (r.removed_duplicate || 0)}`, 'success'); loadMail(); }

    // CLEANER
    let cleanRes = null;
    async function runCleaner() { const raw = $('cl-inp').value.trim(); if (!raw) return toast('Paste emails first', 'error'); const r = await API.post('/api/mail/clean-input', { emails: raw }).catch(e => { toast(e.message, 'error'); return null; }); if (!r) return; cleanRes = r; $('cl-out').innerHTML = `<div class="panel"><div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:14px"><span style="background:var(--gn2);color:var(--gn);border:1px solid var(--gn3);padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700">${r.stats.clean} Clean</span><span style="background:var(--rd2);color:var(--rd);border:1px solid var(--rd3);padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700">${r.stats.invalid} Invalid</span><span style="background:var(--yw2);color:var(--yw);border:1px solid var(--yw3);padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700">${r.stats.disposable} Disposable</span><span style="background:var(--bg3);color:var(--tx3);border:1px solid var(--bd);padding:4px 12px;border-radius:20px;font-size:11px;font-weight:700">${r.stats.duplicate} Duplicate</span></div><div class="fg"><label>Clean Results (${r.clean_count} emails)</label><textarea style="min-height:140px;font-family:monospace;font-size:11px" readonly>${(r.clean || []).join('\n')}</textarea></div></div>`; toast(`${r.clean_count} clean emails ready`, 'success'); }
    function exportClean() { if (!cleanRes?.clean?.length) return toast('Run cleaner first', 'error'); const a = document.createElement('a'); a.href = 'data:text/plain,' + encodeURIComponent(cleanRes.clean.join('\n')); a.download = 'clean_' + Date.now() + '.txt'; a.click(); }

    // SCHEDULE
    async function createSched() { const name = $('sch-name').value.trim(), runAt = $('sch-run').value, subj = $('sch-subj').value.trim(), html = $('sch-html').value.trim(), er = $('sch-emails').value.trim(); if (!name || !runAt || !subj || !html) return toast('Fill all fields', 'error'); if (!er) return toast('No recipients', 'error'); const emails = er.split('\n').map(l => l.trim()).filter(l => l.includes('@')); const cfg = { subjects: [subj], letters: [html], emails, from_name: '', from_email: '', mode: 'rotate', delay_min: 3, delay_max: 8, mails_per_smtp: 10, campaign: $('sch-tag').value.trim() }; await API.post('/api/schedules/create', { name, run_at: runAt.replace('T', ' ') + ':00', repeat: $('sch-rep').value, config: cfg }).catch(e => { toast(e.message, 'error'); return null; }); toast('Schedule created', 'success'); loadScheds(); }
    function loadSchFromDB() { API.get('/api/mail').then(l => { $('sch-emails').value = (l || []).map(m => m.email).join('\n'); toast((l || []).length + ' recipients loaded', 'success'); }).catch(() => { }); }
    async function loadScheds() { const rows = await API.get('/api/schedules').catch(() => []); const el = $('sched-list'); if (!(rows || []).length) { el.innerHTML = '<div class="empty">No schedules yet</div>'; return; } el.innerHTML = '<div class="panel">' + rows.map(r => { const cfg = JSON.parse(r.config || '{}'); return `<div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--bd)"><span class="bs ${r.status}">${r.status.toUpperCase()}</span><div style="flex:1"><div style="font-size:13px;font-weight:600">${esc(r.name)}</div><div style="font-size:11px;color:var(--tx3)">${r.run_at} · ${r.repeat} · ${(cfg.emails || []).length} recipients</div></div><button class="btn rd sm" onclick="cancelSch(${r.id})">Cancel</button><button class="xbtn" onclick="delSch(${r.id})">×</button></div>`; }).join('') + '</div>'; }
    async function cancelSch(id) { await API.post('/api/schedules/cancel', { id }).catch(() => null); toast('Cancelled', 'warn'); loadScheds(); }
    async function delSch(id) { await API.post('/api/schedules/delete', { id }).catch(() => null); toast('Deleted', 'success'); loadScheds(); }

    // INBOX
    async function inboxCheck() { const raw = $('inbox-inp').value.trim(); if (!raw) return toast('Enter accounts', 'error'); const lines = raw.split('\n').filter(Boolean); const bar = $('inbox-prog'); bar.style.display = 'block'; $('btn-inbox').disabled = true; $('inbox-res').innerHTML = ''; let inC = 0, spC = 0, nfC = 0, erC = 0; for (let i = 0; i < lines.length; i++) { const p = lines[i].split('|'); if (p.length < 2) continue; bar.querySelector('.fill').style.width = ((i + 1) / lines.length * 100) + '%'; try { const r = await API.post('/api/inbox/check', { email: p[0].trim(), password: p[1].trim(), subject: $('inbox-subj').value.trim(), from: $('inbox-from').value.trim() }); if (r.status === 'inbox') inC++; else if (r.status === 'spam') spC++; else if (r.status === 'not_found') nfC++; else erC++; $('inbox-res').innerHTML += `<div style="background:var(--b06);border:1px solid var(--b22);border-radius:8px;padding:10px 14px;margin-bottom:6px;display:flex;align-items:center;justify-content:space-between"><span style="font-size:13px">${esc(p[0].trim())}</span><div style="display:flex;align-items:center;gap:8px"><span style="font-size:11px;color:var(--tx3)">${r.inbox_count || 0} inbox · ${r.spam_count || 0} spam${r.error ? ' · ' + esc(r.error) : ''}</span><span class="bs ${r.status || 'dead'}">${(r.status || 'error').toUpperCase()}</span></div></div>`; } catch (e) { erC++; $('inbox-res').innerHTML += `<div style="background:var(--rd2);border:1px solid var(--rd3);border-radius:8px;padding:10px;margin-bottom:6px;font-size:12px;color:var(--rd)">${esc(p[0].trim())} — ${esc(e.message)}</div>`; } $('ib-in').textContent = inC; $('ib-sp').textContent = spC; $('ib-nf').textContent = nfC; $('ib-er').textContent = erC; } bar.style.display = 'none'; $('btn-inbox').disabled = false; toast(`Done: ${inC} inbox, ${spC} spam`, 'success'); }

    // BLACKLIST
    async function checkBL() { const raw = $('bl-inp').value.trim(); if (!raw) return toast('Enter hosts/IPs', 'error'); $('bl-prog').style.display = 'block'; const r = await API.post('/api/blacklist/check', { hosts: raw.split('\n').map(l => l.trim()).filter(Boolean) }).catch(e => { toast(e.message, 'error'); return null; }); $('bl-prog').style.display = 'none'; if (!r) return; renderBL(r.results); toast(`Checked ${r.results.length} hosts`, 'success'); }
    function renderBL(results) { const el = $('bl-res'); if (!results?.length) { el.innerHTML = ''; return; } el.innerHTML = '<div class="panel">' + results.map(r => `<div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--bd)"><div style="width:8px;height:8px;border-radius:50%;background:${r.listed ? 'var(--rd)' : 'var(--gn)'};flex-shrink:0"></div><div style="flex:1"><div style="font-size:13px;font-weight:500">${esc(r.host)} ${r.ip ? `<span style="color:var(--tx3);font-size:11px">(${r.ip})</span>` : ''}</div><div style="font-size:11px;color:${r.listed ? 'var(--rd)' : 'var(--tx3)'}">${r.listed ? 'Listed on: ' + (r.listed_on || []).join(', ') : r.details || 'Clean'}</div></div><span style="padding:4px 12px;border-radius:20px;font-size:10px;font-weight:700;background:${r.listed ? 'var(--rd2)' : 'var(--gn2)'};color:${r.listed ? 'var(--rd)' : 'var(--gn)'};border:1px solid ${r.listed ? 'var(--rd3)' : 'var(--gn3)'}">${r.listed ? ((r.listed_on || []).length + ' LISTED') : 'CLEAN'}</span></div>`).join('') + '</div>'; }
    async function loadSMTPHosts() { const s = await API.get('/api/smtp?status=live').catch(() => []); const h = [...new Set((s || []).map(x => x.host))]; $('bl-inp').value = h.join('\n'); toast(h.length + ' hosts loaded', 'success'); }
    async function loadBLCache() { const r = await API.get('/api/blacklist/cache').catch(() => []); renderBL((r || []).map(x => ({ ...x, listed: x.listed === 1, listed_on: (() => { try { return JSON.parse(x.details || '{}').listed_on || []; } catch { return []; } })() }))); }

    // DOMAIN
    async function checkDomains() { const raw = $('dom-inp').value.trim(); if (!raw) return toast('Enter domains', 'error'); $('dom-prog').style.display = 'block'; const r = await API.post('/api/domain/check', { domains: raw.split('\n').map(l => l.trim()).filter(Boolean) }).catch(e => { toast(e.message, 'error'); return null; }); $('dom-prog').style.display = 'none'; if (!r) return; renderDomains(r.results); toast(`Checked ${r.results.length} domains`, 'success'); }
    async function loadMailDoms() { const d = await API.get('/api/mail/domains').catch(() => []); $('dom-inp').value = (d || []).map(x => x.domain).join('\n'); toast((d || []).length + ' domains loaded', 'success'); }
    async function loadDomCache() { const r = await API.get('/api/domain/cache').catch(() => []); if (r) renderDomains(r.map(x => ({ ...x, details: (() => { try { return JSON.parse(x.details || '[]'); } catch { return []; } })() }))); }
    function renderDomains(results) { const el = $('dom-res'); if (!results?.length) { el.innerHTML = ''; return; } el.innerHTML = '<div class="panel">' + results.map(r => { const sc = r.phishing_score || 0, sc_c = sc >= 60 ? 'var(--rd)' : sc >= 30 ? 'var(--yw)' : 'var(--gn)', risk = sc >= 60 ? 'HIGH' : sc >= 30 ? 'MEDIUM' : 'LOW'; return `<div style="padding:12px 0;border-bottom:1px solid var(--bd)"><div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;flex-wrap:wrap;gap:6px"><div style="font-size:13px;font-weight:600">${esc(r.domain)}</div><div style="display:flex;gap:6px;flex-wrap:wrap"><span style="background:${r.blacklisted ? 'var(--rd2)' : 'var(--gn2)'};color:${r.blacklisted ? 'var(--rd)' : 'var(--gn)'};border:1px solid ${r.blacklisted ? 'var(--rd3)' : 'var(--gn3)'};padding:3px 10px;border-radius:20px;font-size:9px;font-weight:800">${r.blacklisted ? 'BLACKLISTED' : 'CLEAN'}</span><span style="background:var(--bg3);color:${sc_c};border:1px solid ${sc_c}40;padding:3px 10px;border-radius:20px;font-size:9px;font-weight:800">PHISHING: ${sc}/100 ${risk}</span><span style="background:${r.mx_ok ? 'var(--gn2)' : 'var(--rd2)'};color:${r.mx_ok ? 'var(--gn)' : 'var(--rd)'};border:1px solid ${r.mx_ok ? 'var(--gn3)' : 'var(--rd3)'};padding:3px 10px;border-radius:20px;font-size:9px;font-weight:800">DNS: ${r.mx_ok ? 'OK' : 'FAIL'}</span></div></div><div style="display:flex;flex-wrap:wrap;gap:4px">${(r.details || []).map(d => `<span style="font-size:10px;background:var(--bg3);border:1px solid var(--bd);border-radius:4px;padding:2px 8px;color:var(--tx3)">${esc(d)}</span>`).join('')}</div></div>`; }).join('') + '</div>'; }

    // WARMUP
    async function loadWarmupSmtp() { const s = await API.get('/api/smtp?status=live').catch(() => []); const sel = $('wu-smtp'); sel.innerHTML = '<option value="">— Select account —</option>' + (s || []).map(x => `<option value="${x.id}">${esc(x.username)} (${esc(x.host)})</option>`).join(''); }
    async function startWarmup() { const id = $('wu-smtp').value, raw = $('wu-emails').value.trim(); if (!id) return toast('Select SMTP account', 'error'); if (!raw) return toast('Enter test inboxes', 'error'); const emails = raw.split('\n').map(l => l.trim()).filter(l => l.includes('@')); const r = await API.post('/api/warmup/start', { smtp_id: parseInt(id), test_emails: emails }).catch(e => { toast(e.message, 'error'); return null; }); if (r) { toast(r.message, 'success'); loadWarmupSess(); } }
    async function loadWarmupSess() { const rows = await API.get('/api/warmup').catch(() => []); const el = $('wu-list'); if (!(rows || []).length) { el.innerHTML = '<div class="empty">No warm-up sessions yet</div>'; return; } el.innerHTML = '<div class="panel">' + rows.map(r => { const pct = Math.min(100, Math.round((r.day - 1) / 14 * 100)); return `<div style="padding:10px 0;border-bottom:1px solid var(--bd)"><div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px"><div style="font-size:13px;font-weight:600">${esc(r.username || '')} <span style="color:var(--tx3);font-size:11px">(${esc(r.host || '')})</span></div><span style="font-size:12px;color:var(--pk2)">Day ${r.day}/14 — ${r.target_today}/day</span></div><div style="height:3px;background:var(--bg4);border-radius:2px;overflow:hidden;margin-bottom:6px"><div style="width:${pct}%;height:100%;background:var(--gd);border-radius:2px"></div></div><div style="display:flex;justify-content:space-between;font-size:11px;color:var(--tx3)"><span>Last run: ${(r.last_run || 'Never').substring(5, 16)}</span><button class="btn rd sm" onclick="resetWarmup(${r.smtp_id})">Reset</button></div></div>`; }).join('') + '</div>'; }
    async function resetWarmup(sid) { if (cf() && !confirm('Reset warm-up?')) return; await API.post('/api/warmup/reset', { smtp_id: sid }).catch(() => null); toast('Reset', 'success'); loadWarmupSess(); }
    (function initWuGrid() { const g = $('wu-grid'); if (!g) return;[5, 10, 20, 30, 50, 75, 100, 150, 200, 300, 400, 500, 750, 1000].forEach((n, i) => { const d = document.createElement('div'); d.style.cssText = 'background:var(--bg3);border:1px solid var(--bd);border-radius:5px;padding:5px 9px;font-size:10px;color:var(--tx3);text-align:center;min-width:46px'; d.innerHTML = `<div style="font-size:13px;font-weight:800;background:var(--gd);-webkit-background-clip:text;-webkit-text-fill-color:transparent">${n}</div>Day${i + 1}`; g.appendChild(d); }); }())

    // PRICING
    const USDT = '0x1c64960c4125eb231e179b72f6231e16ea4dfac3';
    function copyUSDT() { navigator.clipboard.writeText(USDT).then(() => { toast('USDT address copied', 'success'); const b = $('usdt-btn'); if (b) { b.textContent = 'Copied'; setTimeout(() => b.textContent = 'Copy', 2200); } }).catch(() => { }); }

    async function loadPricing() {
      const grid = $('pricing-grid'); if (!grid) return;
      try {
        const plans = await API.get('/api/plans');
        if (!plans || !plans.length) { grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:30px;color:var(--tx4)">No plans available</div>'; return; }
        const popular = ['pro','business','premium'];
        grid.innerHTML = plans.map((p, i) => {
          const isPopular = popular.includes(p.plan_key);
          const vnd = p.price_vnd ? Number(p.price_vnd).toLocaleString('vi-VN') + '₫' : '';
          const accentColors = ['var(--gn)','var(--bl)','var(--pk2)','#fb923c','var(--gn)','var(--bl)','var(--pk2)','#fb923c','var(--gn)','var(--bl)'];
          const borderColors = ['var(--b22)','rgba(56,189,248,.25)','var(--pk4)','rgba(251,146,60,.25)','var(--b22)','rgba(56,189,248,.25)','var(--pk4)','rgba(251,146,60,.25)','var(--pk4)','rgba(56,189,248,.25)'];
          const ac = accentColors[i % accentColors.length];
          const bc = isPopular ? 'var(--pk4)' : borderColors[i % borderColors.length];
          return `<div style="background:var(--bg2);border:1px solid ${bc};border-radius:12px;padding:22px;position:relative">
            ${isPopular ? '<div style="position:absolute;top:-1px;right:14px;background:var(--gd);color:#fff;font-size:8px;font-weight:800;padding:3px 10px;border-radius:0 0 6px 6px;letter-spacing:1.5px">POPULAR</div>' : ''}
            <div style="font-size:9px;color:${ac};font-weight:800;letter-spacing:2.5px;margin-bottom:10px;text-transform:uppercase">${esc(p.name)}</div>
            <div style="font-size:30px;font-weight:900;letter-spacing:-2px;line-height:1">${esc(p.price)}</div>
            ${vnd ? `<div style="font-size:13px;font-weight:700;color:var(--gn);margin-top:3px">${vnd}</div>` : ''}
            <div style="font-size:12px;color:var(--tx4);margin-bottom:14px;margin-top:4px">${esc(p.dur)}</div>
            <div style="font-size:12px;color:var(--tx2);line-height:2;margin-bottom:16px">${esc(p.description || '')}</div>
            <button class="btn pk sm" style="width:100%;justify-content:center" onclick="copyUSDT()">Get Access</button>
          </div>`;
        }).join('');
      } catch(e) { grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:30px;color:var(--tx4)">Failed to load plans</div>'; }
    }

    // GUIDE TABS
    function guideTab(l) { ['en', 'vi', 'zh'].forEach(x => { const el = $('guide-' + x); if (el) el.style.display = x === l ? 'block' : 'none'; }); document.querySelectorAll('#guide-tabs .tab').forEach((t, i) => t.classList.toggle('active', ['en', 'vi', 'zh'][i] === l)); }

    // ADMIN
    function openQuotaModal() { $('quota-modal').style.display = 'flex'; $('qm-key').value = ''; $('qm-result').style.display = 'none'; }
    function openExtendModal() { $('extend-modal').style.display = 'flex'; $('em-key').value = ''; $('em-result').style.display = 'none'; }
    function closeModal(id) { $(id).style.display = 'none'; }

    async function addQuota() {
      const key = $('qm-key').value.trim();
      const add = parseInt($('qm-amount').value);
      if (!key) return toast('Enter license key', 'error');
      const r = await API.post('/adminlogin/api/keys/quota', { key, add_mails: add }).catch(e => { toast(e.message, 'error'); return null; });
      if (r) {
        const res = $('qm-result');
        res.style.display = 'block'; res.style.color = 'var(--gn)';
        res.textContent = `Added ${add.toLocaleString()} emails. New quota: ${(r.new_quota || 0).toLocaleString()}`;
        toast('Quota added successfully', 'success');
        loadAdminKeys();
      }
    }

    async function extendKey() {
      const key = $('em-key').value.trim();
      const days = parseInt($('em-days').value);
      if (!key) return toast('Enter license key', 'error');
      const r = await API.post('/adminlogin/api/keys/extend', { key, days }).catch(e => { toast(e.message, 'error'); return null; });
      if (r) {
        const res = $('em-result');
        res.style.display = 'block'; res.style.color = 'var(--gn)';
        res.textContent = `Extended. New expiry: ${r.new_expires || '?'}`;
        toast('Key extended', 'success');
        loadAdminKeys();
      }
    }

    async function loadAdmin() { loadAdminDash(); loadAdminKeys(); loadAdminAnns(); loadAdminLogs(); }
    async function loadAdminDash() { const d = await API.get('/adminlogin/api/dashboard').catch(() => null); if (!d) return; $('a-cards').innerHTML = `<div class="sc pk"><div class="sv">${d.smtp_live}</div><div class="sl">SMTP Live</div></div><div class="sc gn"><div class="sv">${d.smtp_count}</div><div class="sl">SMTP Total</div></div><div class="sc bl"><div class="sv">${d.mail_count}</div><div class="sl">Emails</div></div><div class="sc yw"><div class="sv">${d.total_keys}</div><div class="sl">Keys Total</div></div><div class="sc pk"><div class="sv">${d.active_keys}</div><div class="sl">Active Keys</div></div><div class="sc gn"><div class="sv">${d.total_sent || 0}</div><div class="sl">Total Sent</div></div>`; $('nav-admin').style.display = 'block'; }
    async function genKey() { const r = await API.post('/adminlogin/api/keys/create', { duration: $('a-dur').value, is_admin: $('a-type').value === 'admin', tier: $('a-tier').value, max_smtp: parseInt($('a-ms').value) || 999999, max_emails: 999999 }).catch(e => { toast(e.message, 'error'); return null; }); if (!r) return; const el = $('a-key-res'); el.style.display = 'block'; el.innerHTML = `<strong>Key: </strong><code>${esc(r.key)}</code> <button class="btn pk sm" onclick="navigator.clipboard.writeText('${esc(r.key)}').then(()=>toast('Copied','success'))">Copy</button>${r.expires_at ? `<br><small style="color:var(--tx3)">Expires: ${new Date(r.expires_at).toLocaleDateString()}</small>` : ''}`; toast('Key generated', 'success'); loadAdminKeys(); }
    async function loadAdminKeys() { const keys = await API.get('/adminlogin/api/keys').catch(() => []); const tb = $('a-keys-tb'), now = new Date(); if (!(keys || []).length) { tb.innerHTML = '<tr><td colspan="6"><div class="empty">No keys</div></td></tr>'; return; } tb.innerHTML = keys.map(k => { const exp = k.expires_at && new Date(k.expires_at) < now; return `<tr><td style="max-width:200px;overflow:hidden;font-family:monospace;font-size:11px;color:var(--pk2)">${esc((k.key_display || '').substring(0, 22))}</td><td>${k.tier || 'pro'}</td><td>${k.is_admin ? 'Admin' : 'User'}${exp ? ' <span style="color:var(--rd)">EXP</span>' : ''}</td><td style="font-size:11px">${k.expires_at ? new Date(k.expires_at).toLocaleDateString() : 'Never'}</td><td style="font-size:11px;color:var(--tx3)">${(k.created_at || '').substring(0, 10)}</td><td>${k.is_admin ? '' : '<button class="btn rd sm" onclick="banKey(\'' + esc(k.key_display || '') + '\')">Ban</button>'}</td></tr>`; }).join(''); }
    async function banKey(k) { if (!confirm('Ban this key?')) return; await API.post('/adminlogin/api/keys/ban', { key: k }).catch(e => toast(e.message, 'error')); toast('Banned', 'success'); loadAdminKeys(); }
    async function postAnn() { const title = $('ann-tit').value.trim(); if (!title) return toast('Enter title', 'error'); await API.post('/adminlogin/api/announce', { title, content: $('ann-con').value.trim(), type: $('ann-typ').value }).catch(() => null); toast('Posted', 'success'); $('ann-tit').value = ''; $('ann-con').value = ''; loadAdminAnns(); }
    async function loadAdminAnns() { const rows = await API.get('/adminlogin/api/announcements').catch(() => []); const el = $('ann-list'); if (!(rows || []).length) { el.innerHTML = '<div class="empty">No announcements</div>'; return; } el.innerHTML = rows.map(a => `<div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid var(--bd);font-size:12px"><div style="flex:1"><strong>${esc(a.title)}</strong> <span style="color:var(--tx3)">${esc(a.content || '')}</span></div><span style="font-size:10px;color:var(--tx3)">${(a.created_at || '').substring(5, 16)}</span><button class="xbtn" onclick="delAnn(${a.id})">×</button></div>`).join(''); }
    async function delAnn(id) { await API.post('/adminlogin/api/announce/delete', { id }).catch(() => null); loadAdminAnns(); }
    async function loadAdminLogs() { const logs = await API.get('/adminlogin/api/logs').catch(() => []); const el = $('a-logs'); el.innerHTML = (logs || []).length ? (logs || []).map(l => `<div class="lr"><span class="lt">${(l.created_at || '').replace('T', ' ').substring(5, 16)}</span><span class="ltag ${l.level}">${(l.level || 'info').toUpperCase()}</span><span class="lsmtp">[${esc(l.module || 'sys')}]</span><span class="lmsg">${esc(l.message || '')}</span></div>`).join('') : '<div class="empty">No logs</div>'; }

    // PROXY
    let proxyData = [], proxyFilter = 'live';

    async function proxyImport() {
      const lines = $('proxy-inp').value.trim().split('\n').filter(Boolean);
      if (!lines.length) return toast('Paste proxies first', 'error');
      const r = await API.post('/api/proxy/import', { lines }).catch(e => { toast(e.message, 'error'); return null; });
      if (r) { toast(`${r.imported} imported, ${r.skipped} skipped`, 'success'); $('proxy-inp').value = ''; loadProxy(); }
    }

    async function proxyCheck() {
      const r = await API.post('/api/proxy/check', {}).catch(e => { toast(e.message, 'error'); return null; });
      if (!r || !r.total) return toast('No proxies to check', 'info');
      toast(r.message, 'info');
      $('btn-pck').disabled = true;
      const bar = $('proxy-prog'); bar.style.display = 'block';
      const iv = setInterval(async () => {
        const s = await API.get('/api/proxy/status').catch(() => null); if (!s) return;
        const t = s.live + s.die + s.pending + s.unchecked, c = s.live + s.die;
        bar.querySelector('.fill').style.width = (t > 0 ? c / t * 100 : 0) + '%';
        $('proxy-ckst').textContent = `Live: ${s.live} · Dead: ${s.die} · Checking: ${s.pending}`;
        $('pxy-live').textContent = s.live;
        $('pxy-dead').textContent = s.die;
        $('pxy-pend').textContent = s.pending;
        if (!s.running) {
          clearInterval(iv); bar.style.display = 'none'; $('btn-pck').disabled = false;
          toast(`Done: ${s.live} live, ${s.die} dead`, 'success');
          loadProxy();
        }
      }, 1500);
    }

    async function loadProxy() {
      const url = '/api/proxy' + (proxyFilter && proxyFilter !== 'all' ? `?status=${proxyFilter}` : '');
      const r = await API.get(url).catch(() => []);
      proxyData = r || [];
      renderProxy(proxyData);
      // Update badges
      const s = await API.get('/api/proxy/status').catch(() => null);
      if (s) {
        $('b-proxy').textContent = s.live || 0;
        $('pxy-live').textContent = s.live || 0;
        $('pxy-dead').textContent = s.die || 0;
        $('pxy-pend').textContent = s.pending || 0;
        $('pxy-total').textContent = (s.live || 0) + (s.die || 0) + (s.pending || 0) + (s.unchecked || 0);
      }
    }

    function renderProxy(rows) {
      const tb = $('proxy-tb');
      if (!rows.length) { tb.innerHTML = '<tr><td colspan="10"><div class="empty">No proxies in this filter</div></td></tr>'; return; }
      tb.innerHTML = rows.map((r, i) => {
        const hasAuth = r.username && r.username.trim();
        const lat = r.latency ? r.latency + 'ms' : '—';
        const bl = r.blacklisted === 1
          ? '<span style="color:var(--rd);font-size:10px;font-weight:700">LISTED</span>'
          : '<span style="color:var(--gn);font-size:10px;font-weight:700">CLEAN</span>';
        return `<tr>
      <td>${i + 1}</td>
      <td style="font-family:monospace;font-size:11px">${esc(r.ip)}</td>
      <td style="font-family:monospace">${r.port}</td>
      <td style="font-size:10px;color:${hasAuth ? 'var(--gn)' : 'var(--tx4)'}">${hasAuth ? esc(r.username) : 'None'}</td>
      <td><span class="bs ${r.status}">${r.status.toUpperCase()}</span></td>
      <td style="font-family:monospace;font-size:11px;color:${r.latency < 500 ? 'var(--gn)' : r.latency < 1500 ? 'var(--yw)' : 'var(--rd)'}">${lat}</td>
      <td style="font-size:11px">${esc(r.country || '—')}</td>
      <td>${bl}</td>
      <td style="font-size:10px;color:var(--tx3)">${r.last_checked ? r.last_checked.substring(5, 16) : '—'}</td>
      <td><button class="xbtn" onclick="delProxy(${r.id})">×</button></td>
    </tr>`;
      }).join('');
    }

    function filterProxy(q) { renderProxy(proxyData.filter(r => (r.ip + ':' + r.port).includes(q.toLowerCase()))); }
    function proxyTab(b, f) { proxyFilter = f; b.parentElement.querySelectorAll('.tab').forEach(x => x.classList.remove('active')); b.classList.add('active'); loadProxy(); }
    async function delProxy(id) { await API.del('/api/proxy/' + id).catch(() => null); loadProxy(); }
    async function proxyDelDie() { if (cf() && !confirm('Remove all dead proxies?')) return; const r = await API.del('/api/proxy/die').catch(() => null); if (r) toast(r.deleted + ' removed', 'success'); loadProxy(); }
    async function proxyClear() { if (cf() && !confirm('Delete ALL proxies?')) return; await API.del('/api/proxy').catch(() => null); toast('Cleared', 'success'); loadProxy(); }
    function proxyExport() { window.open('/api/proxy/export?key=' + K); }

    // ── HTML EDITOR ──────────────────────────────────────────────────────────────
    let _htmlEditorDebounce = null;

    function switchHTMLTab(tab) {
      const editor = $('html-editor-pane');
      const preview = $('html-preview-pane');
      const source = $('html-source-pane');
      const tEd = $('tab-editor');
      const tPv = $('tab-preview');
      const tSrc = $('tab-source');

      [editor, preview, source].forEach(p => { if (p) p.style.display = 'none'; });
      [tEd, tPv, tSrc].forEach(t => { if (t) t.classList.remove('active'); });

      if (tab === 'editor') {
        if (editor) editor.style.display = 'block';
        if (tEd) tEd.classList.add('active');
      } else if (tab === 'preview') {
        if (preview) preview.style.display = 'block';
        if (tPv) tPv.classList.add('active');
        renderHTMLPreview();
      } else if (tab === 'source') {
        if (source) source.style.display = 'block';
        if (tSrc) tSrc.classList.add('active');
        const srcEl = $('s-html-src');
        const html = $('s-html')?.value || '';
        if (srcEl) srcEl.value = html;
      }
    }

    function renderHTMLPreview() {
      const html = $('s-html')?.value || '';
      const frame = $('html-preview-frame');
      if (!frame) return;
      // Use srcdoc for safe sandboxed rendering — no XSS risk
      // Add basic email-client-style CSS reset
      const doc = `<!DOCTYPE html><html><head><meta charset="utf-8">
<style>
  body { font-family: Arial, Helvetica, sans-serif; font-size: 14px; line-height: 1.6;
         color: #222; background: #fff; margin: 0; padding: 16px; }
  * { box-sizing: border-box; }
  img { max-width: 100%; }
  a { color: #2563eb; }
</style></head><body>${html}<script src="https://unpkg.com/lucide@latest"><\/script>
  <script>if (typeof lucide !== "undefined") lucide.createIcons();<\/script>
<\/body>

<\/html>`;
      frame.srcdoc = doc;
    }

    function htmlEditorChanged() {
      // Update template count for multi-template field
      const letters = $('s-letters');
      if (letters) {
        const count = letters.value.trim()
          ? letters.value.split('===').filter(t => t.trim()).length
          : 0;
        const cnt = $('tmpl-count');
        if (cnt) cnt.textContent = count + ' template' + (count !== 1 ? 's' : '') + ' in multi-template field';
      }
    }

    function wmHtmlChanged() {
      // nothing needed — preview renders on tab switch
    }

    function switchWMTab(tab) {
      const ed = $('wm-ed-pane');
      const pv = $('wm-pv-pane');
      const tEd = $('wm-tab-ed');
      const tPv = $('wm-tab-pv');
      if (tab === 'editor') {
        if (ed) ed.style.display = 'block';
        if (pv) pv.style.display = 'none';
        if (tEd) tEd.classList.add('active');
        if (tPv) tPv.classList.remove('active');
      } else {
        if (ed) ed.style.display = 'none';
        if (pv) pv.style.display = 'block';
        if (tEd) tEd.classList.remove('active');
        if (tPv) tPv.classList.add('active');
        // Render webmail preview
        const html = $('wms-html')?.value || '';
        const frame = $('wm-preview-frame');
        if (frame) {
          frame.srcdoc = `
<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <style>
    body {
      font-family: Arial, sans-serif;
      font-size: 14px;
      line-height: 1.6;
      color: #222;
      background: #fff;
      margin: 0;
      padding: 16px
    }

    * {
      box-sizing: border-box
    }

    img {
      max-width: 100%
    }

    a {
      color: #2563eb
    }
  </style>
</head>

<body>${html}
  <script src="https://unpkg.com/lucide@latest"><\/script>
  <script>if (typeof lucide !== "undefined") lucide.createIcons();<\/script>
<\/body>

<\/html>`;
        }
      }
    }

    function insertSnippet(snippet) {
      const ta = $('s-html');
      if (!ta) return;
      const start = ta.selectionStart;
      const end = ta.selectionEnd;
      const val = ta.value;
      ta.value = val.slice(0, start) + snippet + val.slice(end);
      ta.selectionStart = ta.selectionEnd = start + snippet.length;
      ta.focus();
    }

    function clearHTMLEditor() {
      const ta = $('s-html');
      if (ta) { ta.value = ''; ta.focus(); }
      const frame = $('html-preview-frame');
      if (frame) frame.srcdoc = '';
    }

    // Update template count when s-letters changes
    document.addEventListener('DOMContentLoaded', () => {
      const lt = $('s-letters');
      if (lt) lt.addEventListener('input', () => {
        const count = lt.value.trim()
          ? lt.value.split('===').filter(t => t.trim()).length
          : 0;
        const cnt = $('tmpl-count');
        if (cnt) cnt.textContent = count + ' template' + (count !== 1 ? 's' : '') + ' in multi-template field';
      });
    });

    // INIT
    setLang(lang);
    setSMTPMode('rotate');
    loadProfile();
    go('dashboard');   // ← activates the dashboard section (shows content)
    startAR();
    loadProxyCnt();

    // ── TOPBAR UPDATE ─────────────────────────────────────────────────────────────
    async function updateTopBar() {
      try {
        const s = await API.get('/api/stats').catch(() => null);
        if (s) {
          const smtp2 = s.smtp || { live: 0 };
          const tb_smtp = $('tb-smtp-live');
          const tb_sent = $('tb-sent');
          const tb_fail = $('tb-failed');
          if (tb_smtp) tb_smtp.textContent = smtp2.live ?? '—';
          if (tb_sent) tb_sent.textContent = (s.totalSent || 0).toLocaleString();
          if (tb_fail) tb_fail.textContent = s.totalFailed || 0;
        }
        const ss = await API.get('/api/sender/status').catch(() => null);
        const pill = $('tb-campaign-pill'); const spd = $('tb-speed');
        if (ss) {
          if (ss.running) {
            if (pill) { pill.className = 'tb-pill run'; pill.textContent = 'RUNNING'; }
            if (spd) spd.textContent = ss.speed ? ss.speed + '/s' : '';
            const workers = $('tb-workers'); if (workers) workers.textContent = ss.threads || 1;
            // Update dashboard progress block
            const dblock = $('dash-camp-block');
            if (dblock) {
              dblock.style.display = 'block';
              const total = ss.sent + ss.failed + ss.pending;
              const pct = total > 0 ? Math.round((ss.sent + ss.failed) / total * 100) : 0;
              const bar = $('dash-camp-bar'); if (bar) bar.style.width = pct + '%';
              const dp = $('dash-camp-pct'); if (dp) dp.textContent = pct + '%';
              const ds = $('dash-cs'); if (ds) ds.textContent = (ss.sent || 0).toLocaleString();
              const df = $('dash-cf'); if (df) df.textContent = ss.failed || 0;
              const dpp = $('dash-cp'); if (dpp) dpp.textContent = ss.pending || 0;
              const dspd = $('dash-cspd'); if (dspd) dspd.textContent = (ss.speed || 0) + '/s';
              const dsmtp = $('dash-camp-smtp'); if (dsmtp) dsmtp.textContent = 'Account: ' + (ss.cur_smtp || '—');
            }
          } else {
            if (pill) { pill.className = 'tb-pill idle'; pill.textContent = 'IDLE'; }
            if (spd) spd.textContent = '';
            const dblock = $('dash-camp-block'); if (dblock) dblock.style.display = 'none';
          }
        }
      } catch (e) { }
    }
    setInterval(updateTopBar, 5000);
    updateTopBar();

    // ── LIVE STATS PAGE ───────────────────────────────────────────────────────────
    var liveStatsIv = null;
    var _lsLineChart = null, _lsDonutChart = null;
    var _lsSentHistory = [], _lsFailHistory = [], _lsLabels = [];
    var _lsLastSent = 0, _lsLastFail = 0;

    function _initLSCharts() {
      const lineEl = $('ls-line-chart');
      const donutEl = $('ls-donut-chart');
      if (!lineEl || !donutEl || typeof Chart === 'undefined') return;

      Chart.defaults.color = '#8899b5';
      Chart.defaults.borderColor = 'rgba(255,255,255,0.06)';

      if (_lsLineChart) _lsLineChart.destroy();
      _lsLineChart = new Chart(lineEl, {
        type: 'line',
        data: {
          labels: _lsLabels,
          datasets: [
            {
              label: 'Sent',
              data: _lsSentHistory,
              borderColor: '#10d981',
              backgroundColor: 'rgba(16,217,129,0.08)',
              borderWidth: 2,
              pointRadius: 0,
              pointHoverRadius: 4,
              fill: true,
              tension: 0.4
            },
            {
              label: 'Failed',
              data: _lsFailHistory,
              borderColor: '#f43f5e',
              backgroundColor: 'rgba(244,63,94,0.08)',
              borderWidth: 2,
              pointRadius: 0,
              pointHoverRadius: 4,
              fill: true,
              tension: 0.4
            }
          ]
        },
        options: {
          responsive: true, maintainAspectRatio: false, animation: { duration: 400 },
          interaction: { mode: 'index', intersect: false },
          plugins: { legend: { display: true, position: 'top', labels: { boxWidth: 10, font: { size: 10 }, color: '#8899b5' } }, tooltip: { backgroundColor: '#1a1d2e', borderColor: '#2a2d3e', borderWidth: 1, titleFont: { family: 'JetBrains Mono', size: 11 }, bodyFont: { size: 11 } } },
          scales: {
            x: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { font: { family: 'JetBrains Mono', size: 9 }, maxTicksLimit: 8 } },
            y: { grid: { color: 'rgba(255,255,255,0.04)' }, ticks: { font: { family: 'JetBrains Mono', size: 9 } }, beginAtZero: true }
          }
        }
      });

      if (_lsDonutChart) _lsDonutChart.destroy();
      _lsDonutChart = new Chart(donutEl, {
        type: 'doughnut',
        data: {
          labels: ['Sent', 'Failed'],
          datasets: [{
            data: [0, 0],
            backgroundColor: ['rgba(16,217,129,0.85)', 'rgba(244,63,94,0.85)'],
            borderColor: ['#10d981', '#f43f5e'],
            borderWidth: 1.5,
            hoverOffset: 4
          }]
        },
        options: {
          responsive: true, maintainAspectRatio: false, animation: { duration: 500 },
          cutout: '72%',
          plugins: { legend: { display: false }, tooltip: { backgroundColor: '#1a1d2e', borderColor: '#2a2d3e', borderWidth: 1, callbacks: { label: function(ctx) { const total = ctx.dataset.data.reduce(function(a,b){return a+b;},0); const pct = total > 0 ? ((ctx.parsed/total)*100).toFixed(1) : 0; return ctx.label + ': ' + ctx.raw.toLocaleString() + ' (' + pct + '%)'; } } } }
        }
      });
    }

    async function loadLiveStats() {
      try {
        const [st, ss] = await Promise.all([
          API.get('/api/stats').catch(function(){return null;}),
          API.get('/api/sender/status').catch(function(){return null;})
        ]);

        var sent = 0, fail = 0;
        if (st) {
          sent = st.totalSent || 0;
          fail = st.totalFailed || 0;
          const rate = sent + fail > 0 ? ((sent / (sent + fail)) * 100).toFixed(1) + '%' : '—';
          if ($('ls-sent')) $('ls-sent').textContent = sent.toLocaleString();
          if ($('ls-fail')) $('ls-fail').textContent = fail.toLocaleString();
          if ($('ls-smtp')) $('ls-smtp').textContent = (st.smtp && st.smtp.live) ? st.smtp.live : 0;
          if ($('ls-rate')) $('ls-rate').textContent = rate;
          if ($('ls-donut-pct')) $('ls-donut-pct').textContent = sent + fail > 0 ? ((sent/(sent+fail))*100).toFixed(1)+'%' : '—';

          // Update donut chart
          if (_lsDonutChart) {
            _lsDonutChart.data.datasets[0].data = [sent, fail];
            _lsDonutChart.update();
          }
        }

        // Real-time line chart: track delta per poll
        const now = new Date();
        const label = now.getHours().toString().padStart(2,'0') + ':' + now.getMinutes().toString().padStart(2,'0') + ':' + now.getSeconds().toString().padStart(2,'0');
        const deltaSent = Math.max(0, sent - _lsLastSent);
        const deltaFail = Math.max(0, fail - _lsLastFail);
        _lsLastSent = sent; _lsLastFail = fail;
        _lsLabels.push(label); _lsSentHistory.push(deltaSent); _lsFailHistory.push(deltaFail);
        if (_lsLabels.length > 30) { _lsLabels.shift(); _lsSentHistory.shift(); _lsFailHistory.shift(); }
        if (_lsLineChart) {
          _lsLineChart.data.labels = _lsLabels;
          _lsLineChart.data.datasets[0].data = _lsSentHistory;
          _lsLineChart.data.datasets[1].data = _lsFailHistory;
          _lsLineChart.update();
        }

        if (ss) {
          // Campaign progress
          const lblock = $('live-camp-block');
          if (lblock) {
            lblock.style.display = ss.running ? 'block' : 'none';
            const stopBtn = $('ls-stop-btn'); if (stopBtn) stopBtn.style.display = ss.running ? '' : 'none';
            if (ss.running) {
              const total = ss.sent + ss.failed + ss.pending;
              const pct = total > 0 ? Math.round((ss.sent + ss.failed) / total * 100) : 0;
              const lb = $('live-camp-bar'); if (lb) lb.style.width = pct + '%';
              const lp = $('live-camp-pct'); if (lp) lp.textContent = pct + '%';
              if ($('live-cprog-sent')) $('live-cprog-sent').textContent = (ss.sent || 0).toLocaleString();
              if ($('live-cprog-fail')) $('live-cprog-fail').textContent = (ss.failed || 0).toLocaleString();
              if ($('live-cprog-pend')) $('live-cprog-pend').textContent = (ss.pending || 0).toLocaleString();
              if ($('live-cprog-spd')) $('live-cprog-spd').textContent = (ss.speed || 0) + '/s';
              if ($('live-camp-smtp')) $('live-camp-smtp').textContent = ss.cur_smtp || '—';
            }
          }
          // Live log
          const llog = $('ls-log');
          if (llog && (ss.logs || []).length) {
            const auto = $('ls-autoscroll') ? $('ls-autoscroll').checked !== false : true;
            llog.innerHTML = (ss.logs || []).slice(0, 200).map(function(l) {
              var st2 = (l.status || l.type || 'info');
              return '<div class="lr"><span class="lt">'+(l.time||'')+'</span><span class="ltag '+st2+'">'+st2.substring(0,4).toUpperCase()+'</span><span class="lsmtp">'+esc(l.smtp||'')+'</span><span class="lmsg">'+esc(l.to||l.msg||'')+'</span></div>';
            }).join('');
            if (auto) llog.scrollTop = llog.scrollHeight;
          }
        }

        // Bounce + queue from log stats
        const logSt = await API.get('/api/logs/stats').catch(function(){return null;});
        if (logSt) {
          if ($('ls-bounce')) $('ls-bounce').textContent = (logSt.bounce && logSt.bounce.lines) ? logSt.bounce.lines.toLocaleString() : 0;
          if ($('ls-queue')) $('ls-queue').textContent = (ss && ss.pending) ? ss.pending.toLocaleString() : 0;
        }
      } catch(e) { console.warn('loadLiveStats:', e); }
    }

    // ── LOGS PAGE ─────────────────────────────────────────────────────────────────
    async function loadLogs() {
      // DB logs
      const sys = $('syslog-page');
      if (sys) {
        const s = await API.get('/api/stats').catch(() => null);
        if (s) sys.innerHTML = (s.recentLogs || []).length
          ? (s.recentLogs || []).map(l => `<div class="lr"><span class="lt">${(l.created_at || '').replace('T', ' ').substring(5,
            16)}</span><span class="ltag ${l.level || 'info'}">${(l.level || 'info').toUpperCase()}</span><span
    class="lsmtp">[${esc(l.module || 'sys')}]</span><span class="lmsg">${esc(l.message || '')}</span></div>`).join('')
          : '<div class="empty">No logs yet</div>';
      }
      // File log stats
      const logSt = await API.get('/api/logs/stats').catch(() => null);
      const sc = $('log-stat-cards');
      if (sc && logSt) {
        sc.innerHTML = `
<div class="sc gn">
  <div class="sv">${(logSt.send?.lines || 0).toLocaleString()}</div>
  <div class="sl">send.log lines</div>
  <div class="ss">${logSt.send?.size_kb || 0} KB</div>
</div>
<div class="sc rd">
  <div class="sv">${(logSt.failed?.lines || 0).toLocaleString()}</div>
  <div class="sl">failed.log lines</div>
  <div class="ss">${logSt.failed?.size_kb || 0} KB</div>
</div>
<div class="sc yw">
  <div class="sv">${(logSt.bounce?.lines || 0).toLocaleString()}</div>
  <div class="sl">bounce.log lines</div>
  <div class="ss">${logSt.bounce?.size_kb || 0} KB</div>
</div>
`;
      }
      // Show last N lines of each log file
      const area = $('log-files-area');
      if (area) {
        const types = ['send', 'failed', 'bounce'];
        const colors = { send: 'var(--gn)', failed: 'var(--rd)', bounce: 'var(--yw)' };
        area.innerHTML = '';
        for (const t of types) {
          const div = document.createElement('div');
          div.className = 'log-file-block';
          div.innerHTML = `
<div class="log-file-header">
  <span class="log-file-name">${t}.log</span>
  <button class="btn sm" onclick="window.open('/api/logs/download?type=${t}&key='+K)">Download</button>
</div>
<div class="log-file-body" id="logfile-${t}">
  <div class="empty">Loading...</div>
</div>
`;
          area.appendChild(div);
          // Try to load a preview via stats
          const bd = document.getElementById('logfile-' + t);
          if (logSt && logSt[t]?.lines === 0) {
            bd.innerHTML = '<div class="empty">No entries yet</div>';
          } else {
            bd.innerHTML = '<span style="color:var(--tx4)">Click Download to view full log</span>';
          }
        }
      }
    }

    // TEMPLATES
    let _templates = [];
    async function loadTemplates() {
      const raw = localStorage.getItem('mailer_templates');
      _templates = raw ? JSON.parse(raw) : [];
      const el = $('tmpl-list');
      if (!el) return;
      if (!_templates.length) { el.innerHTML = '<div class="empty">No templates saved yet</div>'; return; }
      el.innerHTML = '<div class="panel">' + _templates.map((t, i) => `<div
    style="padding:10px 0;border-bottom:1px solid var(--bd);display:flex;align-items:center;justify-content:space-between">
    <div>
      <div style="font-size:13px;font-weight:600">${esc(t.name)}</div>
      <div style="font-size:11px;color:var(--tx3);margin-top:2px">${(t.html || '').substring(0, 60)}…</div>
    </div>
    <div style="display:flex;gap:6px">
      <button class="btn sm" onclick="useTemplate(${i})">Use</button>
      <button class="xbtn" onclick="delTemplate(${i})">×</button>
    </div>
  </div>`).join('') + '</div>';
    }
    function saveTemplate() {
      const name = $('tmpl-name')?.value.trim();
      const html = $('tmpl-html')?.value.trim();
      if (!name) return toast('Enter template name', 'error');
      if (!html) return toast('Enter HTML content', 'error');
      const raw = localStorage.getItem('mailer_templates');
      const list = raw ? JSON.parse(raw) : [];
      list.push({ name, html, saved: new Date().toISOString() });
      localStorage.setItem('mailer_templates', JSON.stringify(list));
      toast('Template saved', 'success');
      $('tmpl-name').value = ''; $('tmpl-html').value = '';
      loadTemplates();
    }
    function useTemplate(i) {
      const raw = localStorage.getItem('mailer_templates');
      const list = raw ? JSON.parse(raw) : [];
      if (!list[i]) return;
      go('smtp-sender');
      setTimeout(() => {
        const el = $('s-html'); if (el) {
          el.value = list[i].html; toast('Template loaded into editor',
            'success');
        }
      }, 200);
    }
    function delTemplate(i) {
      const raw = localStorage.getItem('mailer_templates');
      const list = raw ? JSON.parse(raw) : [];
      list.splice(i, 1);
      localStorage.setItem('mailer_templates', JSON.stringify(list));
      toast('Deleted', 'success');
      loadTemplates();
    }

    // EMAIL BLACKLIST
    let _emailBL = [];
    async function loadBlacklist() {
      const raw = localStorage.getItem('mailer_email_bl');
      _emailBL = raw ? JSON.parse(raw) : [];
      const tb = $('ebl-tb');
      if (!tb) return;
      if (!_emailBL.length) { tb.innerHTML = '<tr><td colspan="4"><div class="empty">No blacklisted emails</div></td></tr>'; return; }
      tb.innerHTML = _emailBL.map((e, i) => `<tr><td style="font-family:monospace;font-size:11px;color:var(--tx4)">${i + 1}</td><td style="font-size:12px">${esc(e.email)}</td><td style="font-size:11px;color:var(--tx3)">${(e.added || '').substring(0, 10)}</td><td><button class="xbtn" onclick="delEmailBL(${i})">×</button></td></tr>`).join('');
    }
    function addToEmailBL() {
      const raw_inp = $('ebl-inp')?.value.trim();
      if (!raw_inp) return toast('Enter emails first', 'error');
      const emails = raw_inp.split('\n').map(l => l.trim().toLowerCase()).filter(l => l.includes('@'));
      if (!emails.length) return toast('No valid emails found', 'error');
      const stored = localStorage.getItem('mailer_email_bl');
      const list = stored ? JSON.parse(stored) : [];
      const existing = new Set(list.map(x => x.email));
      let added = 0;
      emails.forEach(email => { if (!existing.has(email)) { list.push({ email, added: new Date().toISOString() }); added++; } });
      localStorage.setItem('mailer_email_bl', JSON.stringify(list));
      toast(added + ' emails blacklisted (' + (emails.length - added) + ' already existed)', 'success');
      $('ebl-inp').value = '';
      loadBlacklist();
    }
    function delEmailBL(i) {
      const raw = localStorage.getItem('mailer_email_bl');
      const list = raw ? JSON.parse(raw) : [];
      list.splice(i, 1);
      localStorage.setItem('mailer_email_bl', JSON.stringify(list));
      toast('Removed', 'success');
      loadBlacklist();
    }
    function clearEmailBL() {
      if (cf() && !confirm('Clear entire email blacklist?')) return;
      localStorage.removeItem('mailer_email_bl');
      toast('Cleared', 'success');
      loadBlacklist();
    }

    // SUPPORT TICKETS
    let _tickets = [];
    async function loadTickets() {
      const raw = localStorage.getItem('mailer_tickets');
      _tickets = raw ? JSON.parse(raw) : [];
      const el = $('tkt-list');
      if (!el) return;
      if (!_tickets.length) { el.innerHTML = '<div class="empty">No tickets yet — submit one above</div>'; return; }
      el.innerHTML = '<div class="panel">' + _tickets.slice().reverse().map((t, i) => {
        const statusCls = t.status === 'open' ? 'live' : 'die';
        return `<div style="padding:12px 0;border-bottom:1px solid var(--bd)"><div style="display:flex;align-items:flex-start;justify-content:space-between;gap:10px"><div style="flex:1"><div style="font-size:13px;font-weight:600;margin-bottom:4px">${esc(t.subject)}</div><div style="font-size:11px;color:var(--tx2);line-height:1.6">${esc(t.message)}</div><div style="font-size:10px;color:var(--tx3);margin-top:5px">${(t.created || '').replace('T', ' ').substring(0, 16)}</div></div><span class="bs ${statusCls}">${(t.status || 'open').toUpperCase()}</span></div></div>`;
      }).join('') + '</div>';
    }
    function submitTicket() {
      const subj = $('tkt-subj')?.value.trim();
      const msg = $('tkt-msg')?.value.trim();
      if (!subj) return toast('Enter a subject', 'error');
      if (!msg) return toast('Enter a message', 'error');
      const raw = localStorage.getItem('mailer_tickets');
      const list = raw ? JSON.parse(raw) : [];
      list.push({ subject: subj, message: msg, status: 'open', created: new Date().toISOString() });
      localStorage.setItem('mailer_tickets', JSON.stringify(list));
      toast('Ticket submitted', 'success');
      $('tkt-subj').value = ''; $('tkt-msg').value = '';
      loadTickets();
    }

    //  WEBMAIL SENDER 
    let _wmsAccounts = [], _wmsMails = [], _wmsPollIv = null;

    async function loadWMSenderState() {
      try {
        const data = await API.get('/api/webmail?status=live').catch(() => []);
        _wmsAccounts = data || [];
        const cnt = $('wms-cnt');
        if (cnt) cnt.textContent = _wmsAccounts.length;
      } catch (_) {}
    }

    async function loadLiveWM() {
      try {
        const data = await API.get('/api/webmail?status=live').catch(() => []);
        _wmsAccounts = data || [];
        const cnt = $('wms-cnt');
        if (cnt) cnt.textContent = _wmsAccounts.length;
        toast(_wmsAccounts.length + ' live webmail accounts loaded', _wmsAccounts.length ? 'success' : 'error');
      } catch (e) { toast('Failed: ' + e.message, 'error'); }
    }

    async function loadMailDBwm() {
      try {
        const data = await API.get('/api/mail').catch(() => []);
        _wmsMails = (data || []).map(r => r.email).filter(Boolean);
        const cnt = $('wms-m-cnt');
        if (cnt) cnt.textContent = _wmsMails.length;
        toast(_wmsMails.length + ' emails loaded', _wmsMails.length ? 'success' : 'error');
      } catch (e) { toast('Failed: ' + e.message, 'error'); }
    }

    function loadWMSMail() {
      const inp = $('wms-mail-inp');
      if (!inp) return;
      const emails = inp.value.split('\n').map(function(l) { return l.trim().toLowerCase(); }).filter(function(l) { return l.includes('@'); });
      _wmsMails = emails;
      const cnt = $('wms-m-cnt');
      if (cnt) cnt.textContent = _wmsMails.length;
      toast(_wmsMails.length + ' emails loaded', 'success');
    }

    function switchWMTab(tab) {
      const edPane = $('wm-ed-pane'), pvPane = $('wm-pv-pane');
      const edTab = $('wm-tab-ed'), pvTab = $('wm-tab-pv');
      if (tab === 'editor') {
        if (edPane) edPane.style.display = '';
        if (pvPane) pvPane.style.display = 'none';
        if (edTab) edTab.classList.add('active');
        if (pvTab) pvTab.classList.remove('active');
      } else {
        if (edPane) edPane.style.display = 'none';
        if (pvPane) pvPane.style.display = '';
        if (edTab) edTab.classList.remove('active');
        if (pvTab) pvTab.classList.add('active');
        wmHtmlChanged();
      }
    }

    function wmHtmlChanged() {
      const frame = $('wm-preview-frame');
      const html = $('wms-html') ? $('wms-html').value : '';
      if (frame) {
        const doc = frame.contentDocument || frame.contentWindow.document;
        doc.open(); doc.write(html); doc.close();
      }
    }

    async function startWMSender() {
      const subj = $('wms-subj') ? $('wms-subj').value.trim() : '';
      const html = $('wms-html') ? $('wms-html').value.trim() : '';
      if (!subj) return toast('Enter subject', 'error');
      if (!html) return toast('Enter HTML body', 'error');
      if (!_wmsMails.length) return toast('Load recipients first', 'error');
      const manInp = $('wms-inp') ? $('wms-inp').value.trim() : '';
      const cfg = {
        mode: 'webmail',
        webmail_source: manInp ? 'manual' : 'live',
        webmail_manual: manInp ? manInp.split('\n').map(function(l){return l.trim();}).filter(Boolean) : [],
        emails: _wmsMails,
        subjects: [subj],
        letters: [html],
        from_name: $('wms-fn') ? $('wms-fn').value.trim() : '',
        reply_to: $('wms-rt') ? $('wms-rt').value.trim() : '',
        tag: $('wms-tag') ? $('wms-tag').value.trim() : '',
        delay_min: parseFloat(($('wms-dmin') || {value: 3}).value),
        delay_max: parseFloat(($('wms-dmax') || {value: 8}).value),
        mails_per_smtp: parseInt(($('wms-mper') || {value: 30}).value),
        threads: parseInt(($('wms-threads') || {value: 1}).value),
      };
      try {
        const res = await API.post('/api/sender/start', cfg);
        if (res.error) return toast(res.error, 'error');
        toast('Webmail campaign started!', 'success');
        const live = $('wms-live'); if (live) live.style.display = 'block';
        const btnS = $('btn-wss'); if (btnS) btnS.style.display = 'none';
        const btnC = $('btn-wsc'); if (btnC) btnC.style.display = '';
        const prog = $('wms-prog'); if (prog) prog.style.display = 'block';
        _wmsPollIv = setInterval(_wmsPoll, 2000);
      } catch (e) { toast('Start failed: ' + e.message, 'error'); }
    }

    async function _wmsPoll() {
      try {
        const ss = await API.get('/api/sender/status').catch(() => null);
        if (!ss) return;
        if (ss.running) {
          if ($('wss-sent')) $('wss-sent').textContent = ss.sent || 0;
          if ($('wss-fail')) $('wss-fail').textContent = ss.failed || 0;
          if ($('wss-pend')) $('wss-pend').textContent = ss.pending || 0;
          const tot = ss.sent + ss.failed;
          if ($('wss-rate')) $('wss-rate').textContent = tot > 0 ? ((ss.sent/tot)*100).toFixed(1)+'%' : '0%';
          if ($('wss-spd')) $('wss-spd').textContent = ss.speed || 0;
          if ($('wss-smtp')) $('wss-smtp').textContent = ss.cur_smtp || '-';
          const prog = $('wms-prog');
          if (prog) {
            const total = ss.sent + ss.failed + ss.pending;
            const pct = total > 0 ? ((ss.sent+ss.failed)/total*100) : 0;
            const fill = prog.querySelector('.fill'); if (fill) fill.style.width = pct + '%';
          }
          const log = $('wmslog');
          if (log && (ss.logs||[]).length) {
            log.innerHTML = (ss.logs||[]).slice(0,100).map(function(l){ return '<div class="lr"><span class="lt">'+(l.time||'')+'</span><span class="ltag '+(l.status||'info')+'">'+(l.status||'info').substring(0,4).toUpperCase()+'</span><span class="lmsg">'+esc(l.to||l.msg||'')+'</span></div>'; }).join('');
            log.scrollTop = log.scrollHeight;
          }
        } else {
          if (_wmsPollIv) { clearInterval(_wmsPollIv); _wmsPollIv = null; }
          const btnS = $('btn-wss'); if (btnS) btnS.style.display = '';
          const btnC = $('btn-wsc'); if (btnC) btnC.style.display = 'none';
          toast('Webmail campaign finished', 'success');
        }
      } catch(_) {}
    }

    async function cancelSender() {
      await API.post('/api/sender/cancel', {}).catch(() => {});
      if (_wmsPollIv) { clearInterval(_wmsPollIv); _wmsPollIv = null; }
      const btnS = $('btn-wss'); if (btnS) btnS.style.display = '';
      const btnC = $('btn-wsc'); if (btnC) btnC.style.display = 'none';
      toast('Campaign stopped', 'success');
    }

    //  LOGS 
    async function clearLogs() {
      await API.del('/api/logs').catch(() => {});
      const el = $('logs-area'); if (el) el.innerHTML = '<div class="empty">Cleared</div>';
      toast('Logs cleared', 'success');
    }
