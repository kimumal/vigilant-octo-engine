#!/usr/bin/env python3
"""
Inbox Checker v4.0 PRO
Check if test emails landed in INBOX or SPAM/JUNK folder via IMAP.

stdin: id|imap_host|imap_port|email|password|search_subject|search_from
stdout: JSON per line

Checks INBOX and common spam folders for matching emails.
"""
import sys, json, time, imaplib, email, socket
from email.header import decode_header

socket.setdefaulttimeout(20)

SPAM_FOLDERS = [
    'SPAM', 'Junk', 'Junk E-mail', 'Junk Email',
    '[Gmail]/Spam', 'Bulk Mail', 'Bulk',
    'INBOX.spam', 'INBOX.junk', 'INBOX.Junk',
    'Unwanted', 'Spamverdacht'
]

IMAP_HOSTS = {
    'gmail.com': 'imap.gmail.com',
    'googlemail.com': 'imap.gmail.com',
    'yahoo.com': 'imap.mail.yahoo.com',
    'yahoo.co.uk': 'imap.mail.yahoo.com',
    'outlook.com': 'outlook.office365.com',
    'hotmail.com': 'outlook.office365.com',
    'live.com': 'outlook.office365.com',
    'msn.com': 'outlook.office365.com',
    'office365.com': 'outlook.office365.com',
    'aol.com': 'imap.aol.com',
    'icloud.com': 'imap.mail.me.com',
    'me.com': 'imap.mail.me.com',
    'mac.com': 'imap.mail.me.com',
    'zoho.com': 'imap.zoho.com',
    'yandex.com': 'imap.yandex.com',
    'mail.ru': 'imap.mail.ru',
    'gmx.com': 'imap.gmx.com',
    'gmx.net': 'imap.gmx.net',
    'protonmail.com': 'imap.protonmail.ch',
}

def guess_imap_host(email_addr):
    domain = email_addr.split('@')[1].lower()
    if domain in IMAP_HOSTS:
        return IMAP_HOSTS[domain]
    return f'imap.{domain}'

def decode_subject(raw_subject):
    try:
        parts = decode_header(raw_subject)
        decoded = []
        for part, charset in parts:
            if isinstance(part, bytes):
                decoded.append(part.decode(charset or 'utf-8', errors='replace'))
            else:
                decoded.append(str(part))
        return ''.join(decoded)
    except:
        return str(raw_subject)

def search_folder(conn, folder, subject_query, from_query, limit=20):
    results = []
    try:
        status, _ = conn.select(folder, readonly=True)
        if status != 'OK':
            return results

        criteria_parts = []
        if subject_query:
            criteria_parts.append(f'SUBJECT "{subject_query}"')
        if from_query:
            criteria_parts.append(f'FROM "{from_query}"')

        if not criteria_parts:
            criteria_parts.append('ALL')

        criteria = '(' + ' '.join(criteria_parts) + ')'
        status, data = conn.search(None, criteria)
        if status != 'OK':
            return results

        ids = data[0].split()
        if not ids:
            return results

        # Get last N
        check_ids = ids[-limit:]
        for mid in check_ids:
            try:
                status, msg_data = conn.fetch(mid, '(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT DATE)])')
                if status == 'OK' and msg_data[0]:
                    raw = msg_data[0][1]
                    msg = email.message_from_bytes(raw)
                    results.append({
                        'subject': decode_subject(msg.get('Subject', '')),
                        'from': msg.get('From', ''),
                        'date': msg.get('Date', ''),
                        'folder': folder
                    })
            except:
                continue
    except Exception as e:
        pass
    return results

def check_inbox(sid, imap_host, imap_port, addr, pwd, subject_q='', from_q=''):
    r = {
        "id": sid,
        "email": addr,
        "status": "error",
        "inbox_count": 0,
        "spam_count": 0,
        "location": "unknown",
        "inbox_results": [],
        "spam_results": [],
        "folders_checked": [],
        "error": ""
    }
    start = time.time()
    conn = None

    try:
        imap_port = int(imap_port) if imap_port else 993
        if not imap_host:
            imap_host = guess_imap_host(addr)

        if imap_port == 993:
            conn = imaplib.IMAP4_SSL(imap_host, imap_port)
        else:
            conn = imaplib.IMAP4(imap_host, imap_port)

        conn.login(addr, pwd)

        # List available folders
        available_folders = []
        try:
            status, folder_list = conn.list()
            if status == 'OK':
                for f in folder_list:
                    if isinstance(f, bytes):
                        parts = f.decode('utf-8', errors='replace').split('"')
                        if len(parts) >= 3:
                            available_folders.append(parts[-2].strip())
                        else:
                            fname = f.decode('utf-8', errors='replace').split()[-1].strip('"')
                            available_folders.append(fname)
        except:
            available_folders = ['INBOX']

        # Check INBOX
        inbox_results = search_folder(conn, 'INBOX', subject_q, from_q)
        r["inbox_count"] = len(inbox_results)
        r["inbox_results"] = inbox_results[:10]
        r["folders_checked"].append('INBOX')

        # Check spam/junk folders
        spam_results = []
        for sf in SPAM_FOLDERS:
            if any(sf.lower() == af.lower() for af in available_folders):
                found = search_folder(conn, sf, subject_q, from_q)
                if found:
                    spam_results.extend(found)
                    r["folders_checked"].append(sf)
                    break
            else:
                # Try anyway
                found = search_folder(conn, sf, subject_q, from_q)
                if found:
                    spam_results.extend(found)
                    r["folders_checked"].append(sf)
                    break

        r["spam_count"] = len(spam_results)
        r["spam_results"] = spam_results[:10]

        # Determine location
        if r["inbox_count"] > 0 and r["spam_count"] == 0:
            r["location"] = "inbox"
            r["status"] = "inbox"
        elif r["spam_count"] > 0 and r["inbox_count"] == 0:
            r["location"] = "spam"
            r["status"] = "spam"
        elif r["inbox_count"] > 0 and r["spam_count"] > 0:
            r["location"] = "both"
            r["status"] = "both"
        else:
            r["location"] = "not_found"
            r["status"] = "not_found"

        conn.logout()
        conn = None

    except imaplib.IMAP4.error as e:
        r["error"] = f"imap_auth: {str(e)[:80]}"
    except socket.timeout:
        r["error"] = "timeout"
    except ConnectionRefusedError:
        r["error"] = "connection_refused"
    except Exception as e:
        r["error"] = str(e)[:100]
    finally:
        r["response_time"] = round(time.time() - start, 2)
        if conn:
            try: conn.logout()
            except: pass

    return r

def main():
    data = sys.stdin.read().strip()
    if not data:
        sys.exit(0)
    for line in data.split('\n'):
        line = line.strip()
        if not line:
            continue
        p = line.split('|')
        if len(p) < 5:
            continue
        sid = int(p[0])
        imap_host = p[1].strip()
        imap_port = p[2].strip()
        addr = p[3].strip()
        pwd = p[4].strip()
        subject_q = p[5].strip() if len(p) > 5 else ''
        from_q = p[6].strip() if len(p) > 6 else ''
        result = check_inbox(sid, imap_host, imap_port, addr, pwd, subject_q, from_q)
        print(json.dumps(result), flush=True)

if __name__ == '__main__':
    main()
