#!/bin/bash
# Run bot separately (if server already running)
cd "$(dirname "$0")"
echo "Starting MAILER bot..."
python3 bot.py
