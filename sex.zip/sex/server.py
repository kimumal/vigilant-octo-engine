#!/usr/bin/env python3
"""MAILER v7 PRO"""
import os,json,time,hashlib,sqlite3,threading,re,csv,io,logging,base64
import smtplib,ssl,socket,random,ipaddress
from datetime import datetime,timedelta,timezone
from collections import deque,defaultdict
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders as _email_enc
from email.utils import formataddr,formatdate,make_msgid
from html.parser import HTMLParser
from http.server import HTTPServer,SimpleHTTPRequestHandler
from urllib.parse import urlparse,parse_qs

logging.basicConfig(level=logging.INFO,format='%(asctime)s [%(levelname)s] %(message)s')
log=logging.getLogger(__name__)

PORT       = int(os.environ.get('PORT',3000))
DATA_DIR   = os.path.join(os.path.dirname(os.path.abspath(__file__)),'data')
STATIC_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),'static')
CLOUD_DIR  = os.path.join(DATA_DIR,'cloud')
os.makedirs(DATA_DIR,exist_ok=True)
os.makedirs(CLOUD_DIR,exist_ok=True)
socket.setdefaulttimeout(20)

# ── LOAD .env file if present (python-dotenv not required) ────────────────────
def _load_dotenv():
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.env')
    if not os.path.exists(env_path): return
    with open(env_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#') or '=' not in line: continue
            k, _, v = line.partition('=')
            k = k.strip(); v = v.strip().strip('"').strip("'")
            if k and k not in os.environ:   # don't override real env vars
                os.environ[k] = v
_load_dotenv()

# ── SECRETS — no hardcoded defaults; must be set in .env or environment ───────
def _require_env(key, hint=''):
    v = os.environ.get(key, '').strip()
    if not v:
        raise RuntimeError(
            f"Missing required env var: {key}"
            + (f"  ({hint})" if hint else '')
            + "  →  set it in .env or export before running."
        )
    return v

ADMIN_KEY  = os.environ.get('MAILER_ADMIN_KEY','').strip()
BOT_TOKEN  = os.environ.get('MAILER_BOT_TOKEN','').strip()
_admin_tg  = os.environ.get('MAILER_ADMIN_TG','0').strip()
ADMIN_TG   = int(_admin_tg) if _admin_tg.isdigit() else 0
USDT_ADDR  = os.environ.get('MAILER_USDT','').strip()

if not ADMIN_KEY:
    raise RuntimeError("Missing required env var: MAILER_ADMIN_KEY  →  set it in .env")

# Production config — set via environment variables
TRUST_PROXY   = os.environ.get('MAILER_TRUST_PROXY','1') == '1'
BEHIND_HTTPS  = os.environ.get('MAILER_HTTPS','0') == '1'
COOKIE_DOMAIN = os.environ.get('MAILER_COOKIE_DOMAIN','')
_RAW_ORIGINS  = os.environ.get('MAILER_ALLOWED_ORIGINS','*')
ALLOWED_ORIGINS = [o.strip().rstrip('/') for o in _RAW_ORIGINS.split(',') if o.strip()]

def get_cors_origin(request_origin=''):
    if not ALLOWED_ORIGINS or '*' in ALLOWED_ORIGINS:
        return '*'
    ro = (request_origin or '').rstrip('/')
    if ro in ALLOWED_ORIGINS:
        return ro
    if COOKIE_DOMAIN:
        domain_bare = COOKIE_DOMAIN.lstrip('.')
        try:
            from urllib.parse import urlparse as _up
            host = _up(ro).hostname or ''
            if host == domain_bare or host.endswith('.' + domain_bare):
                return ro
        except Exception:
            pass
    return ALLOWED_ORIGINS[0] if ALLOWED_ORIGINS else '*'

# ── SECURITY ───────────────────────────────────────────────────────────────────
# ── SECURITY ─────────────────────────────────────────────────────────────────
_brute  = defaultdict(lambda: {'fail':0,'blocked_until':0})
_rate   = defaultdict(lambda: {'hits':[]})
_ddos   = defaultdict(lambda: {'hits':[],'blocked_until':0})

BRUTE_MAX  = 5      # max login fails before block
BRUTE_WIN  = 600    # block 10 min
RATE_MAX   = 200    # max API reqs/min per IP
RATE_WIN   = 60
DDOS_MAX   = 500    # hard DDoS threshold per 10s
DDOS_WIN   = 10
DDOS_BLOCK = 1800   # DDoS block 30 min

import re as _re
_SQLI_RE = _re.compile(
    r'(?i)(union\s+select|drop\s+table|insert\s+into\s+\w|delete\s+from\s+\w'
    r'|exec\s*\(|xp_cmdshell|0x[0-9a-f]{4,}|information_schema)',
)
_TRAV_RE = _re.compile(r'(?i)(\.\.[\/]|%2e%2e[%2f%5c])')
_HDR_RE  = _re.compile(r'(?i)([\r\n]|<script)')


def _ip(h):
    """Get real client IP. Respects TRUST_PROXY for reverse proxy deployments."""
    if TRUST_PROXY:
        # CF-Connecting-IP is most reliable (Cloudflare)
        cf = h.headers.get('CF-Connecting-IP','').strip()
        if cf and '.' in cf and len(cf) < 46:
            return cf
        # X-Real-IP set by nginx: proxy_set_header X-Real-IP $remote_addr
        xri = h.headers.get('X-Real-IP','').strip()
        if xri and '.' in xri and len(xri) < 46:
            return xri
        # X-Forwarded-For — take rightmost trusted IP (leftmost is client)
        xff = h.headers.get('X-Forwarded-For','').strip()
        if xff:
            # leftmost = original client, rightmost = last proxy
            ip = xff.split(',')[0].strip()
            if ip and len(ip) < 46:
                return ip
    return h.client_address[0]

def sec_ddos(ip):
    """Hard DDoS block — 500 req/10s triggers 30min ban."""
    now=time.time();b=_ddos[ip]
    if b['blocked_until'] > now:
        return False  # still blocked
    b['hits']=[t for t in b['hits'] if now-t<DDOS_WIN]
    b['hits'].append(now)
    if len(b['hits']) >= DDOS_MAX:
        b['blocked_until']=now+DDOS_BLOCK
        log.warning(f'DDoS blocked:{ip} ({len(b["hits"])} reqs/{DDOS_WIN}s)')
        log_ev('warn','security',f'DDoS blocked:{ip}')
        return False
    return True

def sec_sqli(text):
    """Detect SQL injection attempt in request body string."""
    if not isinstance(text,str): return False
    return bool(_SQLI_RE.search(text))

def sec_xss(text):
    """Detect XSS attempt."""
    if not isinstance(text,str): return False
    return bool(re.search(r'(?i)(<script|javascript:|on\w+\s*=|<iframe|<object)',text))

def sec_path_trav(path):
    """Detect path traversal."""
    return bool(_TRAV_RE.search(path))

# Per-route rate limits: {path_prefix: (max_hits, window_seconds)}
_ROUTE_LIMITS={
    '/api/auth/login':      (10,  60),   # 10 login attempts/min
    '/adminlogin/auth':     (5,   60),   # 5 admin login attempts/min
    '/api/smtp/check':      (5,   60),   # 5 check starts/min
    '/api/webmail/check':   (5,   60),
    '/api/smtp/import':     (20,  60),   # 20 imports/min
    '/api/mail/import':     (20,  60),
    '/api/sender/start':    (10,  60),
    '/api/bomb/start':      (5,   60),
    '/api/mail/clean':      (10,  60),
}
_route_rate=defaultdict(lambda:defaultdict(lambda:{'hits':[]}))

def sec_rate(ip,path):
    if path in('/','/login','/adminlogin'): return True
    now=time.time()
    # Check per-route limit first
    for prefix,(mx,win) in _ROUTE_LIMITS.items():
        if path==prefix or path.startswith(prefix+'/'):
            b=_route_rate[prefix][ip]
            b['hits']=[t for t in b['hits'] if now-t<win]
            if len(b['hits'])>=mx: return False
            b['hits'].append(now)
            break
    # Global rate limit
    b=_rate[ip]
    b['hits']=[t for t in b['hits'] if now-t<RATE_WIN]
    if len(b['hits'])>=RATE_MAX: return False
    b['hits'].append(now); return True

def sec_brute_ok(ip):
    return _brute[ip]['blocked_until']<time.time()

def sec_fail(ip):
    b=_brute[ip];b['fail']+=1
    if b['fail']>=BRUTE_MAX:
        b['blocked_until']=time.time()+BRUTE_WIN;b['fail']=0
        log.warning(f'Brute blocked:{ip}')
        log_ev('warn','security',f'Brute-force blocked:{ip}')

def sec_ok(ip):
    _brute[ip]={'fail':0,'blocked_until':0}

def xss(s):
    """Sanitize string — strip XSS vectors, limit length, strip null bytes."""
    if not isinstance(s,str): return s
    s=s.replace('\x00','')[:8192]  # null bytes + max length
    s=re.sub(r'(?i)<script[^>]*>.*?</script>','',s,flags=re.S)
    s=re.sub(r'(?i)<(iframe|object|embed|applet|form|input)[^>]*>','',s)
    s=re.sub(r'(?i)\bon\w+\s*=','',s)
    s=re.sub(r'(?i)javascript\s*:','',s)
    s=re.sub(r'(?i)vbscript\s*:','',s)
    s=re.sub(r'(?i)data:\s*text/html','',s)
    return s.strip()

def sanitize_body(d):
    """Recursively sanitize all string values in a dict/list body."""
    if isinstance(d,dict):
        return {k:sanitize_body(v) for k,v in d.items()}
    if isinstance(d,list):
        return [sanitize_body(v) for v in d]
    if isinstance(d,str):
        # Check for SQLi
        if sec_sqli(d):
            log.warning(f'SQLi attempt detected in body: {d[:80]}')
            raise ValueError('Invalid input detected')
        return xss(d)
    return d

def _sec_gc():
    while True:
        time.sleep(600);now=time.time()
        for ip in[k for k,v in list(_rate.items()) if not v['hits'] or now-max(v['hits'])>120]:_rate.pop(ip,None)
        for ip in[k for k,v in list(_brute.items()) if v['fail']==0 and v['blocked_until']<now]:_brute.pop(ip,None)
threading.Thread(target=_sec_gc,daemon=True).start()

# ── DB ─────────────────────────────────────────────────────────────────────────
DB=os.path.join(DATA_DIR,'mailer.db')
_lock=threading.Lock()

def get_db():
    c=sqlite3.connect(DB,check_same_thread=False)
    c.row_factory=sqlite3.Row;c.execute("PRAGMA journal_mode=WAL")
    return c

def init_db():
    c=get_db()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS smtp(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        host TEXT,port INTEGER,username TEXT,password TEXT,
        status TEXT DEFAULT 'unchecked',ssl_info TEXT DEFAULT '',
        response_time REAL DEFAULT 0,error_msg TEXT DEFAULT '',
        health_score INTEGER DEFAULT 100,
        from_name TEXT DEFAULT '',from_email TEXT DEFAULT '',reply_to TEXT DEFAULT '',
        last_checked TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(host,port,username));
    CREATE TABLE IF NOT EXISTS webmail(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        url TEXT,email TEXT,password TEXT,
        status TEXT DEFAULT 'unchecked',server_info TEXT DEFAULT '',
        response_time REAL DEFAULT 0,error_msg TEXT DEFAULT '',
        last_checked TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(url,email));
    CREATE TABLE IF NOT EXISTS proxy(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ip TEXT,port INTEGER,username TEXT DEFAULT '',password TEXT DEFAULT '',
        status TEXT DEFAULT 'unchecked',latency REAL DEFAULT 0,
        country TEXT DEFAULT '',blacklisted INTEGER DEFAULT 0,
        last_checked TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(ip,port,username));
    CREATE TABLE IF NOT EXISTS mail(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,domain TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS api_keys(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key_hash TEXT UNIQUE,key_display TEXT UNIQUE,
        is_admin INTEGER DEFAULT 0,
        max_smtp INTEGER DEFAULT 999999,max_emails INTEGER DEFAULT 999999,
        tier TEXT DEFAULT 'pro',expires_at TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,created_by TEXT DEFAULT 'system');
    CREATE TABLE IF NOT EXISTS logs(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        level TEXT DEFAULT 'info',module TEXT,message TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS announcements(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,content TEXT,type TEXT DEFAULT 'info',
        active INTEGER DEFAULT 1,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS send_history(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        recipient TEXT,smtp_user TEXT,status TEXT,
        error TEXT DEFAULT '',response_time REAL DEFAULT 0,
        campaign TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS schedules(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,config TEXT,run_at TEXT,
        status TEXT DEFAULT 'pending',repeat TEXT DEFAULT 'once',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS blacklist_cache(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        host TEXT UNIQUE,listed INTEGER DEFAULT 0,
        details TEXT DEFAULT '',checked_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS warmup_sessions(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        smtp_id INTEGER,day INTEGER DEFAULT 1,
        emails_today INTEGER DEFAULT 0,target_today INTEGER DEFAULT 10,
        status TEXT DEFAULT 'active',last_run TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS webhook_config(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        url TEXT,events TEXT DEFAULT 'all',
        platform TEXT DEFAULT 'generic',active INTEGER DEFAULT 1,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS domain_check_cache(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        domain TEXT UNIQUE,
        mx_ok INTEGER DEFAULT 0,spf_ok INTEGER DEFAULT 0,
        blacklisted INTEGER DEFAULT 0,phishing_score INTEGER DEFAULT 0,
        details TEXT DEFAULT '',checked_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS plans(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plan_key TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        price TEXT NOT NULL,
        price_vnd INTEGER DEFAULT 0,
        description TEXT DEFAULT '',
        dur TEXT NOT NULL,
        days INTEGER NOT NULL,
        tier TEXT NOT NULL DEFAULT 'pro',
        active INTEGER DEFAULT 1,
        updated_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS templates(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,subject TEXT,html TEXT,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS support_tickets(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id TEXT,tg_name TEXT,subject TEXT,
        status TEXT DEFAULT 'open',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS email_blacklist(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS login_events(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key_hash TEXT,ip TEXT,ua TEXT,
        location TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS custom_hosts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        host_type TEXT DEFAULT 'smtp',
        host TEXT,port INTEGER,
        ssl_tls TEXT DEFAULT 'tls',
        username TEXT DEFAULT '',password TEXT DEFAULT '',
        status TEXT DEFAULT 'unchecked',
        error_msg TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS cloud_files(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        original_name TEXT NOT NULL,
        file_size INTEGER DEFAULT 0,
        mime_type TEXT DEFAULT 'application/octet-stream',
        description TEXT DEFAULT '',
        uploaded_by TEXT DEFAULT 'admin',
        download_count INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS checker_results(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key_id INTEGER DEFAULT 0,
        check_type TEXT DEFAULT 'smtp',
        target TEXT,
        username TEXT DEFAULT '',
        password TEXT DEFAULT '',
        status TEXT DEFAULT 'pending',
        response_time REAL DEFAULT 0,
        extra TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS mailtm_accounts(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key_id INTEGER DEFAULT 0,
        address TEXT,
        password TEXT,
        token TEXT DEFAULT '',
        status TEXT DEFAULT 'active',
        message_count INTEGER DEFAULT 0,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    """)
    # ── Indexes for performance ───────────────────────────────────────────────
    c.executescript("""
    CREATE INDEX IF NOT EXISTS idx_smtp_status       ON smtp(status);
    CREATE INDEX IF NOT EXISTS idx_smtp_health       ON smtp(health_score DESC);
    CREATE INDEX IF NOT EXISTS idx_webmail_status    ON webmail(status);
    CREATE INDEX IF NOT EXISTS idx_proxy_status      ON proxy(status);
    CREATE INDEX IF NOT EXISTS idx_mail_domain       ON mail(domain);
    CREATE INDEX IF NOT EXISTS idx_mail_email        ON mail(email);
    CREATE INDEX IF NOT EXISTS idx_keys_hash         ON api_keys(key_hash);
    CREATE INDEX IF NOT EXISTS idx_keys_display      ON api_keys(key_display);
    CREATE INDEX IF NOT EXISTS idx_keys_expires      ON api_keys(expires_at);
    CREATE INDEX IF NOT EXISTS idx_logs_created      ON logs(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_history_created   ON send_history(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_history_status    ON send_history(status);
    CREATE INDEX IF NOT EXISTS idx_schedules_status  ON schedules(status,run_at);
    CREATE INDEX IF NOT EXISTS idx_cloud_created     ON cloud_files(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_checker_key       ON checker_results(key_id,check_type);
    CREATE INDEX IF NOT EXISTS idx_checker_created   ON checker_results(created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_mailtm_key        ON mailtm_accounts(key_id);
    """)
    # ── Migrate existing DB: add new columns if absent ───────────────────────
    for tbl, col, defn in [
        ('api_keys',     'telegram_id', 'INTEGER DEFAULT 0'),
        ('api_keys',     'last_ip',     "TEXT DEFAULT ''"),
        ('plans',        'price_vnd',   'INTEGER DEFAULT 0'),
        ('plans',        'description', "TEXT DEFAULT ''"),
        # ── user isolation columns ───────────────────────────────────────────────
        ('smtp',         'key_id',      'INTEGER DEFAULT 0'),
        ('webmail',      'key_id',      'INTEGER DEFAULT 0'),
        ('proxy',        'key_id',      'INTEGER DEFAULT 0'),
        ('mail',         'key_id',      'INTEGER DEFAULT 0'),
        ('send_history', 'key_id',      'INTEGER DEFAULT 0'),
        ('schedules',    'key_id',      'INTEGER DEFAULT 0'),
        ('templates',    'key_id',      'INTEGER DEFAULT 0'),
        ('custom_hosts', 'key_id',      'INTEGER DEFAULT 0'),
    ]:
        try: c.execute(f"ALTER TABLE {tbl} ADD COLUMN {col} {defn}")
        except: pass
    for col, defn in [('price_vnd', 'INTEGER DEFAULT 0'), ('description', "TEXT DEFAULT ''")]:
        try: c.execute(f"ALTER TABLE plans ADD COLUMN {col} {defn}")
        except: pass
    c.commit()

    # ── Remove old default plans that are replaced ────────────────────────────
    c.execute("DELETE FROM plans WHERE plan_key IN ('advanced','ultimate')")

    # ── Seed / update 10 canonical plans ─────────────────────────────────────
    # (plan_key, name, price_usd, dur, days, tier, price_vnd, description)
    _default_plans = [
        ('trial',      'Trial',      '$1',   '1 Day',    1,     'basic',     25000,   'Try the platform for 1 day'),
        ('starter',    'Starter',    '$3',   '3 Days',   3,     'basic',     75000,   'Get started with full features'),
        ('basic',      'Basic',      '$5',   '7 Days',   7,     'basic',     125000,  'Ideal for short campaigns'),
        ('standard',   'Standard',   '$10',  '14 Days',  14,    'pro',       250000,  'Standard access for 2 weeks'),
        ('pro',        'Pro',        '$15',  '1 Month',  30,    'pro',       375000,  'Full pro features for 1 month'),
        ('premium',    'Premium',    '$25',  '2 Months', 60,    'pro',       625000,  'Extended access, all features'),
        ('business',   'Business',   '$40',  '3 Months', 90,    'pro',       1000000, 'Best value for regular senders'),
        ('vip',        'VIP',        '$60',  '6 Months', 180,   'unlimited', 1500000, 'VIP access with priority support'),
        ('enterprise', 'Enterprise', '$100', '1 Year',   365,   'unlimited', 2500000, 'Enterprise-grade full year access'),
        ('lifetime',   'Lifetime',   '$150', 'Lifetime', 36500, 'unlimited', 3750000, 'One-time payment, lifetime access'),
    ]
    for pk, name, price, dur, days, tier, price_vnd, description in _default_plans:
        # Insert if not present
        c.execute(
            "INSERT OR IGNORE INTO plans(plan_key,name,price,price_vnd,description,dur,days,tier)"
            " VALUES(?,?,?,?,?,?,?,?)",
            (pk, name, price, price_vnd, description, dur, days, tier)
        )
        # Update price_vnd/description if not yet migrated (price_vnd still 0)
        c.execute(
            "UPDATE plans SET price_vnd=?,description=? WHERE plan_key=? AND price_vnd=0",
            (price_vnd, description, pk)
        )
    c.commit();c.close()

def q(sql,p=(),fetch=False,one=False):
    with _lock:
        c=get_db()
        try:
            cur=c.execute(sql,p)
            if fetch:return[dict(r) for r in cur.fetchall()]
            if one:r=cur.fetchone();return dict(r) if r else None
            c.commit()
            return cur.lastrowid if 'INSERT' in sql.upper() else cur.rowcount
        finally:c.close()

def log_ev(lv,mod,msg):
    try:q("INSERT INTO logs(level,module,message)VALUES(?,?,?)",(lv,mod,msg[:500]))
    except:pass

# ── PLANS — always loaded from DB (single source of truth) ───────────────────
def get_plans():
    """Return plans dict keyed by plan_key, loaded from DB."""
    try:
        rows=q("SELECT * FROM plans WHERE active=1 ORDER BY days",fetch=True)
        return {r['plan_key']:dict(r) for r in rows} if rows else {}
    except Exception:
        return {}

def _session_cleanup():
    """Background: remove expired API keys and old logs every hour."""
    while True:
        try:
            time.sleep(3600)
            now=datetime.now().isoformat()
            # Notify users whose keys are expiring within 3 days
            if BOT_TOKEN:
                expiring=q("SELECT key_display,expires_at,telegram_id FROM api_keys WHERE expires_at IS NOT NULL AND expires_at > ? AND expires_at < datetime('now','+3 days') AND telegram_id > 0",(now,),fetch=True)
                for kr in (expiring or []):
                    try:
                        exp_dt=datetime.fromisoformat(kr['expires_at'].split('+')[0].rstrip('Z'))
                        days_left=max(0,(exp_dt-datetime.now()).days)
                        _tg_send(kr['telegram_id'],
                            f"⚠️ <b>Key Expiry Warning</b>\n"
                            f"Key: <code>{kr['key_display']}</code>\n"
                            f"Expires: {exp_dt.strftime('%Y-%m-%d')}\n"
                            f"Days Remaining: <b>{days_left}</b>\n\n"
                            f"Renew now — contact admin via bot.")
                    except:pass
            expired=q("DELETE FROM api_keys WHERE expires_at IS NOT NULL AND expires_at < ?", (now,))
            old_logs=q("DELETE FROM logs WHERE id NOT IN (SELECT id FROM logs ORDER BY id DESC LIMIT 5000)")
            old_hist=q("DELETE FROM send_history WHERE created_at < datetime('now','-30 days')")
            if expired or old_logs or old_hist:
                log.info(f"[cleanup] expired_keys={expired} old_logs={old_logs} old_history={old_hist}")
        except Exception as e:
            log.error(f"[cleanup] error: {e}")

# ── REALTIME FILE LOGGING ──────────────────────────────────────────────────────
LOG_DIR = os.path.join(DATA_DIR, 'logs')
os.makedirs(LOG_DIR, exist_ok=True)

# Separate file handlers for send / failed / bounce
import logging.handlers as _lh

def _make_file_logger(name, filename):
    lg = logging.getLogger(f'mailer.{name}')
    lg.setLevel(logging.INFO)
    if not lg.handlers:
        fh = _lh.TimedRotatingFileHandler(
            os.path.join(LOG_DIR, filename),
            when='midnight', backupCount=7, encoding='utf-8'
        )
        fh.setFormatter(logging.Formatter('%(asctime)s %(message)s',
                                           datefmt='%Y-%m-%d %H:%M:%S'))
        lg.addHandler(fh)
    return lg

_log_send   = _make_file_logger('send',   'send.log')
_log_failed = _make_file_logger('failed', 'failed.log')
_log_bounce = _make_file_logger('bounce', 'bounce.log')

def _file_log(kind, recipient, smtp_user, error=''):
    """Write one line to send.log / failed.log / bounce.log in realtime."""
    msg = f"{recipient}  smtp={smtp_user}  err={error or 'ok'}"
    try:
        if   kind == 'send':   _log_send.info(f'[SENT]    {msg}')
        elif kind == 'failed': _log_failed.info(f'[FAILED]  {msg}')
        elif kind == 'bounce': _log_bounce.info(f'[BOUNCE]  {msg}')
    except Exception:
        pass  # never crash the sender on log failure

def hk(k):return hashlib.sha256(k.encode()).hexdigest()

def normalize_key(k):
    """Strip invisible Unicode, newlines, tabs, and surrounding quotes/spaces.
    Apply BEFORE hashing so Python save-side and verify-side always agree.
    This also matches what the browser doLogin() sends after its own cleaning.
    """
    if not k: return ''
    # Remove zero-width & invisible Unicode chars (common in Telegram copy-paste)
    k = re.sub(r'[\u200B\u200C\u200D\uFEFF\u00A0\u202F\u2060\u2028\u2029]', '', k)
    # Remove line/tab/carriage-return chars
    k = re.sub(r'[\r\n\t]', '', k)
    # Strip surrounding whitespace and copy-paste quote artifacts
    k = k.strip().strip('"').strip("'").strip('`').strip()
    return k

def verify(key):
    if not key:return None
    key=normalize_key(key)
    if not key:return None
    if key==ADMIN_KEY:
        return{"key_display":ADMIN_KEY,"is_admin":1,"tier":"admin",
               "expires_at":None,"max_smtp":999999,"max_emails":999999}
    rec=q("SELECT * FROM api_keys WHERE key_hash=?",(hk(key),),one=True)
    if not rec:return None
    if rec['expires_at']:
        try:
            exp_str=rec['expires_at']
            # Strip timezone suffix for naive comparison
            exp_str=exp_str.split('+')[0].rstrip('Z').strip()
            exp_dt=datetime.fromisoformat(exp_str)
            now_dt=datetime.now(timezone.utc).replace(tzinfo=None)
            if exp_dt<now_dt:return None
        except Exception:
            pass  # If parse fails, allow access
    return rec

# ── USER DATA ISOLATION ───────────────────────────────────────────────────────
def _kid(auth):
    """Return the integer key_id for data isolation.
    Admin key has no 'id' row → returns 0.  Customer rows have their DB id."""
    if not auth: return 0
    return int(auth.get('id') or 0)

def _is_admin(auth):
    return bool(auth and auth.get('is_admin'))

def _ufilter(auth):
    """Return (AND snippet, params-tuple) to append to a WHERE clause.
    Admin → no extra filter.  Customer → AND key_id=?"""
    if _is_admin(auth): return ('', ())
    return ('AND key_id=?', (_kid(auth),))

def _uwhere(auth):
    """Return (WHERE snippet, params-tuple) for queries that have no existing WHERE.
    Admin → no filter.  Customer → WHERE key_id=?"""
    if _is_admin(auth): return ('', ())
    return ('WHERE key_id=?', (_kid(auth),))

def spin(t):
    """Process spintax {A|B|C} — works inside HTML without breaking tags.
    Only processes {braces} NOT inside HTML attributes (avoids breaking href etc).
    """
    if not t: return t
    def _s(m):
        opts=[o.strip() for o in m.group(1).split('|')]
        return random.choice(opts) if opts else m.group(0)
    # Process spintax up to 5 levels deep (nested spintax)
    result=t
    for _ in range(5):
        new=re.sub(r'\{([^{}]+)\}',_s,result)
        if new==result:break
        result=new
    return result

class _Strip(HTMLParser):
    def __init__(self):super().__init__();self.t=[]
    def handle_data(self,d):self.t.append(d)
def h2t(h):
    s=_Strip()
    try:s.feed(h);return ''.join(s.t)
    except:return h

DISPOSABLE={'mailinator.com','tempmail.com','guerrillamail.com','throwaway.email',
    'yopmail.com','sharklasers.com','grr.la','maildrop.cc','temp-mail.org',
    'fakeinbox.com','trashmail.com','10minutemail.com','spam4.me','discard.email'}

def clean_list(emails):
    seen,clean,inv,disp,dup=set(),[],[],[],[]
    for e in emails:
        e=e.strip().lower().split(':')[0].split('|')[0].strip()
        if not e or '@' not in e or len(e)>254:inv.append(e);continue
        if e in seen:dup.append(e);continue
        seen.add(e)
        dom=e.split('@')[1]
        if dom in DISPOSABLE:disp.append(e);continue
        if not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$',e):inv.append(e);continue
        clean.append(e)
    return clean,inv,disp,dup

DNSBL=['zen.spamhaus.org','bl.spamcop.net','dnsbl.sorbs.net','b.barracudacentral.org',
       'dnsbl-1.uceprotect.net','psbl.surriel.com','ix.dnsbl.manitu.net','spam.dnsbl.sorbs.net']

def chk_bl(host):
    listed,clean=[],[]
    try:
        try:ip=socket.gethostbyname(host)
        except:return{"host":host,"listed":False,"details":"DNS fail","listed_on":[],"clean_on":[],"ip":""}
        rev='.'.join(reversed(ip.split('.')))
        for bl in DNSBL:
            try:socket.setdefaulttimeout(3);socket.gethostbyname(f"{rev}.{bl}");listed.append(bl)
            except socket.gaierror:clean.append(bl)
            except:pass
            finally:socket.setdefaulttimeout(20)
        return{"host":host,"ip":ip,"listed":bool(listed),"listed_on":listed,"clean_on":clean,
               "details":f"{len(listed)}/{len(DNSBL)} DNSBLs"}
    except Exception as e:
        return{"host":host,"listed":False,"details":str(e)[:60],"listed_on":[],"clean_on":[],"ip":""}

def chk_domain(domain):
    """Check domain: MX, SPF, DNSBL blacklist, basic phishing score."""
    result={"domain":domain,"mx_ok":False,"spf_ok":False,"blacklisted":False,
            "phishing_score":0,"details":[],"checked_at":datetime.now().isoformat()}
    try:
        # MX check
        try:
            socket.setdefaulttimeout(5)
            mx_host=f"mx.{domain}"
            # Simple: check if domain resolves
            ip=socket.gethostbyname(domain)
            result["mx_ok"]=True
            result["details"].append(f"Domain resolves: {ip}")
        except:result["details"].append("Domain DNS fail")
        
        # DNSBL check on domain
        try:
            ip=socket.gethostbyname(domain)
            rev='.'.join(reversed(ip.split('.')))
            bl_hits=[]
            for bl in DNSBL[:4]:  # check 4 major ones
                try:socket.setdefaulttimeout(3);socket.gethostbyname(f"{rev}.{bl}");bl_hits.append(bl)
                except:pass
                finally:socket.setdefaulttimeout(20)
            if bl_hits:
                result["blacklisted"]=True
                result["phishing_score"]+=40
                result["details"].append(f"IP {ip} blacklisted on: {','.join(bl_hits)}")
            else:
                result["details"].append(f"IP {ip} not blacklisted")
        except:pass
        
        # Basic phishing heuristics
        score=0
        phish_kw=['paypal','amazon','google','apple','microsoft','bank','secure','verify','account','login','signin']
        dom_lower=domain.lower()
        hits=[kw for kw in phish_kw if kw in dom_lower]
        if hits:score+=len(hits)*15;result["details"].append(f"Phishing keywords: {','.join(hits)}")
        if len(domain.split('.'))<2:score+=20
        # Suspicious TLDs
        sus_tld=['.tk','.ml','.ga','.cf','.gq','.xyz','.top','.click','.download']
        for t in sus_tld:
            if domain.endswith(t):score+=25;result["details"].append(f"Suspicious TLD: {t}");break
        # Hyphen spam
        if domain.count('-')>2:score+=15;result["details"].append("Many hyphens in domain")
        # Long subdomain
        parts=domain.split('.')
        if max(len(p) for p in parts)>20:score+=10;result["details"].append("Long domain label")
        
        result["phishing_score"]=min(100,score)
        if score>=60:result["details"].append(f"HIGH RISK phishing score: {score}")
        elif score>=30:result["details"].append(f"MEDIUM RISK score: {score}")
        else:result["details"].append(f"Low risk score: {score}")
        
        # Cache result
        try:q("INSERT OR REPLACE INTO domain_check_cache(domain,mx_ok,spf_ok,blacklisted,phishing_score,details,checked_at)VALUES(?,?,?,?,?,?,?)",
               (domain,result["mx_ok"],result["spf_ok"],result["blacklisted"],result["phishing_score"],
                json.dumps(result["details"]),result["checked_at"]))
        except:pass
    except Exception as e:
        result["details"].append(f"Error: {str(e)[:60]}")
    finally:socket.setdefaulttimeout(20)
    return result

WU=[5,10,20,30,50,75,100,150,200,300,400,500,750,1000]
def wu_lim(day):return WU[min(day-1,len(WU)-1)] if day>0 else WU[0]

def fire_hook(event,data):
    try:
        hooks=q("SELECT * FROM webhook_config WHERE active=1",fetch=True)
        for h in hooks:
            evts=h.get('events','all')
            if evts!='all' and event not in evts.split(','):continue
            text=f"<b>Mailer v7</b>\nEvent: {event}\n"
            for k,v in data.items():text+=f"- {k}: {v}\n"
            payload={"event":event,"time":datetime.now().isoformat(),"text":text,**data}
            def _s(url=h['url'],plat=h.get('platform','generic'),p=payload):
                try:
                    import urllib.request
                    if plat=='telegram':body={"text":p.get('text',''),"parse_mode":"HTML"}
                    elif plat=='discord':body={"content":p.get('text',''),"username":"Mailer v7"}
                    else:body=p
                    req=urllib.request.Request(url,data=json.dumps(body).encode(),
                        headers={'Content-Type':'application/json'},method='POST')
                    urllib.request.urlopen(req,timeout=10)
                except:pass
            threading.Thread(target=_s,daemon=True).start()
    except:pass

# ── SMTP ───────────────────────────────────────────────────────────────────────
def smtp_connect(host,port,user,pwd,proxy=None):
    """Connect+login. proxy = {'ip','port','user','pass'} or None."""
    port=int(port)
    ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
    
    if proxy:
        # SOCKS5 proxy via raw socket
        import socks
        s=socks.socksocket()
        s.set_proxy(socks.SOCKS5,proxy['ip'],int(proxy['port']),
                    username=proxy.get('user','') or None,
                    password=proxy.get('pass','') or None)
        s.settimeout(25)
        s.connect((host,port))
        if port==465:
            import ssl as _ssl
            ss=_ssl.wrap_socket(s,server_hostname=host,context=ctx)
            srv=smtplib.SMTP.__new__(smtplib.SMTP)
            srv._host=host;srv.timeout=25
            smtplib.SMTP.__init__(srv)
            srv.sock=ss;srv.file=srv.sock.makefile('rb')
            srv._get_socket=lambda *a,**kw:ss
        else:
            srv=smtplib.SMTP.__new__(smtplib.SMTP)
            srv._host=host;srv.timeout=25
            smtplib.SMTP.__init__(srv)
            srv.sock=s;srv.file=s.makefile('rb')
            if port in(587,25,2525):
                try:srv.starttls(context=ctx);srv.ehlo()
                except:pass
    else:
        if port==465:
            srv=smtplib.SMTP_SSL(host,port,timeout=25,context=ctx)
        else:
            srv=smtplib.SMTP(host,port,timeout=25);srv.ehlo()
            if port in(587,25,2525):
                try:srv.starttls(context=ctx);srv.ehlo()
                except:pass
    
    srv.login(user,pwd)
    return srv

def smtp_connect_simple(host,port,user,pwd):
    """Simple connect without proxy — used for checking."""
    port=int(port)
    ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
    if port==465:
        srv=smtplib.SMTP_SSL(host,port,timeout=12,context=ctx)
    else:
        srv=smtplib.SMTP(host,port,timeout=12);srv.ehlo()
        if port in(587,25,2525):
            try:srv.starttls(context=ctx);srv.ehlo()
            except:pass
    srv.login(user,pwd)
    return srv

def validate_email(e):
    """Basic email format validation."""
    e=(e or '').strip()
    if not e or '@' not in e: return False
    parts=e.split('@')
    return len(parts)==2 and len(parts[0])>0 and '.' in parts[1]

def clean_display_name(n):
    """Clean display name — remove special chars that break headers."""
    if not n: return ''
    # Remove chars that break RFC 2822 display names
    n=re.sub(r'[<>\[\]\(\),:;@\\"]','',n).strip()
    # Limit length
    return n[:64] if n else ''

def _parse_css_rules(css_text):
    """Parse a CSS block into [(selector, {prop: value})] list."""
    rules = []
    # Remove comments
    css = re.sub(r'/\*.*?\*/', '', css_text, flags=re.DOTALL)
    # Drop @keyframes / @media / @font-face blocks entirely — can't inline
    css = re.sub(r'@[a-zA-Z-]+[^{]*\{[^{}]*(?:\{[^{}]*\}[^{}]*)?\}', '', css, flags=re.DOTALL)
    for m in re.finditer(r'([^{@]+)\{([^}]*)\}', css):
        raw_selectors = m.group(1)
        decl_str = m.group(2).strip()
        if not decl_str:
            continue
        # Parse declarations into dict
        props = {}
        for d in decl_str.split(';'):
            d = d.strip()
            if ':' in d:
                pk, _, pv = d.partition(':')
                props[pk.strip().lower()] = pv.strip()
        if not props:
            continue
        for sel in raw_selectors.split(','):
            sel = sel.strip()
            # Skip pseudo-classes/elements and complex combinators
            if sel and not re.search(r'[:+~>]', sel):
                rules.append((sel, props))
    return rules

def inline_css(html):
    """Inline CSS from <style> blocks into element style="" attributes.
    Strips <style> blocks after inlining — required for Gmail / Outlook compat.
    Handles: tag, .class, #id, tag.class selectors.
    Existing inline style="" overrides matched rules.
    """
    if not html:
        return html

    all_rules = []

    def _collect(m):
        all_rules.extend(_parse_css_rules(m.group(1)))
        return ''  # remove the <style> block

    cleaned = re.sub(r'<style[^>]*>(.*?)</style>', _collect,
                     html, flags=re.DOTALL | re.IGNORECASE)

    if not all_rules:
        return html  # nothing to do

    def _apply(m):
        full_tag  = m.group(0)
        tag_name  = m.group(1).lower()
        attrs     = m.group(2)

        # Never touch non-visual / void tags
        if tag_name in {'head', 'meta', 'link', 'title', 'script',
                        'style', 'br', 'hr', 'img', 'input', 'area', 'base'}:
            return full_tag

        # Collect classes and id
        cls_m   = re.search(r'\bclass=["\']([^"\']*)["\']', attrs, re.I)
        classes = set(cls_m.group(1).split()) if cls_m else set()
        id_m    = re.search(r'\bid=["\']([^"\']*)["\']', attrs, re.I)
        elem_id = id_m.group(1) if id_m else None

        # Accumulate matched props (later rules override earlier ones)
        merged = {}
        for sel, props in all_rules:
            hit = False
            if sel == tag_name:
                hit = True
            elif sel.startswith('.') and sel[1:] in classes:
                hit = True
            elif sel.startswith('#') and sel[1:] == elem_id:
                hit = True
            elif '.' in sel and not sel.startswith('.'):
                t, c = sel.split('.', 1)
                if t == tag_name and c in classes:
                    hit = True
            if hit:
                merged.update(props)

        if not merged:
            return full_tag

        # Let existing inline style win (merge on top)
        exist_m = re.search(r'\bstyle=["\']([^"\']*)["\']', attrs, re.I)
        if exist_m:
            for d in exist_m.group(1).split(';'):
                d = d.strip()
                if ':' in d:
                    pk, _, pv = d.partition(':')
                    merged[pk.strip().lower()] = pv.strip()

        new_style = '; '.join(f'{k}: {v}' for k, v in merged.items() if v)

        if exist_m:
            new_attrs = attrs[:exist_m.start()] + f'style="{new_style}"' + attrs[exist_m.end():]
        else:
            new_attrs = attrs + f' style="{new_style}"'

        return f'<{tag_name}{new_attrs}>'

    result = re.sub(r'<([a-zA-Z][a-zA-Z0-9]*)([^>]*)>', _apply, cleaned)
    return result

def build_msg(fa,fn,to,subj,html,rt=None,attachments=None):
    """Build RFC-compliant email.
    - Inlines all <style> CSS so Gmail/Outlook/Yahoo render correctly
    - base64-encodes the HTML part so SMTP doesn't mangle CSS characters
    - multipart/alternative plain+html fallback
    - optional attachments: [{'filename':str,'data':bytes}]
    """
    # ── Normalise html ─────────────────────────────────────────────────────────
    if not html:
        html = '<p></p>'
    elif not re.search(r'<[a-zA-Z]', html):
        lines = html.split('\n')
        html = ('<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;'
                'font-size:14px;line-height:1.7;color:#222222;max-width:600px;margin:0 auto;">'
                + ''.join(f'<p style="margin:0 0 12px 0">{ln}</p>' if ln.strip() else '<br>' for ln in lines)
                + '</body></html>')

    # ── Inline CSS — converts <style> blocks to style="" attributes ────────────
    html = inline_css(html)

    # Plain text fallback (spam filters + old clients need it)
    plain_text = h2t(html)
    plain_part = MIMEText(plain_text, 'plain', 'utf-8')

    # HTML part — base64 encoded so all CSS chars survive SMTP transport
    html_encoded = base64.b64encode(html.encode('utf-8')).decode('ascii')
    html_part = MIMEText('', 'html', 'utf-8')
    html_part.replace_header('Content-Transfer-Encoding', 'base64')
    html_part.set_payload(html_encoded)

    alt = MIMEMultipart('alternative')
    alt.attach(plain_part)
    # HTML MUST be last per RFC 2046 — clients render last part they understand
    alt.attach(html_part)

    # ── Wrap in multipart/mixed when attachments present ─────────────────────
    if attachments:
        msg = MIMEMultipart('mixed')
        msg.attach(alt)
        for att in attachments:
            fname = att.get('filename', 'attachment')
            fdata = att.get('data', b'')
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(fdata)
            _email_enc.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename="{fname}"')
            msg.attach(part)
    else:
        msg = alt
    
    # Validate/clean from address
    fa=(fa or '').strip()
    if not validate_email(fa):
        # Fallback: extract from 'Name <email>' if needed
        m=re.search(r'<([^>]+)>',fa)
        fa=m.group(1).strip() if m else fa
    if not validate_email(fa): fa='sender@mail.local'
    
    dom=fa.split('@')[1]
    
    # Clean display name — ALWAYS wrap in formataddr for valid RFC header
    fn=clean_display_name(fn or '')
    if fn:
        # formataddr handles proper encoding/quoting
        from_header=formataddr((fn,fa))
    else:
        # No display name — just bare email
        from_header=fa
    
    # Validate to
    to=(to or '').strip()
    
    # Validate subject — prevent header injection
    subj=' '.join((subj or '').strip().splitlines())
    if not subj: subj='(No Subject)'
    
    msg['From']=from_header
    msg['To']=to
    msg['Subject']=subj
    msg['Date']=formatdate(localtime=True)
    msg['Message-ID']=make_msgid(domain=dom)
    msg['MIME-Version']='1.0'
    msg['X-Mailer']=random.choice(['Microsoft Outlook 16.0','Apple Mail 16.6','Thunderbird 115.0'])
    msg['X-Priority']='3'
    
    # Validate reply-to
    if rt:
        rt=(rt or '').strip()
        if validate_email(rt):
            msg['Reply-To']=rt
    
    return msg

def chk_smtp(sid,host,port,user,pwd,te='',proxy=None):
    """Check SMTP account. Optional proxy dict: {ip,port,username,password,type}."""
    r={"id":sid,"status":"die","response_time":0,"error":"","ssl_info":""}
    t0=time.time();srv=None;ssl_p=[]
    try:
        port=int(port)
        ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
        # ── Extended EHLO checks ─────────────────────────────────────────────
        if port==465:
            srv=smtplib.SMTP_SSL(host,port,timeout=10,context=ctx);ssl_p.append("SSL")
        else:
            srv=smtplib.SMTP(host,port,timeout=10);srv.ehlo()
            if port in(587,25,2525,2587):
                try:srv.starttls(context=ctx);srv.ehlo();ssl_p.append("STARTTLS")
                except:ssl_p.append("NO-TLS")
            if not ssl_p:ssl_p.append("PLAIN")
        # ── Check EHLO capabilities ──────────────────────────────────────────
        try:
            caps=srv.esmtp_features
            if caps.get('auth'): ssl_p.append(f"AUTH:{caps['auth'][:20]}")
            if caps.get('size'): r['max_size']=caps['size']
        except: pass
        r["ssl_info"]=" | ".join(ssl_p)
        srv.login(user,pwd)
        if te and '@' in te:
            try:
                msg=MIMEText(f'SMTP OK {host}:{port}','plain','utf-8')
                msg['From']=user;msg['To']=te;msg['Subject']=f'[CHECK] {host}'
                srv.sendmail(user,[te],msg.as_string());r["status"]="live"
            except smtplib.SMTPRecipientsRefused:r["status"]="limited";r["error"]="rcpt_refused"
            except Exception as e:r["status"]="limited";r["error"]=str(e)[:50]
        else:r["status"]="live"
        try:srv.quit()
        except:pass;srv=None
    except smtplib.SMTPAuthenticationError as e:r["error"]=f"AUTH:{str(e)[:80]}"
    except socket.timeout:r["error"]="TIMEOUT"
    except socket.gaierror as e:r["error"]=f"DNS:{str(e)[:50]}"
    except ConnectionRefusedError:r["error"]="REFUSED"
    except Exception as e:r["error"]=f"ERR:{str(e)[:80]}"
    finally:
        r["response_time"]=round(time.time()-t0,2)
        if srv:
            try:srv.quit()
            except:pass
    return r

def chk_wm(sid,url,email,pwd,te=''):
    r={"id":sid,"status":"die","response_time":0,"error":"","server_info":""}
    t0=time.time()
    try:
        host=urlparse(url).hostname or url.split('//')[-1].split(':')[0]
        ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
        for port in[465,587,25]:
            try:
                if port==465:srv=smtplib.SMTP_SSL(host,port,timeout=15,context=ctx)
                else:
                    srv=smtplib.SMTP(host,port,timeout=15);srv.ehlo()
                    if port==587:
                        try:srv.starttls(context=ctx);srv.ehlo()
                        except:pass
                srv.login(email,pwd);r["status"]="live";r["server_info"]=f"{host}:{port}"
                if te and '@' in te:
                    try:
                        msg=MIMEText(f'WM Check {email}','plain')
                        msg['From']=email;msg['To']=te;msg['Subject']=f'[WM] {email}'
                        srv.sendmail(email,[te],msg.as_string());r["server_info"]+=" SEND OK"
                    except Exception as se:r["server_info"]+=f" FAIL:{str(se)[:30]}";r["status"]="limited"
                try:srv.quit()
                except:pass;break
            except:continue
        if r["status"]=="die" and not r["error"]:r["error"]="ALL_PORTS_FAIL"
    except Exception as e:r["error"]=str(e)[:60]
    finally:r["response_time"]=round(time.time()-t0,2)
    return r

# ── SENDER ─────────────────────────────────────────────────────────────────────
SS={"running":False,"cancelled":False,"paused":False,"sent":0,"failed":0,"limited":0,
    "pending":0,"total":0,"speed":0,"active_smtp":0,"start_time":0,
    "logs":[],"sent_list":[],"failed_list":[],"campaign":"","cur_smtp":"",
    "threads":1,"bounce":0,"batch_size":0,"batch_sent":0,"daily_sent":0,
    "hourly_sent":0,"retry_queue":0,"auto_paused":False}

def rst_ss():
    global SS
    SS={"running":False,"cancelled":False,"paused":False,"sent":0,"failed":0,"limited":0,
        "pending":0,"total":0,"speed":0,"active_smtp":0,"start_time":0,
        "logs":[],"sent_list":[],"failed_list":[],"campaign":"","cur_smtp":"",
        "threads":1,"bounce":0,"batch_size":0,"batch_sent":0,"daily_sent":0,
        "hourly_sent":0,"retry_queue":0,"auto_paused":False}

# ── ATTACHMENT STORE ──────────────────────────────────────────────────────────
# Holds uploaded attachment data keyed by a short attach_id.
# Each entry auto-expires after 2 h so memory is not leaked.
_pending_attach = {}    # {attach_id: {'filename': str, 'data': bytes}}
_attach_lock = threading.Lock()
_ATTACH_ALLOWED = {'.pdf','.png','.jpg','.jpeg','.webp','.gif'}
_ATTACH_MAX_BYTES = 20 * 1024 * 1024   # 20 MB hard cap

def _attach_expire(aid, delay=7200):
    """Background thread: remove attachment from store after `delay` seconds."""
    def _run():
        time.sleep(delay)
        with _attach_lock:
            _pending_attach.pop(aid, None)
    threading.Thread(target=_run, daemon=True).start()

# SMTP check stop flag + live stats
smtp_check_stop=threading.Event()
CS={"running":False,"total":0,"checked":0,"live":0,"dead":0,"failed":0,"limited":0}

def rst_cs():
    global CS
    CS={"running":False,"total":0,"checked":0,"live":0,"dead":0,"failed":0,"limited":0}

def sender_worker(cfg):
    """
    Sender Engine v2 — queue-based multi-thread bulk mailer:
    - Queue worker đa luồng, không treo web
    - Retry 3 lần cho lỗi 421/450/452 (rate-limit/temp)
    - 550/535 → mark die, rotate SMTP ngay
    - Random delay 1.5–4s giữa mỗi mail (configurable)
    - Rotate nhiều SMTP live theo vòng lặp round-robin
    - Ghi realtime: send.log / failed.log / bounce.log
    """
    global SS
    smtp_pool   = cfg.get('smtp_list',[])
    emails      = cfg.get('emails',[])
    rec_names   = cfg.get('rec_names',{})
    subjects    = cfg.get('subjects',['No Subject'])
    letters     = cfg.get('letters',['<p>Hello</p>'])
    from_name   = cfg.get('from_name','')
    from_email  = cfg.get('from_email','')
    reply_to    = cfg.get('reply_to','')
    delay_min   = float(cfg.get('delay_min',1.5))   # default 1.5s
    delay_max   = float(cfg.get('delay_max',4.0))   # default 4.0s
    mails_per   = int(cfg.get('mails_per_smtp',50))
    campaign    = cfg.get('campaign','')
    _sender_kid = int(cfg.get('key_id', 0))   # user isolation
    proxy_list     = cfg.get('proxy_list',[])
    use_proxy      = cfg.get('use_proxy',False) and len(proxy_list)>0
    threads        = min(int(cfg.get('threads',1)),10)
    batch_size     = int(cfg.get('batch_size',0))       # 0 = no batch limit
    batch_delay    = float(cfg.get('batch_delay',30))   # seconds between batches
    daily_limit    = int(cfg.get('daily_limit',0))      # 0 = unlimited
    hourly_limit   = int(cfg.get('hourly_limit',0))     # 0 = unlimited
    from_names     = cfg.get('from_names',[])           # list for randomization
    bounce_pause   = cfg.get('bounce_pause',False)      # auto-pause on bounce
    bounce_thresh  = int(cfg.get('bounce_thresh',10))   # pause after N bounces
    retry_delay    = float(cfg.get('retry_delay',30))   # retry queue delay
    _retry_q       = deque()                            # failed emails for retry
    _retry_lock    = threading.Lock()

    # ── Attachment ──────────────────────────────────────────────────────────────
    _attachments = None
    _aid = cfg.get('attach_id','').strip()
    if _aid:
        with _attach_lock:
            _att = _pending_attach.get(_aid)
        if _att:
            _attachments = [{'filename': _att['filename'], 'data': _att['data']}]
            log.info(f"[sender] attachment loaded: {_att['filename']} ({len(_att['data'])} bytes)")
        else:
            log.warning(f"[sender] attach_id={_aid!r} not found — sending without attachment")

    queue=deque(emails)
    n=len(smtp_pool)
    if n==0:SS["running"]=False;return

    proxy_idx=0
    smtp_idx=0
    _q_lock=threading.Lock()

    def _slog(to,su,st,err,rt=0):
        ts=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry={"time":datetime.now().strftime("%H:%M:%S"),"to":to,"smtp":su,"status":st,"error":err,"rt":rt}
        with _q_lock:
            SS["logs"].insert(0,entry)
            if len(SS["logs"])>500:SS["logs"]=SS["logs"][:500]
        # Enhanced file log with full timestamp
        _kind='send' if st=='sent' else ('bounce' if 'bounce' in st or '55' in str(err) else 'failed')
        if to:_file_log(_kind,to,su,err)
        try:q("INSERT INTO send_history(key_id,recipient,smtp_user,status,error,response_time,campaign)VALUES(?,?,?,?,?,?,?)",(_sender_kid,to,su,st,err,rt,campaign))
        except:pass
        # Auto-send debug to Telegram on FAILURE/BOUNCE/TIMEOUT/BLOCKED
        if to and st not in('sent','rotate','batch','limit') and BOT_TOKEN and ADMIN_TG:
            status_icon="❌" if 'fail' in st else ("🔄" if 'bounce' in st else ("⏱️" if 'timeout' in st else "🚫"))
            err_upper=str(err).upper()
            status_display=("BLOCKED" if any(x in err_upper for x in ('535','AUTH','BLOCKED')) else
                           ("TIMEOUT" if 'timeout' in st or 'TIMEOUT' in err_upper else
                           ("BOUNCE"  if 'bounce' in st or '55' in str(err) else "FAILED")))
            debug_text=(
                f"{status_icon} <b>Sender Debug Alert</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"Recipient: <code>{to}</code>\n"
                f"Status: <b>{status_display}</b>\n"
                f"SMTP: <code>{su}</code>\n"
                f"Error: <code>{str(err)[:120]}</code>\n"
                f"Timestamp: {ts}\n"
                f"Campaign: {campaign or '—'}"
            )
            _tg_send(ADMIN_TG, debug_text)

    def _die(user):
        try:q("UPDATE smtp SET health_score=MAX(0,health_score-10),status='die' WHERE username=?",(user,))
        except:pass

    def _ok(user):
        try:q("UPDATE smtp SET health_score=MIN(100,health_score+1) WHERE username=?",(user,))
        except:pass

    def get_proxy():
        nonlocal proxy_idx
        if not use_proxy or not proxy_list:return None
        p=proxy_list[proxy_idx%len(proxy_list)];proxy_idx+=1
        return p

    def send_thread(smtp_s):
        """Queue-worker thread: drain shared queue with 3-retry + SMTP rotation."""
        nonlocal smtp_idx
        s = smtp_s            # current SMTP dict for this thread
        srv = None            # persistent SMTP connection (reuse across emails)
        sent_on_cur = 0       # count sent on current SMTP (for rotation)

        def _rotate_smtp(reason=''):
            """Move to next live SMTP in pool, log reason."""
            nonlocal s, srv, sent_on_cur
            if srv:
                try: srv.quit()
                except: pass
                srv = None
            with _q_lock:
                smtp_idx_ref = smtp_pool.index(s) if s in smtp_pool else 0
                # Find next non-dead SMTP
                for offset in range(1, n + 1):
                    candidate = smtp_pool[(smtp_idx_ref + offset) % n]
                    if candidate.get('status') != 'die':
                        s = candidate
                        break
            sent_on_cur = 0
            if reason:
                _slog('', s.get('user', '?'), 'rotate', reason[:80])

        while not SS["cancelled"]:
            # ── Pause / auto-pause support ─────────────────────────────────────
            while (SS.get("paused") or SS.get("auto_paused")) and not SS["cancelled"]:
                time.sleep(0.5)

            # ── Daily / hourly limits ─────────────────────────────────────────
            if daily_limit > 0 and SS["daily_sent"] >= daily_limit:
                log.info(f"[sender] Daily limit {daily_limit} reached — pausing")
                SS["auto_paused"] = True
                _slog("","","limit",f"Daily limit {daily_limit} reached")
                break
            if hourly_limit > 0 and SS["hourly_sent"] >= hourly_limit:
                log.info(f"[sender] Hourly limit {hourly_limit} reached — pausing 1h")
                SS["auto_paused"] = True
                time.sleep(3600)
                SS["hourly_sent"] = 0
                SS["auto_paused"] = False

            # ── Batch pause ──────────────────────────────────────────────────
            if batch_size > 0 and SS["batch_sent"] >= batch_size:
                log.info(f"[sender] Batch {batch_size} done — waiting {batch_delay}s")
                _slog("","","batch",f"Batch {batch_size} sent — pausing {batch_delay}s")
                SS["batch_sent"] = 0
                time.sleep(batch_delay)
            # ── Pick next email from shared queue ────────────────────────────
            with _q_lock:
                if not queue: break
                to = queue.popleft()

            t0 = time.time()
            # Resolve from_email: smtp identity > campaign setting > username
            fa  = (s.get('from_email','') or from_email or s['user']).strip()
            if not validate_email(fa): fa = s['user']  # always fallback to valid addr
            fn  = random.choice(from_names) if from_names else (s.get('from_name','') or from_name)
            rt_ = s.get('reply_to','')   or reply_to
            subj = spin(random.choice(subjects))
            html = spin(random.choice(letters))
            # ── Dynamic name personalization: replace {{name}} per recipient ──
            _rec_name = rec_names.get(to, 'Customer')
            subj = subj.replace('{{name}}', _rec_name)
            html = html.replace('{{name}}', _rec_name)
            # Build message ONCE with resolved fa — rebuild if SMTPSenderRefused
            msg  = build_msg(fa, fn, to, subj, html, rt_, attachments=_attachments)

            sent = False
            err  = ''
            MAX_RETRY = 3   # retry up to 3× for recoverable errors

            for attempt in range(MAX_RETRY):
                if SS["cancelled"]: break
                try:
                    # ── (Re)connect if needed ─────────────────────────────────
                    if srv is None:
                        # Live debug log format
                        _mode = 'Webmail' if cfg.get('mode') == 'webmail' else 'SMTP'
                        _live_debug = (
                            f"--- {_mode} Live ---\n"
                            f"HOST: {s['host']}\n"
                            f"PORT: {s['port']}\n"
                            f"USER: {s['user']}\n"
                            f"PASS: {'*'*min(len(str(s.get('pass',''))),8)}\n"
                            f"--- DEBUG ---\n"
                            f"DEBUG: Connecting..."
                        )
                        log.info(f"[sender] {_live_debug.replace(chr(10),' | ')}")
                        srv = smtp_connect_simple(s['host'], s['port'],
                                                   s['user'], s['pass'])
                        log.info(f"[sender] CONNECT OK → {s['host']}:{s['port']} user={s['user']}")

                    # ── Send (try from_email, fallback to username) ───────────
                    try:
                        srv.sendmail(fa, [to], msg.as_string())
                    except smtplib.SMTPSenderRefused:
                        # Rebuild msg với username làm From để header khớp envelope
                        _fa_fallback = s['user']
                        _msg_fallback = build_msg(_fa_fallback, fn, to, subj, html, rt_, attachments=_attachments)
                        srv.sendmail(_fa_fallback, [to], _msg_fallback.as_string())

                    sent = True
                    sent_on_cur += 1
                    _ok(s['user'])
                    SS["cur_smtp"] = s['user']
                    # Rotate SMTP if hit mails_per limit
                    if sent_on_cur >= mails_per:
                        _rotate_smtp(f'rotation_after_{sent_on_cur}')
                    break   # success — exit retry loop

                # ── 535 AUTH FAIL → permanent, rotate immediately ─────────────
                except smtplib.SMTPAuthenticationError as e:
                    err = f"535:auth_fail:{str(e)[:50]}"
                    _die(s['user'])
                    try: srv.quit()
                    except: pass
                    srv = None
                    _rotate_smtp('535_auth_fail')
                    break   # auth fail is permanent, no retry same SMTP

                # ── RCPT/DATA errors: 421/450/452 temp, 550/551 bounce ────────
                except (smtplib.SMTPRecipientsRefused, smtplib.SMTPDataError) as e:
                    code = getattr(e, 'smtp_code', 0) or 0
                    err  = f"{code}:{str(e)[:60]}"
                    try: srv.quit()
                    except: pass
                    srv = None

                    if code in (421, 450, 451, 452):
                        # Temporary rate-limit / server busy → retry after backoff
                        backoff = (attempt + 1) * random.uniform(4, 10)
                        log.warning(f"[sender] {code} temp error → retry {attempt+1}/{MAX_RETRY} after {backoff:.1f}s")
                        _slog(to, s.get('user','?'), f'temp_{code}', err)
                        if attempt < MAX_RETRY - 1:
                            time.sleep(backoff)
                            _rotate_smtp(f'{code}_temp')
                            continue
                    elif code in (550, 551, 552, 553, 554):
                        # Permanent bounce → log to bounce.log, don't retry
                        _file_log('bounce', to, s.get('user','?'), err)
                        with _q_lock:
                            SS['bounce'] = SS.get('bounce',0) + 1
                            if bounce_pause and SS['bounce'] >= bounce_thresh:
                                SS['auto_paused'] = True
                                _slog("","","bounce_pause",f"Auto-paused: {SS['bounce']} bounces")
                        SS["limited"] += 1
                        with _q_lock: SS["failed_list"].append(to)
                    break

                # ── SMTP sender refused (wrong from addr) ─────────────────────
                except smtplib.SMTPSenderRefused as e:
                    err = f"sender_refused:{str(e)[:60]}"
                    try: srv.quit()
                    except: pass
                    srv = None
                    # Rebuild msg with username as from and retry once
                    if attempt == 0:
                        fa = s['user']
                        msg = build_msg(fa, fn, to, subj, html, rt_, attachments=_attachments)
                        continue
                    break

                # ── Disconnected mid-session → reconnect and retry ────────────
                except smtplib.SMTPServerDisconnected:
                    err = 'disconnected'
                    srv = None
                    if attempt < MAX_RETRY - 1:
                        time.sleep(random.uniform(1, 3))
                        continue
                    break

                # ── Connection refused → SMTP is dead ────────────────────────
                except ConnectionRefusedError:
                    err = 'conn_refused'
                    srv = None
                    _die(s['user'])
                    _rotate_smtp('conn_refused')
                    break

                # ── Timeout → rotate and retry ───────────────────────────────
                except socket.timeout:
                    err = 'timeout'
                    srv = None
                    if attempt < MAX_RETRY - 1:
                        _rotate_smtp('timeout')
                        continue
                    break

                # ── Generic exception ─────────────────────────────────────────
                except Exception as e:
                    code = getattr(e, 'smtp_code', None)
                    err  = f"{code}:{str(e)[:60]}" if code else str(e)[:70]
                    try: srv.quit()
                    except: pass
                    srv = None
                    break

            # ── Update shared state ───────────────────────────────────────────
            rt2 = round(time.time() - t0, 2)
            with _q_lock:
                if sent:
                    SS["sent"]       += 1
                    SS["batch_sent"] += 1
                    SS["daily_sent"] += 1
                    SS["hourly_sent"]+= 1
                    SS["sent_list"].append(to)
                    _file_log('send', to, s.get('user','?'), '')
                else:
                    if "limit" in err or "rcpt" in err.lower():
                        SS["limited"] += 1
                    else:
                        SS["failed"]  += 1
                    SS["failed_list"].append(to)
                    _file_log('failed', to, s.get('user','?'), err)
                SS["pending"] = len(queue)
                elapsed = time.time() - SS["start_time"]
                done    = SS["sent"] + SS["failed"] + SS["limited"]
                SS["speed"] = round(done / elapsed, 2) if elapsed > 0 else 0

            _slog(to, s.get('user',''), ('sent' if sent else 'failed'), err, rt2)

            # ── Delay between emails: 1.5–4s default, configurable ───────────
            if queue and not SS["cancelled"]:
                if not sent and ('421' in err or '450' in err or '451' in err):
                    time.sleep(random.uniform(8, 15))   # extra backoff after temp error
                else:
                    time.sleep(random.uniform(delay_min, delay_max))

        # Close connection when thread finishes
        if srv:
            try: srv.quit()
            except: pass

    # Start threads — each gets smtp from pool round-robin
    thread_list=[]
    threads_real=min(threads,n,len(emails))
    for i in range(threads_real):
        s=smtp_pool[i%n]
        t=threading.Thread(target=send_thread,args=(s,),daemon=True)
        thread_list.append(t);t.start()
    
    SS['threads']=threads_real
    for t in thread_list:t.join()

    SS["running"]=False;SS["pending"]=0
    log_ev('info','sender',f"Done: {SS['sent']} sent/{SS['failed']} failed/{SS['limited']} limited")
    try:fire_hook('send_complete',{'sent':SS['sent'],'failed':SS['failed'],'campaign':campaign})
    except:pass

# ── BOMB ───────────────────────────────────────────────────────────────────────
BS={"running":False,"cancelled":False,"sent":0,"failed":0,
    "target":"","start_time":0,"smtp_used":0,"speed":0,"logs":[]}

def rst_bs():
    global BS
    BS={"running":False,"cancelled":False,"sent":0,"failed":0,
        "target":"","start_time":0,"smtp_used":0,"speed":0,"logs":[]}

def bomb_worker(cfg):
    global BS
    target    =cfg.get('target','')
    subjects  =cfg.get('subjects',['Hello'])
    letters   =cfg.get('letters',['<p>Hi</p>'])
    from_name =cfg.get('from_name','')
    from_email=cfg.get('from_email','')
    reply_to  =cfg.get('reply_to','')
    limit     =int(cfg.get('limit',0))
    delay_min =float(cfg.get('delay_min',0))
    delay_max =float(cfg.get('delay_max',0.5))

    def _load():
        return[dict(r) for r in q(
            "SELECT host,port,username as user,password as pass,"
            "from_name,from_email,reply_to FROM smtp "
            "WHERE status IN('live','limited') ORDER BY health_score DESC",fetch=True)]

    def _blog(st,err,su):
        BS["logs"].insert(0,{"time":datetime.now().strftime("%H:%M:%S"),"smtp":su,"status":st,"error":err})
        if len(BS["logs"])>300:BS["logs"]=BS["logs"][:300]

    smtp_list=_load()
    if not smtp_list:BS["running"]=False;return
    sidx=0;count=0;dead_streak=0

    while not BS["cancelled"]:
        if limit>0 and count>=limit:break
        if dead_streak>=max(len(smtp_list),5):
            log_ev('warn','bomb','All SMTP dead');break
        if count>0 and count%50==0:
            fresh=_load()
            if fresh:smtp_list=fresh;dead_streak=0
        s=smtp_list[sidx%len(smtp_list)];sidx+=1;user=s['user']
        subj=spin(random.choice(subjects));body=spin(random.choice(letters))
        fa=s.get('from_email','') or from_email or user
        fn=s.get('from_name','') or from_name
        rt=s.get('reply_to','') or reply_to
        msg=build_msg(fa,fn,target,subj,body,rt)
        try:
            srv=smtp_connect_simple(s['host'],s['port'],user,s['pass'])
            dead_streak=0
            try:
                try:srv.sendmail(fa,[target],msg.as_string())
                except smtplib.SMTPSenderRefused:srv.sendmail(user,[target],msg.as_string())
                BS["sent"]+=1;_blog("sent","",user)
                try:q("UPDATE smtp SET health_score=MIN(100,health_score+1) WHERE username=?",(user,))
                except:pass
            except Exception as e:
                BS["failed"]+=1;_blog("failed",str(e)[:60],user)
            finally:
                try:srv.quit()
                except:pass
        except Exception as e:
            BS["failed"]+=1;dead_streak+=1
            _blog("smtp_fail",str(e)[:60],user)
            try:q("UPDATE smtp SET health_score=MAX(0,health_score-5),status='die' WHERE username=?",(user,))
            except:pass
        count+=1;BS["smtp_used"]=sidx
        el=time.time()-BS["start_time"]
        BS["speed"]=round(count/el,2) if el>0 else 0
        if delay_max>0:time.sleep(random.uniform(delay_min,delay_max))
    BS["running"]=False
    log_ev('info','bomb',f"Bomb done:{BS['sent']} sent to {target}")

# ── SCHEDULE ───────────────────────────────────────────────────────────────────
def sched_worker():
    while True:
        try:
            now=datetime.now().isoformat()
            rows=q("SELECT * FROM schedules WHERE status='pending' AND run_at<=? ORDER BY run_at",(now,),fetch=True)
            for s in rows:
                try:
                    cfg=json.loads(s['config'])
                    q("UPDATE schedules SET status='running' WHERE id=?",(s['id'],))
                    sl=[dict(r) for r in q("SELECT host,port,username as user,password as pass,from_name,from_email,reply_to FROM smtp WHERE status IN('live','limited') ORDER BY health_score DESC",fetch=True)]
                    if sl:
                        cfg['smtp_list']=sl;rst_ss()
                        SS.update({"running":True,"total":len(cfg.get('emails',[])),"pending":len(cfg.get('emails',[])),"start_time":time.time()})
                        t=threading.Thread(target=sender_worker,args=(cfg,),daemon=True);t.start();t.join()
                    rep=s.get('repeat','once')
                    if rep=='daily':
                        nr=(datetime.fromisoformat(s['run_at'])+timedelta(days=1)).isoformat()
                        q("UPDATE schedules SET status='pending',run_at=? WHERE id=?",(nr,s['id']))
                    elif rep=='weekly':
                        nr=(datetime.fromisoformat(s['run_at'])+timedelta(weeks=1)).isoformat()
                        q("UPDATE schedules SET status='pending',run_at=? WHERE id=?",(nr,s['id']))
                    else:q("UPDATE schedules SET status='done' WHERE id=?",(s['id'],))
                except Exception as e:
                    q("UPDATE schedules SET status='error' WHERE id=?",(s['id'],))
                    log_ev('error','scheduler',str(e)[:100])
        except:pass
        time.sleep(30)

def warmup_worker(smtp_id,test_emails):
    try:
        smtp=q("SELECT * FROM smtp WHERE id=?",(smtp_id,),one=True)
        if not smtp:return
        sess=q("SELECT * FROM warmup_sessions WHERE smtp_id=?",(smtp_id,),one=True)
        if not sess:
            q("INSERT INTO warmup_sessions(smtp_id,day,emails_today,target_today)VALUES(?,1,0,?)",(smtp_id,WU[0]))
            sess=q("SELECT * FROM warmup_sessions WHERE smtp_id=?",(smtp_id,),one=True)
        day=sess['day'];target=wu_lim(day);sent=0
        try:srv=smtp_connect_simple(smtp['host'],smtp['port'],smtp['username'],smtp['password'])
        except Exception as e:log_ev('error','warmup',f"Conn:{e}");return
        for i in range(min(target,len(test_emails))):
            to=test_emails[i%len(test_emails)]
            try:
                msg=MIMEMultipart('alternative')
                msg['From']=smtp['username'];msg['To']=to
                msg['Subject']=f"Warm-up Day {day} #{i+1}"
                msg['Date']=formatdate(localtime=True);msg['Message-ID']=make_msgid()
                msg.attach(MIMEText(f"<p>Warm-up #{i+1} day {day}.</p>",'html','utf-8'))
                srv.sendmail(smtp['username'],[to],msg.as_string());sent+=1
                time.sleep(random.uniform(60,180))
            except Exception as e:log_ev('warn','warmup',f"Fail:{e}");break
        try:srv.quit()
        except:pass
        q("UPDATE warmup_sessions SET day=?,emails_today=?,target_today=?,last_run=? WHERE smtp_id=?",
          (day+1,sent,wu_lim(day+1),datetime.now().isoformat(),smtp_id))
        log_ev('info','warmup',f"Day {day}:{sent}/{target}")
    except Exception as e:log_ev('error','warmup',str(e))

# ── TELEGRAM BOT ───────────────────────────────────────────────────────────────
_bot_pending={}

def _tg(method,**kw):
    import urllib.request,urllib.error
    url=f"https://api.telegram.org/bot{BOT_TOKEN}/{method}"
    data=json.dumps({k:v for k,v in kw.items() if v is not None}).encode()
    req=urllib.request.Request(url,data=data,headers={'Content-Type':'application/json'},method='POST')
    try:r=urllib.request.urlopen(req,timeout=15);return json.loads(r.read())
    except:return None

def _tg_send(chat_id, text, parse_mode='HTML'):
    """Send a Telegram message to any chat_id — fire-and-forget in background thread."""
    if not BOT_TOKEN or not chat_id:return
    def _do():
        _tg('sendMessage',chat_id=chat_id,text=text,parse_mode=parse_mode)
    threading.Thread(target=_do,daemon=True).start()

def _tg_get_live_text(include_proxy=True):
    """Build live SMTP/Webmail/Proxy summary text for Telegram delivery."""
    smtp_rows=q("SELECT host,port,username,from_email FROM smtp WHERE status='live' ORDER BY health_score DESC LIMIT 20",fetch=True)
    wm_rows=q("SELECT url,email FROM webmail WHERE status='live' LIMIT 10",fetch=True)
    lines=["<b>SMTP LIVE</b>"]
    if smtp_rows:
        for r in smtp_rows:
            fa=r.get('from_email','') or r['username']
            lines.append(f"  <code>{r['host']}|{r['port']}|{r['username']}</code>")
    else:
        lines.append("  (none)")
    lines.append("")
    lines.append("<b>WEBMAIL LIVE</b>")
    if wm_rows:
        for r in wm_rows:
            lines.append(f"  <code>{r['url']}|{r['email']}</code>")
    else:
        lines.append("  (none)")
    if include_proxy:
        px_rows=q("SELECT ip,port FROM proxy WHERE status='live' LIMIT 10",fetch=True)
        lines.append("")
        lines.append("<b>PROXY LIVE</b>")
        if px_rows:
            for r in px_rows:
                lines.append(f"  <code>{r['ip']}:{r['port']}</code>")
        else:
            lines.append("  (none)")
    return "\n".join(lines)

def _tg_kb_plans():
    plans=get_plans()
    return{"inline_keyboard":[
        [{"text":f"{p['name']}  —  {p['price']} / {p['dur']}","callback_data":f"plan:{k}"}]
        for k,p in plans.items()
    ]}

def _tg_kb_confirm(pk):
    return{"inline_keyboard":[
        [{"text":"✅ I sent payment — Submit screenshot","callback_data":f"confirm:{pk}"}],
        [{"text":"❌ Cancel","callback_data":"cancel"}]
    ]}

def _tg_kb_admin(uid,pk):
    return{"inline_keyboard":[[
        {"text":"✅ Confirm + Gen Key","callback_data":f"ok:{uid}:{pk}"},
        {"text":"❌ Reject","callback_data":f"no:{uid}"}
    ]]}

def _make_unique_key():
    """Generate a unique MAILER-XXXXXXXXXXXXXXXX key (16 uppercase alphanum chars)."""
    for _ in range(10):
        raw="MAILER-"+"".join(random.choices("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ",k=16))
        key=normalize_key(raw)   # always clean before save
        exists=q("SELECT 1 FROM api_keys WHERE key_display=?",(key,),one=True)
        if not exists:
            return key
    raise RuntimeError("Key generation collision after 10 retries")

def _bot_gen_key(pk,creator="bot"):
    plans=get_plans()
    p=plans.get(pk)
    if not p:
        return None, f"Unknown plan: {pk}"
    try:
        key=_make_unique_key()
        exp=(datetime.now(timezone.utc)+timedelta(days=p['days'])).replace(tzinfo=None,microsecond=0).isoformat()
        q("INSERT INTO api_keys(key_hash,key_display,is_admin,tier,expires_at,created_by,max_smtp,max_emails)VALUES(?,?,0,?,?,?,999999,999999)",
          (hk(key),key,p['tier'],exp,creator))
        # Verify it was actually stored
        stored=q("SELECT id FROM api_keys WHERE key_display=?",(key,),one=True)
        if not stored:
            return None,"Key write verification failed"
        return key,datetime.fromisoformat(exp).strftime("%Y-%m-%d")
    except Exception as e:
        log.error(f"[gen_key] error: {e}")
        return None,str(e)

def _handle_bot_update(upd):
    if 'message' in upd:
        msg=upd['message'];cid=msg['chat']['id'];uid=msg['from']['id']
        text=msg.get('text','');fname=msg['from'].get('first_name','')
        plans=get_plans()

        if text.startswith('/start') or text.startswith('/help'):
            plan_lines="\n".join(f"  {p['name']} — <b>{p['price']}</b> / {p['dur']}" for p in plans.values())
            welcome = (
                f"👋 Hello <b>{fname}</b>!\n\n"
                f"Welcome to <b>MAILER v7 PRO</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n"
                f"Professional bulk email sender\n\n"
                f"📦 <b>Plans:</b>\n{plan_lines}\n\n"
                f"💳 <b>Payment:</b> USDT BEP20 (BSC)\n"
                f"<code>{USDT_ADDR}</code>\n\n"
                f"👇 Choose a plan to purchase:"
            )
            _tg('sendMessage',chat_id=cid,parse_mode='HTML',
                text=welcome,reply_markup=json.dumps(_tg_kb_plans()))

        elif text.startswith('/price') or text.startswith('/buy') or text.startswith('/plans') or text.startswith('/muon'):
            plan_lines="\n\n".join(
                f"📦 <b>{p['name']}</b>  —  <b>{p['price']}</b>  /  {p['dur']}"
                for p in plans.values()
            )
            price_text=(
                f"💰 <b>MAILER v7 PRO — Pricing</b>\n"
                f"━━━━━━━━━━━━━━━━━━━━\n\n"
                f"{plan_lines}\n\n"
                f"💳 Payment: USDT BEP20 (BSC)\n"
                f"<code>{USDT_ADDR}</code>"
            )
            _tg('sendMessage',chat_id=cid,parse_mode='HTML',text=price_text,
                reply_markup=json.dumps(_tg_kb_plans()))

        elif text.startswith('/getlive'):
            parts=text.split();lookup_id=parts[1].strip() if len(parts)>1 else str(uid)
            # Find key by telegram_id or by order ID
            try:
                tg_target=int(lookup_id)
            except:tg_target=0
            key_row=None
            if tg_target:
                key_row=q("SELECT key_display,expires_at,created_at,tier FROM api_keys WHERE telegram_id=? ORDER BY id DESC LIMIT 1",(tg_target,),one=True)
            if not key_row:
                # Try treating as key display partial match
                key_row=q("SELECT key_display,expires_at,created_at,tier,telegram_id FROM api_keys WHERE key_display LIKE ? ORDER BY id DESC LIMIT 1",(f"%{lookup_id}%",),one=True)
            if not key_row:
                _tg('sendMessage',chat_id=cid,text="❌ No key found for that ID.\nMake sure you bought a key first via this bot.")
                return
            # Only allow if requester IS the linked TG ID or is admin
            key_tg=key_row.get('telegram_id',0) or tg_target
            if uid!=ADMIN_TG and uid!=key_tg:
                _tg('sendMessage',chat_id=cid,text="❌ You can only view your own live accounts.")
                return
            exp=key_row.get('expires_at','?')
            try:
                exp_dt=datetime.fromisoformat(str(exp).split('+')[0].rstrip('Z'))
                days_left=max(0,(exp_dt-datetime.now()).days)
                exp_str=exp_dt.strftime('%Y-%m-%d')
            except:days_left='?';exp_str=str(exp)[:10]
            k_disp=key_row.get('key_display','?')
            smtp_live=q("SELECT COUNT(*) as c FROM smtp WHERE status='live'",fetch=True)[0]['c']
            wm_live=q("SELECT COUNT(*) as c FROM webmail WHERE status='live'",fetch=True)[0]['c']
            px_live=q("SELECT COUNT(*) as c FROM proxy WHERE status='live'",fetch=True)[0]['c']
            live_text=_tg_get_live_text()
            _tg('sendMessage',chat_id=cid,parse_mode='HTML',
                text=(f"📦 <b>Your Live Accounts</b>\n"
                      f"━━━━━━━━━━━━━━━━━━━━\n"
                      f"🔑 KEY STATUS\n"
                      f"Key: <code>{k_disp}</code>\n"
                      f"Expiry: <b>{exp_str}</b>\n"
                      f"Days Remaining: <b>{days_left}</b>\n"
                      f"Status: <b>{'Active' if str(days_left).isdigit() and int(str(days_left))>0 else 'Expired'}</b>\n\n"
                      f"📊 SMTP Live: <b>{smtp_live}</b> | Webmail: <b>{wm_live}</b> | Proxy: <b>{px_live}</b>\n\n"
                      f"{live_text}"))

        elif text.startswith('/mykey'):
            # Let user link their key to their telegram ID
            parts=text.split(None,1)
            if len(parts)<2:
                _tg('sendMessage',chat_id=cid,text="Usage: /mykey MAILER-XXXXXXXXXXXXXXXX")
                return
            user_key=parts[1].strip()
            from hashlib import sha256 as _sha256
            kh_=sha256(user_key.encode()).hexdigest() if hasattr(sha256,'__call__') else ''
            kh_=hashlib.sha256(user_key.encode()).hexdigest()
            rec_=q("SELECT id,expires_at FROM api_keys WHERE key_hash=?",(kh_,),one=True)
            if not rec_:
                _tg('sendMessage',chat_id=cid,text="❌ Key not found or invalid.")
                return
            q("UPDATE api_keys SET telegram_id=? WHERE id=?",(uid,rec_['id']))
            exp_=rec_.get('expires_at','?')[:10]
            _tg('sendMessage',chat_id=cid,parse_mode='HTML',
                text=f"✅ Key linked to your Telegram!\nKey: <code>{user_key}</code>\nExpiry: {exp_}\n\nUse /getlive to get live accounts anytime.")

        elif text.startswith('/genkey') and uid==ADMIN_TG:
            parts=text.split();pk=parts[1].lower() if len(parts)>1 else 'pro'
            if pk not in plans:
                _tg('sendMessage',chat_id=cid,text=f"Unknown plan. Use: {', '.join(plans)}")
                return
            key,exp=_bot_gen_key(pk,'admin_manual')
            p=plans[pk]
            if key:
                _tg('sendMessage',chat_id=cid,parse_mode='HTML',
                    text=f"✅ Key generated\nPlan: <b>{p['name']}</b> / {p['dur']}\n"
                         f"Key: <code>{key}</code>\nExpires: {exp}")
            else:_tg('sendMessage',chat_id=cid,text=f"Error: {exp}")

        elif text.startswith('/reply') and uid==ADMIN_TG:
            parts=text.split(None,2)
            if len(parts)<3:
                _tg('sendMessage',chat_id=cid,text="Usage: /reply <user_id> <message>");return
            try:
                target=int(parts[1]);reply_msg=parts[2]
                _tg('sendMessage',chat_id=target,parse_mode='HTML',
                    text=f"📨 <b>Admin:</b>\n{reply_msg}")
                _tg('sendMessage',chat_id=ADMIN_TG,text=f"✅ Reply sent to {target}")
            except Exception as e:
                _tg('sendMessage',chat_id=cid,text=f"Error: {e}")

        elif text.startswith('/stopchat') and uid==ADMIN_TG:
            # Admin can stop receiving messages from a user
            target_text=text.split(None,1)[1] if len(text.split())>1 else ''
            if target_text.lstrip('-').isdigit():
                target=int(target_text)
                try:
                    _tg('sendMessage',chat_id=target,text="The admin has stopped this conversation. For further inquiries, contact via @RedxMails_Bot")
                    _tg('sendMessage',chat_id=ADMIN_TG,text=f"✅ Sent stop message to {target}")
                except Exception as e:
                    _tg('sendMessage',chat_id=ADMIN_TG,text=f"Error: {e}")
            else:
                _tg('sendMessage',chat_id=ADMIN_TG,text="Usage: /stopchat <user_id>")

        elif text.startswith('/stats') and uid==ADMIN_TG:
            try:
                total=q("SELECT COUNT(*) as c FROM api_keys",fetch=True)[0]['c']
                active=q("SELECT COUNT(*) as c FROM api_keys WHERE(expires_at IS NULL OR expires_at>?)",(datetime.now().isoformat(),),fetch=True)[0]['c']
                slive=q("SELECT COUNT(*) as c FROM smtp WHERE status='live'",fetch=True)[0]['c']
                stot=q("SELECT COUNT(*) as c FROM send_history WHERE status='sent'",fetch=True)[0]['c']
                _tg('sendMessage',chat_id=cid,parse_mode='HTML',
                    text=f"<b>MAILER v7 Stats</b>\n\nKeys: {total} / {active} active\n"
                         f"SMTP live: {slive}\nTotal sent: {stot}")
            except Exception as e:_tg('sendMessage',chat_id=cid,text=f"Error: {e}")

        elif 'photo' in msg:
            pk=_bot_pending.get(uid)
            uname=f"@{msg['from'].get('username','')}" if msg['from'].get('username') else fname
            if not pk:
                # Forward general photo to admin
                _tg('forwardMessage',chat_id=ADMIN_TG,from_chat_id=cid,message_id=msg['message_id'])
                _tg('sendMessage',chat_id=ADMIN_TG,parse_mode='HTML',
                    text=f"📷 Photo from <b>{uname}</b> (ID: <code>{uid}</code>)",
                    reply_markup=json.dumps({"inline_keyboard":[[
                        {"text":"💬 Reply","callback_data":f"reply:{uid}"},
                        {"text":"🚫 Stop Chat","callback_data":f"stop:{uid}"}
                    ]]}))
                _tg('sendMessage',chat_id=cid,text="📸 Message sent to admin!")
                return
            p=plans.get(pk,{})
            _tg('forwardMessage',chat_id=ADMIN_TG,from_chat_id=cid,message_id=msg['message_id'])
            _tg('sendMessage',chat_id=ADMIN_TG,parse_mode='HTML',
                text=f"💰 Payment from <b>{uname}</b> (ID: <code>{uid}</code>)\n"
                     f"Plan: <b>{p['name']}</b> — {p['price']} / {p['dur']}",
                reply_markup=json.dumps(_tg_kb_admin(uid,pk)))
            _tg('sendMessage',chat_id=cid,text="📸 Screenshot received! Admin will verify shortly.")
        
        elif msg.get('text') and not text.startswith('/'):
            # User asking a question — forward to admin with stop button
            if uid != ADMIN_TG:
                uname=f"@{msg['from'].get('username','')}" if msg['from'].get('username') else fname
                _tg('sendMessage',chat_id=ADMIN_TG,parse_mode='HTML',
                    text=f"💬 Message from <b>{uname}</b> (ID: <code>{uid}</code>):\n\n{text}",
                    reply_markup=json.dumps({"inline_keyboard":[[
                        {"text":"💬 Reply","callback_data":f"reply:{uid}"},
                        {"text":"🚫 Stop Chat","callback_data":f"stop:{uid}"}
                    ]]}))
                _tg('sendMessage',chat_id=cid,
                    text="✅ Your message has been sent to admin. You'll receive a reply shortly.\n"
                         "Use /price to see plans or /start for more info.")

    elif 'callback_query' in upd:
        cb=upd['callback_query'];cid=cb['message']['chat']['id']
        mid=cb['message']['message_id'];uid=cb['from']['id'];data=cb['data']
        plans=get_plans()

        if data.startswith('plan:'):
            pk=data[5:];p=plans.get(pk)
            if not p:_tg('answerCallbackQuery',callback_query_id=cb['id'],text="Unknown plan");return
            _bot_pending[uid]=pk
            _tg('editMessageText',chat_id=cid,message_id=mid,parse_mode='HTML',
                text=f"<b>{p['name']} — {p['price']} / {p['dur']}</b>\n\n"
                     f"Send exactly <b>{p['price']}</b> USDT (BEP20) to:\n"
                     f"<code>{USDT_ADDR}</code>\n\n"
                     f"After sending, press the button below and send your screenshot.",
                reply_markup=json.dumps(_tg_kb_confirm(pk)))
            _tg('answerCallbackQuery',callback_query_id=cb['id'])

        elif data.startswith('confirm:'):
            pk=data[8:];_bot_pending[uid]=pk
            _tg('editMessageText',chat_id=cid,message_id=mid,
                text="📸 Send your payment screenshot in this chat.\nAdmin will verify shortly.")
            _tg('answerCallbackQuery',callback_query_id=cb['id'])

        elif data=='cancel':
            _bot_pending.pop(uid,None)
            _tg('editMessageText',chat_id=cid,message_id=mid,text="Cancelled. Use /start to begin again.")
            _tg('answerCallbackQuery',callback_query_id=cb['id'])

        elif data.startswith('reply:') and uid==ADMIN_TG:
            target_uid=int(data[6:])
            _tg('sendMessage',chat_id=ADMIN_TG,
                text=f"Type your reply to user {target_uid}. Use /reply {target_uid} <message>")
            _tg('answerCallbackQuery',callback_query_id=cb['id'])

        elif data.startswith('stop:') and uid==ADMIN_TG:
            target_uid=int(data[5:])
            try:
                _tg('sendMessage',chat_id=target_uid,
                    text="⛔ Admin has stopped this conversation.\n"
                         "For support, use /start or contact @RedxMails_Bot")
            except:pass
            _tg('editMessageReplyMarkup',chat_id=cid,message_id=mid,reply_markup=json.dumps({"inline_keyboard":[]}))
            _tg('sendMessage',chat_id=ADMIN_TG,text=f"✅ Stopped chat with user {target_uid}")
            _tg('answerCallbackQuery',callback_query_id=cb['id'],text="Chat stopped")

        elif data.startswith('ok:') and uid==ADMIN_TG:
            parts=data.split(':');target_uid=int(parts[1]);pk=parts[2]
            key,exp=_bot_gen_key(pk,f"bot_admin_{ADMIN_TG}")
            if not key:_tg('answerCallbackQuery',callback_query_id=cb['id'],text=f"DB error: {exp}");return
            p=plans.get(pk) or plans.get('pro') or next(iter(plans.values()),{})
            # Store telegram_id against the key
            try:q("UPDATE api_keys SET telegram_id=? WHERE key_display=?",(target_uid,key))
            except:pass
            _tg('sendMessage',chat_id=target_uid,parse_mode='HTML',
                text=f"✅ Payment confirmed!\n\n"
                     f"Thanks for buying <b>MAILER v7 PRO</b>\n\n"
                     f"Plan: <b>{p['name']}</b> — {p['price']}\n"
                     f"Key: <code>{key}</code>\nExpires: {exp}\n\n"
                     f"Enter this key at the login page to activate.\n\n"
                     f"Use /getlive {target_uid} to get your live accounts anytime.")
            _tg('editMessageReplyMarkup',chat_id=cid,message_id=mid,reply_markup=json.dumps({"inline_keyboard":[]}))
            _tg('sendMessage',chat_id=ADMIN_TG,parse_mode='HTML',
                text=f"✅ Key sent to <code>{target_uid}</code>\nKey: <code>{key}</code>\nPlan: {p['name']} / Exp: {exp}")
            _bot_pending.pop(target_uid,None)
            _tg('answerCallbackQuery',callback_query_id=cb['id'],text="Key sent!")
            # Auto-deliver live accounts to user
            live_text=_tg_get_live_text()
            smtp_live=q("SELECT COUNT(*) as c FROM smtp WHERE status='live'",fetch=True)[0]['c']
            wm_live=q("SELECT COUNT(*) as c FROM webmail WHERE status='live'",fetch=True)[0]['c']
            _tg('sendMessage',chat_id=target_uid,parse_mode='HTML',
                text=(f"📦 <b>Your Live Accounts</b>\n"
                      f"━━━━━━━━━━━━━━━━━━━━\n"
                      f"🔑 Key: <code>{key}</code>\n"
                      f"📅 Expiry: <b>{exp}</b>\n"
                      f"📊 SMTP Live: <b>{smtp_live}</b>\n"
                      f"📊 Webmail Live: <b>{wm_live}</b>\n\n"
                      f"{live_text}"))

        elif data.startswith('no:') and uid==ADMIN_TG:
            target_uid=int(data[3:])
            try:_tg('sendMessage',chat_id=target_uid,text="❌ Payment could not be verified.\nPlease send clearer screenshot or contact admin.")
            except:pass
            _tg('editMessageReplyMarkup',chat_id=cid,message_id=mid,reply_markup=json.dumps({"inline_keyboard":[]}))
            _tg('sendMessage',chat_id=ADMIN_TG,text=f"Rejected user {target_uid}")
            _bot_pending.pop(target_uid,None)
            _tg('answerCallbackQuery',callback_query_id=cb['id'],text="Rejected")

def bot_polling():
    offset=None
    log.info("Telegram bot polling started")
    while True:
        try:
            params={"timeout":30,"allowed_updates":["message","callback_query"]}
            if offset:params["offset"]=offset
            res=_tg('getUpdates',**params)
            if res and res.get('ok') and res.get('result'):
                for upd in res['result']:
                    offset=upd['update_id']+1
                    try:_handle_bot_update(upd)
                    except Exception as e:log.error(f"Bot upd err:{e}")
        except Exception as e:
            log.error(f"Bot poll err:{e}")
            time.sleep(5)

# ── HTTP SERVER ────────────────────────────────────────────────────────────────
class H(SimpleHTTPRequestHandler):
    def log_message(self,*a):pass

    def _j(self,d,s=200):
        origin   = self.headers.get('Origin','').rstrip('/')
        cors_org = get_cors_origin(origin)
        is_https = self._detect_https()

        self.send_response(s)
        self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','SAMEORIGIN')
        self.send_header('X-XSS-Protection','1; mode=block')
        self.send_header('Referrer-Policy','strict-origin-when-cross-origin')

        # HSTS — only when actually on HTTPS
        if is_https or BEHIND_HTTPS:
            self.send_header('Strict-Transport-Security','max-age=31536000; includeSubDomains')

        # CORS
        self.send_header('Access-Control-Allow-Origin', cors_org)
        if cors_org != '*':
            # Credentials only when origin is explicitly allowed (not wildcard)
            self.send_header('Access-Control-Allow-Credentials','true')
        self.send_header('Access-Control-Allow-Headers',
                         'Content-Type, X-API-Key, Authorization, X-Requested-With')
        self.send_header('Access-Control-Allow-Methods','GET, POST, DELETE, OPTIONS, PATCH')
        self.send_header('Access-Control-Expose-Headers','X-API-Key')
        self.send_header('Vary','Origin')
        self.send_header('Cache-Control','no-store, no-cache, must-revalidate')

        self.end_headers()
        self.wfile.write(json.dumps(d, default=str).encode())

    def _file(self,data,name,ct='text/plain'):
        self.send_response(200)
        self.send_header('Content-Type',ct)
        self.send_header('Content-Disposition',f'attachment; filename="{name}"')
        self.end_headers();self.wfile.write(data.encode() if isinstance(data,str) else data)

    def _html(self,fp):
        try:
            with open(os.path.join(STATIC_DIR,fp),'rb') as f:data=f.read()
            self.send_response(200)
            ct='text/html; charset=utf-8'
            if fp.endswith('.css'):ct='text/css; charset=utf-8'
            elif fp.endswith('.js'):ct='application/javascript; charset=utf-8'
            self.send_header('Content-Type',ct)
            self.send_header('X-Content-Type-Options','nosniff')
            self.send_header('X-Frame-Options','SAMEORIGIN')
            self.send_header('Referrer-Policy','strict-origin-when-cross-origin')
            self.send_header('Cache-Control','no-store')
            self.end_headers();self.wfile.write(data)
        except FileNotFoundError:self._j({"error":"Not found"},404)

    def _body(self):
        try:
            cl=int(self.headers.get('Content-Length',0) or 0)
        except (ValueError,TypeError):
            cl=0
        if not cl: return {}
        if cl > 10*1024*1024:  # max 10MB body
            self._j({"error":"Request too large"},413)
            return None  # signals caller to abort
        try:
            raw=self.rfile.read(cl)
        except Exception:
            return {}
        try:
            data=json.loads(raw)
        except Exception:
            return {}
        # Sanitize + SQLi check on string values
        try:
            data=sanitize_body(data)
        except ValueError as e:
            ip=_ip(self)
            log.warning(f'SQLi/XSS blocked from {ip}: {e}')
            log_ev('warn','security',f'SQLi blocked from {ip}')
            self._j({"error":"Invalid input"},400)
            return None  # signals caller to abort
        return data

    def _auth(self):
        # Priority: 1) X-API-Key header, 2) Authorization Bearer, 3) query param
        key = self.headers.get('X-API-Key','').strip()
        if not key:
            auth_hdr = self.headers.get('Authorization','')
            if auth_hdr.startswith('Bearer '):
                key = auth_hdr[7:].strip()
        if not key:
            qs = parse_qs(urlparse(self.path).query)
            key = qs.get('key',[''])[0].strip()
        if not key:
            return None
        return verify(key)

    def _detect_https(self):
        """Detect if request came over HTTPS (including behind reverse proxy)."""
        if BEHIND_HTTPS:
            return True
        proto = self.headers.get('X-Forwarded-Proto','')
        if proto.lower() == 'https':
            return True
        return False

    def _sec(self):
        ip=_ip(self);path=urlparse(self.path).path

        # DDoS check (all requests)
        if not sec_ddos(ip):
            try: self._j({"error":"Request blocked"},429)
            except: pass
            return False

        # Path traversal check
        if sec_path_trav(path):
            log.warning(f'Path traversal attempt from {ip}: {path}')
            try: self._j({"error":"Forbidden"},403)
            except: pass
            return False

        # Suspicious header injection
        for hname in ('User-Agent','Referer','X-Forwarded-For'):
            hv=self.headers.get(hname,'')
            if _HDR_RE.search(hv):
                log.warning(f'Header injection attempt from {ip}: {hname}={hv[:60]}')
                try: self._j({"error":"Forbidden"},403)
                except: pass
                return False

        # Rate limit
        if not sec_rate(ip,path):
            try: self._j({"error":"Rate limit exceeded — slow down"},429)
            except: pass
            return False

        return True

    def do_OPTIONS(self):
        origin   = self.headers.get('Origin','').rstrip('/')
        cors_org = get_cors_origin(origin)
        self.send_response(204)
        self.send_header('Access-Control-Allow-Origin', cors_org)
        if cors_org != '*':
            self.send_header('Access-Control-Allow-Credentials','true')
        self.send_header('Access-Control-Allow-Headers',
                         'Content-Type, X-API-Key, Authorization, X-Requested-With')
        self.send_header('Access-Control-Allow-Methods','GET, POST, DELETE, OPTIONS, PATCH')
        self.send_header('Access-Control-Max-Age','86400')
        self.send_header('Vary','Origin')
        self.send_header('Cache-Control','no-store')
        self.end_headers()

    def do_GET(self):
        try:
            self._do_GET_inner()
        except Exception as e:
            log.error(f"[GET] unhandled: {e}")
            try:self._j({"error":"Internal server error"},500)
            except:pass

    def _do_GET_inner(self):
        if not self._sec():return
        path=urlparse(self.path).path;qs=parse_qs(urlparse(self.path).query)
        if path=='/':return self._html('landing.html')
        if path=='/app':return self._html('index.html')
        if path=='/login':return self._html('login.html')
        if path=='/adminlogin':return self._html('admin-login.html')

        # Serve static root image files (.png, .ico, .jpg, .svg, etc.)
        if path.startswith('/static/') and any(path.endswith(ext) for ext in ('.png','.jpg','.jpeg','.gif','.ico','.svg','.webp')):
            rel = path.lstrip('/').replace('static/', '', 1)
            safe_rel = os.path.normpath(rel).replace('\\', '/')
            if '..' in safe_rel:
                return self._j({"error": "Forbidden"}, 403)
            return self._html(safe_rel)

        # Serve static subdirectory files (css/, js/, img/)
        if path.startswith('/static/css/') or path.startswith('/static/js/') or path.startswith('/static/img/'):
            rel = path.lstrip('/').replace('static/', '', 1)
            safe_rel = os.path.normpath(rel).replace('\\', '/')
            if '..' in safe_rel:
                return self._j({"error": "Forbidden"}, 403)
            return self._html(safe_rel)

        auth=self._auth()
        if path.startswith('/api/') and not auth:return self._j({"error":"Auth required"},401)

        if path=='/api/auth/check':
            # Public endpoint — check if a key is valid
            qs2=parse_qs(urlparse(self.path).query)
            k=qs2.get('key',[''])[0].strip()
            if not k:return self._j({"valid":False,"reason":"no key provided"})
            rec=verify(k)
            if not rec:return self._j({"valid":False,"reason":"key not found or expired"})
            return self._j({"valid":True,"tier":rec.get('tier','pro'),"expires":rec.get('expires_at'),"is_admin":rec.get('is_admin',0)})

        if path=='/api/auth/session':
            # Session heartbeat — called on every app load to verify key is still valid
            auth_s=self._auth()
            if not auth_s:
                return self._j({
                    "authenticated":False,
                    "reason":"Key not found, expired, or missing",
                    "code":"SESSION_INVALID"
                },401)
            # Calculate days remaining
            days_left=None
            if auth_s.get('expires_at'):
                try:
                    exp=datetime.fromisoformat(auth_s['expires_at'].split('+')[0].rstrip('Z'))
                    delta=exp-datetime.now(timezone.utc).replace(tzinfo=None)
                    days_left=max(0,delta.days)
                except Exception:
                    pass
            return self._j({
                "authenticated":True,
                "key_display":auth_s['key_display'],
                "is_admin":int(auth_s.get('is_admin',0)),
                "tier":auth_s.get('tier','pro'),
                "expires_at":auth_s.get('expires_at'),
                "days_remaining":days_left,
                "max_smtp":auth_s.get('max_smtp',999999),
            })

        if path=='/api/auth/profile':
            days_left=None;date_added=auth.get('created_at','')
            exp_str=auth.get('expires_at')
            if exp_str:
                try:
                    exp=datetime.fromisoformat(exp_str.split('+')[0].rstrip('Z'))
                    delta=exp-datetime.now(timezone.utc).replace(tzinfo=None)
                    days_left=max(0,delta.days)
                except:pass
            status='Active' if (not exp_str or (days_left is not None and days_left>0)) else 'Expired'
            return self._j({
                "key_display":auth['key_display'],"is_admin":auth['is_admin'],
                "tier":auth.get('tier','pro'),"expires_at":exp_str,
                "date_added":date_added,"days_remaining":days_left,"status":status,
                "max_smtp":auth.get('max_smtp',999999),"max_emails":auth.get('max_emails',999999),
                "telegram_id":auth.get('telegram_id',0),"last_ip":auth.get('last_ip',''),
            })

        if path=='/api/auth/link-telegram':
            tg_id=int((parse_qs(urlparse(self.path).query).get('tg_id',['0'])[0]) or 0)
            if tg_id:
                q("UPDATE api_keys SET telegram_id=? WHERE key_hash=?",(tg_id,hk(auth['key_display'])))
                return self._j({"ok":True,"telegram_id":tg_id})
            return self._j({"error":"tg_id required"},400)

        if path=='/api/stats':
            _uf,_up=_ufilter(auth)
            sT=q(f"SELECT COUNT(*) as c FROM smtp {_uf}",_up,fetch=True)[0]['c']
            sL=q(f"SELECT COUNT(*) as c FROM smtp WHERE status='live' {_uf}",_up,fetch=True)[0]['c']
            sLm=q(f"SELECT COUNT(*) as c FROM smtp WHERE status='limited' {_uf}",_up,fetch=True)[0]['c']
            sD=q(f"SELECT COUNT(*) as c FROM smtp WHERE status='die' {_uf}",_up,fetch=True)[0]['c']
            pT=q(f"SELECT COUNT(*) as c FROM proxy {_uf}",_up,fetch=True)[0]['c']
            pL=q(f"SELECT COUNT(*) as c FROM proxy WHERE status='live' {_uf}",_up,fetch=True)[0]['c']
            mT=q(f"SELECT COUNT(*) as c FROM mail {_uf}",_up,fetch=True)[0]['c']
            wmL=q(f"SELECT COUNT(*) as c FROM webmail WHERE status='live' {_uf}",_up,fetch=True)[0]['c']
            wmT=q(f"SELECT COUNT(*) as c FROM webmail {_uf}",_up,fetch=True)[0]['c']
            hourly=q(f"SELECT strftime('%H',created_at) as hour,status,COUNT(*) as c FROM send_history WHERE created_at>=datetime('now','-24 hours') {_uf} GROUP BY hour,status",_up,fetch=True)
            domain_stats=q(f"SELECT domain,COUNT(*) as count FROM mail {_uf} GROUP BY domain ORDER BY count DESC LIMIT 10",_up,fetch=True)
            total_sent=q(f"SELECT COUNT(*) as c FROM send_history WHERE status='sent' {_uf}",_up,fetch=True)[0]['c']
            total_failed=q(f"SELECT COUNT(*) as c FROM send_history WHERE status='failed' {_uf}",_up,fetch=True)[0]['c']
            # Logs/announcements are global
            return self._j({
                "smtp":{"total":sT,"live":sL,"limited":sLm,"die":sD,"unchecked":sT-sL-sLm-sD},
                "proxy":{"total":pT,"live":pL,"die":pT-pL},
                "mail":{"total":mT},"webmail":{"total":wmT,"live":wmL},
                "domainStats":domain_stats,
                "recentLogs":q("SELECT * FROM logs ORDER BY id DESC LIMIT 20",fetch=True) if _is_admin(auth) else [],
                "announcements":q("SELECT * FROM announcements WHERE active=1 ORDER BY id DESC LIMIT 5",fetch=True),
                "sender":{"running":SS["running"],"sent":SS["sent"],"failed":SS["failed"],"speed":SS["speed"],"cur_smtp":SS.get("cur_smtp","")},
                "bomb":{"running":BS["running"],"sent":BS["sent"],"target":BS["target"]},
                "hourly":hourly,
                "totalSent":total_sent,
                "totalFailed":total_failed,
            })

        if path=='/api/smtp':
            s=qs.get('status',[None])[0]
            # NEVER expose passwords in API response
            _safe_cols="id,host,port,username,status,health_score,ssl_info,response_time,error_msg,from_name,from_email,reply_to,last_checked"
            _uf,_up=_ufilter(auth)
            if s and s!='all':rows=q(f"SELECT {_safe_cols} FROM smtp WHERE status=? {_uf} ORDER BY health_score DESC,id DESC LIMIT 500",(s,)+_up,fetch=True)
            else:rows=q(f"SELECT {_safe_cols} FROM smtp {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY health_score DESC,id DESC LIMIT 500",_up,fetch=True)
            return self._j(rows)
        if path=='/api/smtp/status':
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT status,COUNT(*) as c FROM smtp {_uf.replace('AND','WHERE',1) if _uf else ''} GROUP BY status",_up,fetch=True)
            r={"live":0,"limited":0,"die":0,"pending":0,"unchecked":0}
            for row in rows:
                if row['status'] in r:r[row['status']]=row['c']
            r["running"]=CS["running"];r["checker"]=dict(CS)
            return self._j(r)

        if path=='/api/plans':
            return self._j(list(get_plans().values()))
        if path=='/api/smtp/export':
            # Export includes passwords — require valid auth
            if not auth: return self._j({"error":"Auth required"},401)
            s=qs.get('status',['live'])[0]
            _uf,_up=_ufilter(auth)
            if s!='all':rows=q(f"SELECT * FROM smtp WHERE status=? {_uf} ORDER BY id",(s,)+_up,fetch=True)
            else:rows=q(f"SELECT * FROM smtp {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY id",_up,fetch=True)
            return self._file('\n'.join(f"{r['host']}|{r['port']}|{r['username']}|{r['password']}" for r in rows),f"smtp_{s}.txt")

        if path=='/api/webmail':
            s=qs.get('status',[None])[0]
            _wm_cols="id,url,email,status,server_info,response_time,error_msg,last_checked"
            _uf,_up=_ufilter(auth)
            if s and s!='all':rows=q(f"SELECT {_wm_cols} FROM webmail WHERE status=? {_uf} ORDER BY id DESC LIMIT 500",(s,)+_up,fetch=True)
            else:rows=q(f"SELECT {_wm_cols} FROM webmail {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY id DESC LIMIT 500",_up,fetch=True)
            return self._j(rows)
        if path=='/api/webmail/status':
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT status,COUNT(*) as c FROM webmail {_uf.replace('AND','WHERE',1) if _uf else ''} GROUP BY status",_up,fetch=True)
            r={"live":0,"die":0,"pending":0,"unchecked":0}
            for row in rows:
                if row['status'] in r:r[row['status']]=row['c']
            r["running"]=r["pending"]>0;return self._j(r)

        if path=='/api/proxy':
            s=qs.get('status',[None])[0]
            _uf,_up=_ufilter(auth)
            if s and s!='all':return self._j(q(f"SELECT * FROM proxy WHERE status=? {_uf} ORDER BY id DESC LIMIT 500",(s,)+_up,fetch=True))
            return self._j(q(f"SELECT * FROM proxy {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY id DESC LIMIT 500",_up,fetch=True))
        if path=='/api/proxy/status':
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT status,COUNT(*) as c FROM proxy {_uf.replace('AND','WHERE',1) if _uf else ''} GROUP BY status",_up,fetch=True)
            r={"live":0,"die":0,"pending":0,"unchecked":0}
            for row in rows:
                if row['status'] in r:r[row['status']]=row['c']
            r["running"]=r["pending"]>0;return self._j(r)
        if path=='/api/proxy/export':
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT * FROM proxy WHERE status='live' {_uf} ORDER BY id",_up,fetch=True)
            return self._file('\n'.join(f"{r['ip']}:{r['port']}"+(f":{r['username']}:{r['password']}" if r['username'] else '') for r in rows),"proxy_live.txt")

        if path=='/api/mail':
            _uf,_up=_ufilter(auth)
            return self._j(q(f"SELECT * FROM mail {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY id DESC LIMIT 500",_up,fetch=True))
        if path=='/api/mail/domains':
            _uf,_up=_ufilter(auth)
            return self._j(q(f"SELECT domain,COUNT(*) as count FROM mail {_uf.replace('AND','WHERE',1) if _uf else ''} GROUP BY domain ORDER BY count DESC",_up,fetch=True))
        if path=='/api/mail/export':
            _uf,_up=_ufilter(auth)
            return self._file('\n'.join(r['email'] for r in q(f"SELECT email FROM mail {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY email",_up,fetch=True)),"emails.txt")

        if path=='/api/bomb/status':
            el=time.time()-BS["start_time"] if BS["start_time"] else 0
            return self._j({**{k:v for k,v in BS.items() if k!='logs'},"elapsed":round(el),"logs":BS["logs"][:100]})

        if path.startswith('/api/sender/export/'):
            t=path.split('/')[-1]
            lst=SS["sent_list"] if t=='sent' else SS["failed_list"]
            return self._file('\n'.join(lst),f"{t}_{int(time.time())}.txt")
        if path=='/api/templates':
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT id,name,subject,created_at FROM templates {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY id DESC LIMIT 100",_up,fetch=True)
            return self._j(rows or [])
        if path.startswith('/api/templates/'):
            tid=int(path.split('/')[-1])
            _uf,_up=_ufilter(auth)
            row=q(f"SELECT * FROM templates WHERE id=? {_uf}",(tid,)+_up,one=True)
            if not row:return self._j({"error":"Not found"},404)
            return self._j(row)
        if path=='/api/blacklist/email':
            rows=q("SELECT * FROM email_blacklist ORDER BY id DESC LIMIT 500",fetch=True)
            return self._j(rows or [])
        if path=='/api/support/tickets':
            rows=q("SELECT id,ticket_id,tg_name,subject,status,created_at FROM support_tickets ORDER BY id DESC LIMIT 50",fetch=True)
            return self._j(rows or [])
        if path=='/api/sender/status':
            el=time.time()-SS["start_time"] if SS["start_time"] else 0
            safe={k:v for k,v in SS.items() if k not in('sent_list','failed_list','logs')}
            return self._j({**safe,"elapsed":round(el),"logs":SS["logs"][:80],
                "auto_paused":SS.get("auto_paused",False),
                "batch_sent":SS.get("batch_sent",0),
                "daily_sent":SS.get("daily_sent",0),
                "retry_queue":SS.get("retry_queue",0)})
        if path=='/api/history/export':
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT * FROM send_history {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY id DESC LIMIT 10000",_up,fetch=True)
            out=io.StringIO();w=csv.DictWriter(out,fieldnames=['id','recipient','smtp_user','status','error','response_time','campaign','created_at'])
            w.writeheader()
            for r in rows:w.writerow(r)
            return self._file(out.getvalue(),f"history_{int(time.time())}.csv",'text/csv')

        # ── Download realtime log files ────────────────────────────────────────
        if path=='/api/logs/download':
            qs2=parse_qs(urlparse(self.path).query)
            ltype=qs2.get('type',['send'])[0]
            if ltype not in ('send','failed','bounce'):
                return self._j({'error':'type must be send|failed|bounce'},400)
            log_file=os.path.join(LOG_DIR,f'{ltype}.log')
            if not os.path.exists(log_file):
                return self._j({'error':f'{ltype}.log not found — no activity yet'},404)
            with open(log_file,'rb') as f:data=f.read()
            return self._file(data,f'{ltype}_{int(time.time())}.log','text/plain')

        if path=='/api/logs/stats':
            stats={}
            for ltype in('send','failed','bounce'):
                log_file=os.path.join(LOG_DIR,f'{ltype}.log')
                if os.path.exists(log_file):
                    with open(log_file) as f:
                        lines=[l for l in f if l.strip()]
                    stats[ltype]={'lines':len(lines),'size_kb':round(os.path.getsize(log_file)/1024,1)}
                else:
                    stats[ltype]={'lines':0,'size_kb':0}
            return self._j(stats)

        if path=='/api/schedules':
            _uf,_up=_ufilter(auth)
            return self._j(q(f"SELECT * FROM schedules {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY run_at DESC LIMIT 50",_up,fetch=True))
        if path=='/api/blacklist/cache':return self._j(q("SELECT * FROM blacklist_cache ORDER BY id DESC LIMIT 100",fetch=True))
        if path=='/api/warmup':return self._j(q("SELECT w.*,s.host,s.username,s.health_score FROM warmup_sessions w JOIN smtp s ON s.id=w.smtp_id ORDER BY w.id DESC LIMIT 50",fetch=True))
        if path=='/api/webhooks':return self._j(q("SELECT * FROM webhook_config ORDER BY id DESC",fetch=True))
        if path=='/api/domain/cache':return self._j(q("SELECT * FROM domain_check_cache ORDER BY checked_at DESC LIMIT 100",fetch=True))

        if path=='/api/custom-hosts':
            ht=parse_qs(urlparse(self.path).query).get('type',['all'])[0]
            _uf,_up=_ufilter(auth)
            if ht and ht!='all':rows=q(f"SELECT * FROM custom_hosts WHERE host_type=? {_uf} ORDER BY id DESC",(ht,)+_up,fetch=True)
            else:rows=q(f"SELECT * FROM custom_hosts {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY id DESC",_up,fetch=True)
            return self._j(rows or [])

        # ── CLOUD FILES ───────────────────────────────────────────────────────────
        if path=='/api/cloud/files':
            rows=q("SELECT id,original_name,file_size,mime_type,description,uploaded_by,download_count,created_at FROM cloud_files ORDER BY id DESC",fetch=True)
            return self._j(rows or [])
        if path.startswith('/api/cloud/download/'):
            fid=int(path.split('/')[-1])
            row=q("SELECT * FROM cloud_files WHERE id=?",(fid,),fetch=True)
            if not row:return self._j({"error":"File not found"},404)
            row=row[0]
            fp=os.path.join(CLOUD_DIR,row['filename'])
            if not os.path.exists(fp):return self._j({"error":"File missing on disk"},404)
            q("UPDATE cloud_files SET download_count=download_count+1 WHERE id=?",(fid,))
            with open(fp,'rb') as f:data=f.read()
            return self._file(data,row['original_name'],row['mime_type'])

        # ── CHECKER RESULTS ────────────────────────────────────────────────────
        if path=='/api/checker/results':
            _uf,_up=_ufilter(auth)
            ctype=parse_qs(urlparse(self.path).query).get('type',[''])[0]
            if ctype:
                rows=q(f"SELECT * FROM checker_results WHERE check_type=? {_uf} ORDER BY id DESC LIMIT 500",(ctype,)+_up,fetch=True)
            else:
                rows=q(f"SELECT * FROM checker_results {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY id DESC LIMIT 500",_up,fetch=True)
            return self._j(rows or [])

        # ── MAIL.TM ACCOUNTS ──────────────────────────────────────────────────
        if path=='/api/mailtm/accounts':
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT id,address,status,message_count,created_at FROM mailtm_accounts {_uf.replace('AND','WHERE',1) if _uf else ''} ORDER BY id DESC LIMIT 200",_up,fetch=True)
            return self._j(rows or [])
        if path.startswith('/api/mailtm/inbox/'):
            _uf,_up=_ufilter(auth)
            amid=int(path.split('/')[-1])
            row=q(f"SELECT * FROM mailtm_accounts WHERE id=? {_uf}",(amid,)+_up,fetch=True)
            if not row:return self._j({"error":"Account not found"},404)
            row=row[0]
            # Fetch inbox via mail.tm API
            try:
                import urllib.request as _ur
                hdr={'Authorization':f'Bearer {row["token"]}','Content-Type':'application/json'}
                req=_ur.Request('https://api.mail.tm/messages',headers=hdr)
                with _ur.urlopen(req,timeout=10) as resp:
                    msgs=json.loads(resp.read())
                return self._j(msgs.get('hydra:member',[]) if isinstance(msgs,dict) else [])
            except Exception as ex:
                return self._j({"error":str(ex)},502)

        if path.startswith('/adminlogin/api/'):
            if not auth or not auth['is_admin']:return self._j({"error":"Admin only"},403)
            if path=='/adminlogin/api/dashboard':
                return self._j({
                    "smtp_count":q("SELECT COUNT(*) as c FROM smtp",fetch=True)[0]['c'],
                    "smtp_live":q("SELECT COUNT(*) as c FROM smtp WHERE status='live'",fetch=True)[0]['c'],
                    "mail_count":q("SELECT COUNT(*) as c FROM mail",fetch=True)[0]['c'],
                    "total_keys":q("SELECT COUNT(*) as c FROM api_keys",fetch=True)[0]['c'],
                    "active_keys":q("SELECT COUNT(*) as c FROM api_keys WHERE(expires_at IS NULL OR expires_at>?)",(datetime.now().isoformat(),),fetch=True)[0]['c'],
                    "webmail_live":q("SELECT COUNT(*) as c FROM webmail WHERE status='live'",fetch=True)[0]['c'],
                    "total_sent":q("SELECT COUNT(*) as c FROM send_history WHERE status='sent'",fetch=True)[0]['c'],
                    "schedules_pending":q("SELECT COUNT(*) as c FROM schedules WHERE status='pending'",fetch=True)[0]['c'],
                })
            if path=='/adminlogin/api/keys':return self._j(q("SELECT id,key_display,is_admin,tier,expires_at,max_smtp,max_emails,created_at,created_by FROM api_keys ORDER BY created_at DESC",fetch=True))
            if path=='/adminlogin/api/logs':return self._j(q("SELECT * FROM logs ORDER BY id DESC LIMIT 200",fetch=True))
            if path=='/adminlogin/api/announcements':return self._j(q("SELECT * FROM announcements ORDER BY id DESC",fetch=True))
        return self._j({"error":"Not found"},404)

    def do_POST(self):
        try:
            self._do_POST_inner()
        except Exception as e:
            log.error(f"[POST] unhandled: {e}")
            try:self._j({"error":"Internal server error"},500)
            except:pass

    def _do_POST_inner(self):
        if not self._sec():return
        path=urlparse(self.path).path
        body=self._body()
        if body is None:return  # _body already sent error response

        if path=='/api/auth/login':
            ip=_ip(self)
            # Brute-force protection
            if not sec_brute_ok(ip):
                log_ev('warn','auth',f'Brute-blocked:{ip}')
                return self._j({
                    "error":"Too many failed attempts — please wait 5 minutes",
                    "code":"RATE_LIMITED"
                },429)
            raw_key=(body.get('key') or '')
            log.info(f"[login] raw len={len(raw_key)} repr={repr(raw_key[:40])}")
            key=normalize_key(raw_key)
            log.info(f"[login] clean key={repr(key[:40])}")
            if not key:
                return self._j({"error":"Access key is required","code":"KEY_MISSING"},400)
            rec=verify(key)
            if not rec:
                sec_fail(ip)
                log_ev('warn','auth',f'Bad key attempt from {ip}')
                return self._j({
                    "error":"Invalid or expired key",
                    "code":"KEY_INVALID"
                },403)
            sec_ok(ip)
            log_ev('info','auth',f"Login OK tier={rec.get('tier','user')} ip={ip}")
            # ── Unusual login detection ──────────────────────────────────────
            try:
                ua=self.headers.get('User-Agent','')[:200]
                kh=hk(key)
                last=q("SELECT ip,ua FROM login_events WHERE key_hash=? ORDER BY id DESC LIMIT 1",(kh,),one=True)
                is_new_ip  = last and last['ip'] != ip
                is_new_ua  = last and last.get('ua','') and last['ua'][:40] != ua[:40]
                q("INSERT INTO login_events(key_hash,ip,ua)VALUES(?,?,?)",(kh,ip,ua[:200]))
                if last and (is_new_ip or is_new_ua) and BOT_TOKEN and ADMIN_TG:
                    tg_id=rec.get('telegram_id',0) or 0
                    alert_text=(
                        f"⚠️ <b>Unusual login detected</b>\n"
                        f"━━━━━━━━━━━━━━━━━━━━\n"
                        f"Key: <code>{rec.get('key_display','?')[:20]}</code>\n"
                        f"IP: <code>{ip}</code>\n"
                        f"Previous IP: <code>{last['ip']}</code>\n"
                        f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
                        f"{'New IP detected! ' if is_new_ip else ''}"
                        f"{'New device/browser!' if is_new_ua else ''}"
                    )
                    _tg_send(ADMIN_TG, alert_text)
                    if tg_id:
                        _tg_send(tg_id, alert_text)
                # Update last_ip on key
                try:q("UPDATE api_keys SET last_ip=? WHERE key_hash=?",(ip,kh))
                except:pass
            except Exception as _le:
                log.warning(f"[login_track] {_le}")
            return self._j({
                "ok":True,
                "is_admin":rec['is_admin'],
                "tier":rec.get('tier','pro'),
                "expires_at":rec.get('expires_at'),
            })

        if path=='/adminlogin/auth':
            ip=_ip(self)
            if not sec_brute_ok(ip):return self._j({"error":"Too many attempts — wait 5 minutes"},429)
            key=body.get('key','')
            if not key:return self._j({"error":"Key required"},400)
            rec=verify(key)
            if not rec or not rec['is_admin']:sec_fail(ip);return self._j({"error":"Invalid key"},403)
            sec_ok(ip);return self._j({"ok":True})

        auth=self._auth()
        if not auth:return self._j({"error":"Auth required"},401)

        if path=='/api/smtp/import':
            lines=body.get('lines',[]);imp=skip=0
            BATCH=500;_ukid=_kid(auth)
            batch=[]
            def _flush_smtp(batch):
                nonlocal imp,skip
                if not batch:return
                try:
                    with _lock:
                        c=get_db()
                        try:
                            c.executemany(
                                "INSERT OR IGNORE INTO smtp(key_id,host,port,username,password)VALUES(?,?,?,?,?)",
                                batch)
                            imp+=c.execute("SELECT changes()").fetchone()[0]
                            c.commit()
                        finally:c.close()
                except Exception as e:
                    log.warning(f"[smtp_import] batch error: {e}")
                    skip+=len(batch)
            for l in lines:
                l=l.strip()
                if not l:skip+=1;continue
                p=l.split('|')
                if len(p)<4:skip+=1;continue
                try:
                    batch.append((_ukid,p[0].strip(),int(p[1].strip()),p[2].strip(),p[3].strip()))
                    if len(batch)>=BATCH:_flush_smtp(batch);batch=[]
                except:skip+=1
            _flush_smtp(batch)
            log_ev('info','smtp',f"Import {imp} skip={skip}")
            return self._j({"imported":imp,"skipped":skip})

        if path=='/api/smtp/check':
            te=body.get('test_email','')
            threads=min(int(body.get('threads',10)),50)
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT * FROM smtp WHERE status IN('unchecked','pending') {_uf} LIMIT 5000",_up,fetch=True)
            if not rows:return self._j({"message":"No SMTP to check","total":0})
            q(f"UPDATE smtp SET status='pending' WHERE status='unchecked' {_uf}",_up)
            smtp_check_stop.clear()
            rst_cs();CS["running"]=True;CS["total"]=len(rows)
            _proxy_pool=q("SELECT ip,port,username,password FROM proxy WHERE status='live'",fetch=True) or []
            def _t():
                from queue import Queue as _Q,Empty as _Empty
                work_q=_Q()
                for row in rows:work_q.put(row)
                _cs_lock=threading.Lock()
                def _worker():
                    while not smtp_check_stop.is_set():
                        try:row=work_q.get(timeout=1)
                        except _Empty:break
                        try:
                            prx_=random.choice(_proxy_pool) if _proxy_pool else None
                            r=chk_smtp(row['id'],row['host'],row['port'],
                                       row['username'],row['password'],te,proxy=prx_)
                            q("UPDATE smtp SET status=?,ssl_info=?,response_time=?,error_msg=?,last_checked=? WHERE id=?",
                              (r['status'],r['ssl_info'],r['response_time'],r['error'],
                               datetime.now().isoformat(),r['id']))
                            with _cs_lock:
                                CS["checked"]+=1
                                st=r['status']
                                if st=='live':CS["live"]+=1
                                elif st=='die':CS["dead"]+=1
                                elif st=='limited':CS["limited"]+=1
                                else:CS["failed"]+=1
                        except Exception as ex:
                            log.warning(f"[checker] id={row.get('id')} err: {ex}")
                            with _cs_lock:CS["checked"]+=1;CS["failed"]+=1
                        finally:work_q.task_done()
                workers=[threading.Thread(target=_worker,daemon=True) for _ in range(threads)]
                for w in workers:w.start()
                for w in workers:w.join()
                CS["running"]=False
                # Notify admin when check completes
                if BOT_TOKEN and ADMIN_TG:
                    _tg_send(ADMIN_TG,
                        f"✅ <b>SMTP Check Complete</b>\n"
                        f"Total: {CS['total']} | Live: {CS['live']} | Dead: {CS['dead']} | Limited: {CS['limited']} | Failed: {CS['failed']}")
            threading.Thread(target=_t,daemon=True).start()
            return self._j({"message":f"Check started ({threads} threads)","total":len(rows)})

        if path=='/api/smtp/check/stop':
            smtp_check_stop.set();return self._j({"ok":True})

        if path=='/api/smtp/recheck':
            _uf,_up=_ufilter(auth)
            n=q(f"UPDATE smtp SET status='unchecked' WHERE status IN('live','die','limited') {_uf}",_up)
            return self._j({"total":n})

        if path=='/api/smtp/identity':
            sid=body.get('id')
            if not sid:return self._j({"error":"id required"},400)
            _uf,_up=_ufilter(auth)
            q(f"UPDATE smtp SET from_name=?,from_email=?,reply_to=? WHERE id=? {_uf}",
              (body.get('from_name',''),body.get('from_email',''),body.get('reply_to',''),sid)+_up)
            return self._j({"ok":True})

        if path=='/api/blacklist/check':
            hosts=body.get('hosts',[])
            if not hosts:return self._j({"error":"hosts required"},400)
            results=[]
            def _bl():
                for h in hosts[:20]:
                    r=chk_bl(h)
                    q("INSERT OR REPLACE INTO blacklist_cache(host,listed,details,checked_at)VALUES(?,?,?,?)",
                      (h,1 if r.get('listed') else 0,json.dumps(r),datetime.now().isoformat()))
                    results.append(r)
            t=threading.Thread(target=_bl,daemon=True);t.start();t.join(timeout=60)
            return self._j({"results":results})

        if path=='/api/domain/check':
            domains=body.get('domains',[])
            if not domains:return self._j({"error":"domains required"},400)
            results=[]
            for d in domains[:20]:
                results.append(chk_domain(d.strip()))
            return self._j({"results":results})

        if path=='/api/warmup/start':
            smtp_id=body.get('smtp_id');te=body.get('test_emails',[])
            if not smtp_id or not te:return self._j({"error":"smtp_id and test_emails required"},400)
            threading.Thread(target=warmup_worker,args=(smtp_id,te),daemon=True).start()
            return self._j({"ok":True,"message":"Warm-up started"})
        if path=='/api/warmup/reset':
            sid=body.get('smtp_id')
            if sid:q("DELETE FROM warmup_sessions WHERE smtp_id=?",(sid,))
            return self._j({"ok":True})

        if path=='/api/schedules/create':
            name=body.get('name','Sched');run_at=body.get('run_at','')
            if not run_at:return self._j({"error":"run_at required"},400)
            q("INSERT INTO schedules(key_id,name,config,run_at,repeat)VALUES(?,?,?,?,?)",
              (_kid(auth),name,json.dumps(body.get('config',{})),run_at,body.get('repeat','once')))
            return self._j({"ok":True})
        if path=='/api/schedules/delete':
            sid=body.get('id')
            _uf,_up=_ufilter(auth)
            if sid:q(f"DELETE FROM schedules WHERE id=? {_uf}",(sid,)+_up)
            return self._j({"ok":True})
        if path=='/api/schedules/cancel':
            sid=body.get('id')
            _uf,_up=_ufilter(auth)
            if sid:q(f"UPDATE schedules SET status='cancelled' WHERE id=? {_uf}",(sid,)+_up)
            return self._j({"ok":True})

        if path=='/api/webhooks/create':
            url=body.get('url','').strip()
            if not url:return self._j({"error":"url required"},400)
            q("INSERT INTO webhook_config(url,events,platform)VALUES(?,?,?)",(url,body.get('events','all'),body.get('platform','generic')))
            return self._j({"ok":True})
        if path=='/api/webhooks/test':
            url=body.get('url','').strip()
            if not url:return self._j({"error":"url required"},400)
            try:fire_hook('test',{'message':'Mailer v7 test OK'});return self._j({"ok":True})
            except Exception as e:return self._j({"error":str(e)[:100]})
        if path=='/api/webhooks/delete':
            wid=body.get('id')
            if wid:q("DELETE FROM webhook_config WHERE id=?",(wid,))
            return self._j({"ok":True})

        if path=='/api/webmail/import':
            lines=body.get('lines',[]);imp=skip=0
            BATCH=500;batch=[];_ukid=_kid(auth)
            def _flush_wm(batch):
                nonlocal imp,skip
                if not batch:return
                try:
                    with _lock:
                        c=get_db()
                        try:
                            c.executemany("INSERT OR IGNORE INTO webmail(key_id,url,email,password)VALUES(?,?,?,?)",batch)
                            imp+=c.execute("SELECT changes()").fetchone()[0]
                            c.commit()
                        finally:c.close()
                except Exception as e:
                    log.warning(f"[wm_import] batch error: {e}");skip+=len(batch)
            for l in lines:
                l=l.strip()
                if not l:skip+=1;continue
                p=l.split('|')
                if len(p)<3:skip+=1;continue
                batch.append((_ukid,p[0].strip(),p[1].strip(),p[2].strip()))
                if len(batch)>=BATCH:_flush_wm(batch);batch=[]
            _flush_wm(batch)
            return self._j({"imported":imp,"skipped":skip})
        if path=='/api/webmail/check':
            te=body.get('test_email','')
            wm_threads=min(int(body.get('threads',3)),10)  # configurable 1–10
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT * FROM webmail WHERE status IN('unchecked','pending') {_uf} LIMIT 200",_up,fetch=True)
            if not rows:return self._j({"message":"No webmail to check","total":0})
            q(f"UPDATE webmail SET status='pending' WHERE status='unchecked' {_uf}",_up)
            _wm_q=deque(rows)
            _wm_lock=threading.Lock()
            def _wm_worker():
                while True:
                    with _wm_lock:
                        if not _wm_q: break
                        row=_wm_q.popleft()
                    r=chk_wm(row['id'],row['url'],row['email'],row['password'],te)
                    q("UPDATE webmail SET status=?,server_info=?,response_time=?,error_msg=?,last_checked=? WHERE id=?",
                      (r['status'],r['server_info'],r['response_time'],r['error'],datetime.now().isoformat(),r['id']))
            for _ in range(min(wm_threads,len(rows))):
                threading.Thread(target=_wm_worker,daemon=True).start()
            return self._j({"message":f"Check started ({wm_threads} threads)","total":len(rows)})
        if path=='/api/webmail/recheck':
            _uf,_up=_ufilter(auth)
            n=q(f"UPDATE webmail SET status='unchecked' WHERE status IN('live','die','limited') {_uf}",_up)
            return self._j({"total":n})

        if path=='/api/proxy/import':
            lines=body.get('lines',[]);imp=skip=0;_ukid=_kid(auth)
            for l in lines:
                p=l.split(':')
                if len(p)<2:skip+=1;continue
                try:q("INSERT OR IGNORE INTO proxy(key_id,ip,port,username,password)VALUES(?,?,?,?,?)",
                       (_ukid,p[0].strip(),int(p[1].strip()),p[2].strip() if len(p)>2 else '',p[3].strip() if len(p)>3 else ''));imp+=1
                except:skip+=1
            return self._j({"imported":imp,"skipped":skip})
        if path=='/api/proxy/check':
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT * FROM proxy WHERE status IN('unchecked','pending') {_uf} LIMIT 50",_up,fetch=True)
            if not rows:return self._j({"message":"No proxy","total":0})
            q(f"UPDATE proxy SET status='pending' WHERE status='unchecked' {_uf}",_up)
            def _px():
                import urllib.request
                for row in rows:
                    t0=time.time();lat=0;country='';bl=0
                    try:
                        pu=f"http://{row['username']}:{row['password']}@{row['ip']}:{row['port']}" if row['username'] else f"http://{row['ip']}:{row['port']}"
                        op=urllib.request.build_opener(urllib.request.ProxyHandler({'http':pu,'https':pu}))
                        op.addheaders=[('User-Agent','Mozilla/5.0')]
                        resp=op.open('http://ip-api.com/json',timeout=15)
                        lat=round((time.time()-t0)*1000)
                        try:
                            geo=json.loads(resp.read().decode())
                            country=geo.get('country','')
                        except:pass
                        # Quick DNSBL check on proxy IP
                        try:
                            rev='.'.join(reversed(row['ip'].split('.')))
                            try:socket.setdefaulttimeout(3);socket.gethostbyname(f"{rev}.zen.spamhaus.org");bl=1
                            except socket.gaierror:bl=0
                            finally:socket.setdefaulttimeout(20)
                        except:pass
                        q("UPDATE proxy SET status='live',latency=?,country=?,blacklisted=?,last_checked=? WHERE id=?",(lat,country,bl,datetime.now().isoformat(),row['id']))
                    except:
                        q("UPDATE proxy SET status='die',last_checked=? WHERE id=?",(datetime.now().isoformat(),row['id']))
            threading.Thread(target=_px,daemon=True).start()
            return self._j({"message":"Check started","total":len(rows)})

        if path=='/api/mail/import':
            lines=body.get('lines',[]);imp=skip=0
            BATCH=1000;batch=[];_ukid=_kid(auth)
            def _flush_mail(batch):
                nonlocal imp,skip
                if not batch:return
                try:
                    with _lock:
                        c=get_db()
                        try:
                            c.executemany("INSERT OR IGNORE INTO mail(key_id,email,domain)VALUES(?,?,?)",batch)
                            imp+=c.execute("SELECT changes()").fetchone()[0]
                            c.commit()
                        finally:c.close()
                except Exception as e:
                    log.warning(f"[mail_import] batch error: {e}");skip+=len(batch)
            for l in lines:
                l=l.strip()
                if not l:skip+=1;continue
                # Support MAIL:PASS, MAIL|PASS, plain MAIL — extract only email
                if '|' in l: e=l.split('|')[0].strip()
                elif ':' in l:
                    p=l.split(':',1)
                    e=p[0].strip() if '@' in p[0] else l.strip()
                else: e=l.strip()
                e=e.lower()
                if not e or '@' not in e or len(e)>254 or '.' not in e.split('@')[1]:skip+=1;continue
                batch.append((_ukid,e,e.split('@')[1]))
                if len(batch)>=BATCH:_flush_mail(batch);batch=[]
            _flush_mail(batch)
            return self._j({"imported":imp,"skipped":skip})
        if path=='/api/mail/clean':
            _uf,_up=_ufilter(auth)
            rows=q(f"SELECT email FROM mail {_uf.replace('AND','WHERE',1) if _uf else ''}",_up,fetch=True)
            clean,inv,disp,dup=clean_list([r['email'] for r in rows])
            for e in inv+disp:q(f"DELETE FROM mail WHERE email=? {_uf}",(e,)+_up)
            return self._j({"clean":len(clean),"removed_invalid":len(inv),"removed_disposable":len(disp),"removed_duplicate":len(dup)})
        if path=='/api/mail/clean-input':
            raw=body.get('emails',[])
            if isinstance(raw,str):raw=[l.strip() for l in raw.split('\n') if l.strip()]
            clean,inv,disp,dup=clean_list(raw)
            return self._j({"clean":clean,"clean_count":len(clean),"invalid":inv,"disposable":disp,"duplicate":dup,
                "stats":{"total":len(raw),"clean":len(clean),"invalid":len(inv),"disposable":len(disp),"duplicate":len(dup)}})

        if path=='/api/sender/start':
            if SS["running"]:return self._j({"error":"Already running"},400)
            mode=body.get('mode','rotate')
            # Parse email|name format — fallback name: Customer
            _raw_emails=body.get('emails',[])
            emails=[]; rec_names={}
            for _r in _raw_emails:
                _r=str(_r).strip()
                _parts=_r.split('|',1)
                _email=_parts[0].strip()
                _name=_parts[1].strip() if len(_parts)>1 else ''
                if _email and '@' in _email:
                    emails.append(_email)
                    if _name: rec_names[_email]=_name
            if not emails:return self._j({"error":"No emails"},400)
            subjects=body.get('subjects',[]) or [body.get('subject','No Subject')]
            # Multiple Templates: if field provided with === separator, split into list.
            # If empty/absent, fall back to html body. Never use stale cache.
            _multi_raw=(body.get('multiple_templates') or '').strip()
            if _multi_raw:
                _parts=[t.strip() for t in _multi_raw.split('===') if t.strip()]
                letters=_parts if _parts else [body.get('html','<p>Hello</p>')]
            else:
                letters=body.get('letters',[]) or [body.get('html','<p>Hello</p>')]
            # Guarantee at least one non-empty template
            letters=[l for l in letters if l and l.strip()] or ['<p>Hello</p>']
            smtp_list=[]
            if mode=='rotate':
                src=body.get('smtp_source','live')
                if src=='manual' and body.get('smtp_manual'):
                    for l in body['smtp_manual']:
                        p=l.split('|')
                        if len(p)>=4:smtp_list.append({'host':p[0].strip(),'port':p[1].strip(),'user':p[2].strip(),'pass':p[3].strip()})
                else:
                    _uf,_up=_ufilter(auth)
                    smtp_list=[dict(r) for r in q(f"SELECT host,port,username as user,password as pass,from_name,from_email,reply_to FROM smtp WHERE status IN('live','limited') {_uf} ORDER BY health_score DESC",_up,fetch=True)]
            elif mode=='single':
                smtp_list=[{'host':body.get('single_host',''),'port':body.get('single_port','587'),'user':body.get('single_user',''),'pass':body.get('single_pass','')}]
            elif mode=='office365':
                for l in body.get('o365_list',[]):
                    p=l.split('|')
                    if len(p)>=2:smtp_list.append({'host':'smtp.office365.com','port':'587','user':p[0].strip(),'pass':p[1].strip()})
            elif mode=='webmail':
                src=body.get('webmail_source','live')
                if src=='manual' and body.get('webmail_manual'):
                    for l in body['webmail_manual']:
                        p=l.split('|')
                        if len(p)>=3:smtp_list.append({'host':urlparse(p[0].strip()).hostname or p[0].strip(),'port':'465','user':p[1].strip(),'pass':p[2].strip()})
                else:
                    _uf,_up=_ufilter(auth)
                    for wm in q(f"SELECT * FROM webmail WHERE status='live' {_uf} ORDER BY RANDOM()",_up,fetch=True):
                        smtp_list.append({'host':urlparse(wm['url']).hostname or wm['url'],'port':'465','user':wm['email'],'pass':wm['password']})
            if not smtp_list:return self._j({"error":"No SMTP available — import and check SMTP first"},400)
            # Load proxies if requested
            proxy_list=[]
            use_proxy=body.get('use_proxy',False)
            if use_proxy:
                _uf,_up=_ufilter(auth)
                proxy_list=[dict(r) for r in q(f"SELECT ip,port,username as user,password as pass FROM proxy WHERE status='live' {_uf}",_up,fetch=True)]
            # Parse from_names list (newline separated)
            fn_raw = body.get('from_names','')
            from_names_list = [n.strip() for n in fn_raw.splitlines() if n.strip()] if fn_raw else []

            cfg={'mode':mode,'smtp_list':smtp_list,'emails':emails,'rec_names':rec_names,'subjects':subjects,'letters':letters,
                'from_name':body.get('from_name',''),'from_email':body.get('from_email',''),'reply_to':body.get('reply_to',''),
                'from_names':from_names_list,
                'key_id':_kid(auth),
                'delay_min':float(body.get('delay_min',2)),'delay_max':float(body.get('delay_max',8)),
                'mails_per_smtp':int(body.get('mails_per_smtp',50)),'campaign':body.get('campaign',''),
                'threads':min(int(body.get('threads',1)),10),
                'batch_size':int(body.get('batch_size',0)),
                'batch_delay':float(body.get('batch_delay',30)),
                'attach_id':body.get('attach_id',''),
                'daily_limit':0,'hourly_limit':0,
                'bounce_pause':bool(body.get('bounce_pause',False)),
                'bounce_thresh':int(body.get('bounce_thresh',10)),
                'use_proxy':use_proxy,'proxy_list':proxy_list}
            rst_ss()
            SS.update({"running":True,"total":len(emails),"pending":len(emails),"active_smtp":len(smtp_list),"start_time":time.time(),"campaign":cfg['campaign']})
            threading.Thread(target=sender_worker,args=(cfg,),daemon=True).start()
            return self._j({"ok":True,"total":len(emails),"smtp_count":len(smtp_list)})

        if path=='/api/sender/upload-attachment':
            fname=(body.get('filename') or 'attachment').strip()
            # Sanitise filename — no path traversal
            fname=os.path.basename(fname) or 'attachment'
            ext=os.path.splitext(fname)[1].lower()
            if ext not in _ATTACH_ALLOWED:
                return self._j({"error":f"Unsupported file type '{ext}'. Allowed: {', '.join(_ATTACH_ALLOWED)}"},400)
            data_b64=(body.get('data') or '').strip()
            if not data_b64:
                return self._j({"error":"No file data provided"},400)
            try:
                fdata=base64.b64decode(data_b64)
            except Exception:
                return self._j({"error":"Invalid base64 file data"},400)
            if len(fdata)>_ATTACH_MAX_BYTES:
                return self._j({"error":f"File too large (max {_ATTACH_MAX_BYTES//1024//1024} MB)"},413)
            # Generate a short stable ID
            aid=hashlib.md5(fdata[:2048]).hexdigest()[:10]+str(int(time.time()))[-6:]
            with _attach_lock:
                _pending_attach[aid]={'filename':fname,'data':fdata}
            _attach_expire(aid)    # auto-cleanup after 2 h
            log.info(f"[attach] stored id={aid} file={fname} size={len(fdata)}")
            return self._j({"ok":True,"attach_id":aid,"filename":fname,"size":len(fdata)})

        if path=='/api/sender/cancel':
            SS["cancelled"]=True;SS["running"]=False;return self._j({"ok":True})

        if path=='/api/bomb/start':
            if BS["running"]:return self._j({"error":"Bomb already running"},400)
            target=body.get('target','').strip()
            if not target or '@' not in target:return self._j({"error":"target email required"},400)
            _uf,_up=_ufilter(auth)
            sc=q(f"SELECT COUNT(*) as c FROM smtp WHERE status IN('live','limited') {_uf}",_up,fetch=True)[0]['c']
            if sc==0:return self._j({"error":"No live SMTP"},400)
            subjects=body.get('subjects',[]) or [body.get('subject','Hello')]
            html=body.get('html','<p>Hi</p>')
            letters=body.get('letters',[]) or [html]
            cfg={'target':target,'subjects':subjects,'letters':letters,
                'from_name':body.get('from_name',''),'from_email':body.get('from_email',''),
                'reply_to':body.get('reply_to',''),'limit':int(body.get('limit',0)),
                'delay_min':float(body.get('delay_min',0)),'delay_max':float(body.get('delay_max',0.5))}
            rst_bs()
            BS.update({"running":True,"target":target,"start_time":time.time()})
            threading.Thread(target=bomb_worker,args=(cfg,),daemon=True).start()
            return self._j({"ok":True,"target":target,"smtp_count":sc})

        if path=='/api/bomb/stop':
            BS["cancelled"]=True;BS["running"]=False;return self._j({"ok":True})

        if path=='/api/inbox/check':
            em=body.get('email','');pwd=body.get('password','')
            if not em or not pwd:return self._j({"error":"email+password required"},400)
            from checker.inbox_checker import check_inbox,guess_imap_host
            result=check_inbox(0,guess_imap_host(em),'993',em,pwd,body.get('subject',''),body.get('from',''))
            return self._j(result)

        if path=='/api/logs/clear':q("DELETE FROM logs");return self._j({"ok":True})

        if path.startswith('/adminlogin/api/'):
            if not auth or not auth['is_admin']:return self._j({"error":"Admin only"},403)
            if path=='/adminlogin/api/keys/create':
                dur_map={'1day':1,'3days':3,'7days':7,'14days':14,'30days':30,'60days':60,'90days':90,'180days':180,'365days':365}
                dur=body.get('duration','30days');days=dur_map.get(dur,30)
                exp=(datetime.now(timezone.utc)+timedelta(days=days)).replace(tzinfo=None,microsecond=0).isoformat() if dur!='unlimited' else None
                try:
                    key=_make_unique_key()
                    q("INSERT INTO api_keys(key_hash,key_display,is_admin,tier,expires_at,created_by,max_smtp,max_emails)VALUES(?,?,?,?,?,?,?,?)",
                      (hk(key),key,1 if body.get('is_admin') else 0,body.get('tier','pro'),exp,auth['key_display'],
                       int(body.get('max_smtp',999999)),int(body.get('max_emails',999999))))
                    log_ev('info','admin',f"Key created tier={body.get('tier','pro')} by {auth['key_display'][:20]}")
                    return self._j({"key":key,"expires_at":exp})
                except Exception as e:
                    return self._j({"error":f"Key creation failed: {e}"},500)
            if path=='/adminlogin/api/plans/update':
                # Admin update a plan: {plan_key, name, price, price_vnd, description, dur, days, tier}
                pk=body.get('plan_key','').strip()
                if not pk:return self._j({"error":"plan_key required"},400)
                q("INSERT INTO plans(plan_key,name,price,price_vnd,description,dur,days,tier,updated_at)VALUES(?,?,?,?,?,?,?,?,?)"
                  " ON CONFLICT(plan_key) DO UPDATE SET name=excluded.name,price=excluded.price,"
                  "price_vnd=excluded.price_vnd,description=excluded.description,"
                  "dur=excluded.dur,days=excluded.days,tier=excluded.tier,updated_at=excluded.updated_at",
                  (pk,body.get('name',pk),body.get('price','$0'),int(body.get('price_vnd',0)),
                   body.get('description',''),body.get('dur','30 days'),
                   int(body.get('days',30)),body.get('tier','pro'),datetime.now().isoformat()))
                log_ev('info','admin',f"Plan updated: {pk} price={body.get('price')} vnd={body.get('price_vnd')}")
                return self._j({"ok":True,"plans":list(get_plans().values())})
            if path=='/adminlogin/api/keys/ban':
                k=body.get('key','')
                if k:q("DELETE FROM api_keys WHERE key_hash=? AND is_admin=0",(hk(k),))
                return self._j({"ok":True})
            if path=='/adminlogin/api/keys/quota':
                # Add mail quota to a key: {key, add_mails}
                key_disp=body.get('key','').strip()
                add_mails=int(body.get('add_mails',0))
                if not key_disp or add_mails<=0:
                    return self._j({"error":"key and add_mails required"},400)
                rec=q("SELECT id,max_emails FROM api_keys WHERE key_display=?",(key_disp,),one=True)
                if not rec: return self._j({"error":"Key not found"},404)
                new_quota=(rec['max_emails'] or 0)+add_mails
                q("UPDATE api_keys SET max_emails=? WHERE id=?",(new_quota,rec['id']))
                log_ev('info','admin',f'Quota +{add_mails} to key {key_disp[:20]} → {new_quota}')
                return self._j({"ok":True,"key":key_disp,"new_quota":new_quota})

            if path=='/adminlogin/api/keys/extend':
                # Extend key expiry: {key, days}
                key_disp=body.get('key','').strip()
                days=int(body.get('days',30))
                if not key_disp: return self._j({"error":"key required"},400)
                rec=q("SELECT id,expires_at FROM api_keys WHERE key_display=?",(key_disp,),one=True)
                if not rec: return self._j({"error":"Key not found"},404)
                base=datetime.now(timezone.utc).replace(tzinfo=None)
                if rec['expires_at']:
                    try: base=max(base,datetime.fromisoformat(rec['expires_at']))
                    except: pass
                new_exp=(base+timedelta(days=days)).isoformat()
                q("UPDATE api_keys SET expires_at=? WHERE id=?",(new_exp,rec['id']))
                return self._j({"ok":True,"key":key_disp,"new_expires":new_exp[:10]})

            if path=='/adminlogin/api/announce':
                title=body.get('title','');content=body.get('content','')
                if title:q("INSERT INTO announcements(title,content,type)VALUES(?,?,?)",(title,content,body.get('type','info')))
                return self._j({"ok":True})
            if path=='/adminlogin/api/announce/delete':
                aid=body.get('id')
                if aid:q("DELETE FROM announcements WHERE id=?",(aid,))
                return self._j({"ok":True})

        # ── Custom Hosts ──────────────────────────────────────────────────────
        if path=='/api/custom-hosts/add':
            host=body.get('host','').strip()
            if not host:return self._j({"error":"host required"},400)
            try:
                q("INSERT INTO custom_hosts(host_type,host,port,ssl_tls,username,password)VALUES(?,?,?,?,?,?)",
                  (body.get('host_type','smtp'),host,int(body.get('port',587)),
                   body.get('ssl_tls','tls'),body.get('username',''),body.get('password','')))
                return self._j({"ok":True})
            except Exception as e:return self._j({"error":str(e)},500)

        if path=='/api/custom-hosts/test':
            host=body.get('host','').strip()
            port=int(body.get('port',587))
            user=body.get('username','').strip()
            pwd=body.get('password','').strip()
            ssl_tls=body.get('ssl_tls','tls')
            if not host:return self._j({"error":"host required"},400)
            try:
                ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
                if port==465 or ssl_tls=='ssl':
                    srv=smtplib.SMTP_SSL(host,port,timeout=10,context=ctx)
                else:
                    srv=smtplib.SMTP(host,port,timeout=10);srv.ehlo()
                    if ssl_tls in('tls','starttls'):
                        try:srv.starttls(context=ctx);srv.ehlo()
                        except:pass
                if user and pwd:srv.login(user,pwd)
                srv.quit()
                if host:q("UPDATE custom_hosts SET status='live',error_msg='' WHERE host=?",(host,))
                _tg_send(ADMIN_TG,f"✅ Custom host test OK\nHost: {host}:{port}\nUser: {user}")
                return self._j({"ok":True,"message":f"Connection to {host}:{port} successful"})
            except Exception as e:
                err=str(e)[:120]
                if host:q("UPDATE custom_hosts SET status='die',error_msg=? WHERE host=?",(err,host))
                return self._j({"ok":False,"error":err})

        # ── CLOUD FILE UPLOAD (admin only) ────────────────────────────────────
        if path=='/api/cloud/upload':
            if not _is_admin(auth):return self._j({"error":"Admin only"},403)
            # Multipart — read raw body as bytes
            cl=int(self.headers.get('Content-Length',0) or 0)
            if cl<1 or cl>100*1024*1024:return self._j({"error":"Invalid size (max 100MB)"},400)
            raw=self.rfile.read(cl)
            ct=self.headers.get('Content-Type','')
            boundary=b''
            for part in ct.split(';'):
                part=part.strip()
                if part.startswith('boundary='):
                    boundary=part[9:].strip().encode()
                    break
            if not boundary:return self._j({"error":"No boundary"},400)
            # Parse simple multipart
            import re as _re2
            filename_m=_re2.search(rb'filename="([^"]+)"',raw)
            if not filename_m:return self._j({"error":"No filename in upload"},400)
            orig_name=filename_m.group(1).decode(errors='replace')
            # Find body after double CRLF
            hdr_end=raw.find(b'\r\n\r\n')
            if hdr_end<0:return self._j({"error":"Malformed multipart"},400)
            file_data=raw[hdr_end+4:]
            # Strip trailing boundary
            tail_idx=file_data.rfind(b'\r\n--'+boundary)
            if tail_idx>=0:file_data=file_data[:tail_idx]
            safe_name=re.sub(r'[^a-zA-Z0-9._-]','_',orig_name)[:120]
            unique_name=f"{int(time.time())}_{safe_name}"
            fp=os.path.join(CLOUD_DIR,unique_name)
            with open(fp,'wb') as f:f.write(file_data)
            import mimetypes
            mime=mimetypes.guess_type(orig_name)[0] or 'application/octet-stream'
            desc=self.headers.get('X-Description','')
            q("INSERT INTO cloud_files(filename,original_name,file_size,mime_type,description,uploaded_by)VALUES(?,?,?,?,?,?)",
              (unique_name,orig_name,len(file_data),mime,desc,'admin'))
            return self._j({"ok":True,"name":orig_name,"size":len(file_data)})

        # ── CHECKER: SMTP ─────────────────────────────────────────────────────
        if path=='/api/checker/smtp':
            lines=body.get('lines','')
            if isinstance(lines,str):lines=[l.strip() for l in lines.splitlines() if l.strip()]
            if not lines:return self._j({"error":"No targets"},400)
            _ukid=_kid(auth)
            results=[]
            def _chk_smtp(line):
                parts=line.split('|') if '|' in line else line.split(':')
                if len(parts)<3:return
                host_port,user,pwd=parts[0],parts[1],':'.join(parts[2:])
                if ':' in host_port:h,p=host_port.rsplit(':',1);p=int(p)
                else:h=host_port;p=587
                t0=time.time()
                try:
                    ctx=ssl.create_default_context();ctx.check_hostname=False;ctx.verify_mode=ssl.CERT_NONE
                    if p==465:srv=smtplib.SMTP_SSL(h,p,timeout=8,context=ctx)
                    else:srv=smtplib.SMTP(h,p,timeout=8);srv.ehlo()
                    if p==587:
                        try:srv.starttls(context=ctx);srv.ehlo()
                        except:pass
                    srv.login(user,pwd);srv.quit()
                    st='live';err=''
                except smtplib.SMTPAuthenticationError:st='dead';err='Auth failed'
                except Exception as ex:st='timeout' if 'timed out' in str(ex).lower() else 'dead';err=str(ex)[:80]
                rt=round(time.time()-t0,2)
                q("INSERT INTO checker_results(key_id,check_type,target,username,password,status,response_time,extra)VALUES(?,?,?,?,?,?,?,?)",
                  (_ukid,'smtp',h,user,pwd,st,rt,err))
                results.append({'host':h,'port':p,'user':user,'status':st,'rt':rt,'error':err})
            import concurrent.futures as _cf
            with _cf.ThreadPoolExecutor(max_workers=min(20,len(lines))) as ex:
                list(ex.map(_chk_smtp,lines[:500]))
            live=sum(1 for r in results if r['status']=='live')
            return self._j({"ok":True,"total":len(results),"live":live,"dead":len(results)-live,"results":results})

        # ── CHECKER: WEBMAIL ──────────────────────────────────────────────────
        if path=='/api/checker/webmail':
            lines=body.get('lines','')
            if isinstance(lines,str):lines=[l.strip() for l in lines.splitlines() if l.strip()]
            if not lines:return self._j({"error":"No targets"},400)
            _ukid=_kid(auth)
            results=[]
            import urllib.request as _ur2
            def _chk_wm(line):
                parts=line.split('|') if '|' in line else line.split(':',2)
                if len(parts)<3:return
                url,user,pwd=parts[0].strip(),parts[1].strip(),parts[2].strip()
                if not url.startswith('http'):url='https://'+url
                t0=time.time()
                try:
                    data_=json.dumps({'email':user,'password':pwd}).encode()
                    req=_ur2.Request(url+'/api/auth/login' if 'roundcube' not in url.lower() else url,
                                     data=data_,method='POST',
                                     headers={'Content-Type':'application/json','User-Agent':'Mozilla/5.0'})
                    with _ur2.urlopen(req,timeout=8) as r:
                        txt=r.read().decode(errors='replace')
                    st='live' if (r.status<400 and ('token' in txt or 'inbox' in txt.lower() or 'success' in txt.lower())) else 'dead'
                except Exception as ex:
                    st='timeout' if 'timed out' in str(ex).lower() else 'dead';txt=str(ex)[:80]
                rt=round(time.time()-t0,2)
                q("INSERT INTO checker_results(key_id,check_type,target,username,password,status,response_time)VALUES(?,?,?,?,?,?,?)",
                  (_ukid,'webmail',url,user,pwd,st,rt))
                results.append({'url':url,'user':user,'status':st,'rt':rt})
            import concurrent.futures as _cf2
            with _cf2.ThreadPoolExecutor(max_workers=min(20,len(lines))) as ex:
                list(ex.map(_chk_wm,lines[:500]))
            live=sum(1 for r in results if r['status']=='live')
            return self._j({"ok":True,"total":len(results),"live":live,"results":results})

        # ── CHECKER: CPANEL ──────────────────────────────────────────────────
        if path=='/api/checker/cpanel':
            lines=body.get('lines','')
            if isinstance(lines,str):lines=[l.strip() for l in lines.splitlines() if l.strip()]
            if not lines:return self._j({"error":"No targets"},400)
            _ukid=_kid(auth)
            results=[]
            import urllib.request as _ur3
            def _chk_cp(line):
                parts=line.split('|') if '|' in line else line.split(':',2)
                if len(parts)<3:return
                domain,user,pwd=parts[0].strip(),parts[1].strip(),parts[2].strip()
                if not domain.startswith('http'):domain='https://'+domain
                t0=time.time()
                st='dead';detail=''
                for port in [2083,2082]:
                    try:
                        creds=base64.b64encode(f'{user}:{pwd}'.encode()).decode()
                        req=_ur3.Request(f"{domain.rstrip('/')}:{port}",
                                         headers={'Authorization':f'Basic {creds}','User-Agent':'Mozilla/5.0'})
                        with _ur3.urlopen(req,timeout=8) as r:
                            txt=r.read().decode(errors='replace')
                        if r.status==200 and ('cPanel' in txt or 'logout' in txt.lower() or 'Home' in txt):
                            st='live';break
                    except Exception as ex:
                        detail=str(ex)[:60]
                rt=round(time.time()-t0,2)
                q("INSERT INTO checker_results(key_id,check_type,target,username,password,status,response_time,extra)VALUES(?,?,?,?,?,?,?,?)",
                  (_ukid,'cpanel',domain,user,pwd,st,rt,detail))
                results.append({'domain':domain,'user':user,'status':st,'rt':rt})
            import concurrent.futures as _cf3
            with _cf3.ThreadPoolExecutor(max_workers=min(15,len(lines))) as ex:
                list(ex.map(_chk_cp,lines[:300]))
            live=sum(1 for r in results if r['status']=='live')
            return self._j({"ok":True,"total":len(results),"live":live,"results":results})

        # ── CHECKER: DOMAIN ──────────────────────────────────────────────────
        if path=='/api/checker/domain':
            domains=body.get('domains','')
            if isinstance(domains,str):domains=[d.strip() for d in domains.splitlines() if d.strip()]
            if not domains:return self._j({"error":"No domains"},400)
            results=[]
            import socket as _sk2
            def _chk_dom(d):
                d=d.lower().strip()
                t0=time.time()
                try:
                    ip=_sk2.gethostbyname(d)
                    status='live';detail=ip
                except:
                    status='dead';detail='No DNS'
                rt=round(time.time()-t0,2)
                results.append({'domain':d,'status':status,'detail':detail,'rt':rt})
            import concurrent.futures as _cf4
            with _cf4.ThreadPoolExecutor(max_workers=30) as ex:
                list(ex.map(_chk_dom,domains[:1000]))
            return self._j({"ok":True,"total":len(results),"live":sum(1 for r in results if r['status']=='live'),"results":results})

        # ── MAIL.TM: CREATE ──────────────────────────────────────────────────
        if path=='/api/mailtm/create':
            count=min(int(body.get('count',1)),50)
            _ukid=_kid(auth)
            import urllib.request as _urm
            created=[]
            def _mk_tm():
                try:
                    # Get domains
                    req=_urm.Request('https://api.mail.tm/domains',headers={'Content-Type':'application/json'})
                    with _urm.urlopen(req,timeout=10) as r:doms=json.loads(r.read())
                    dom=doms['hydra:member'][0]['domain']
                    user=''.join(random.choices('abcdefghijklmnopqrstuvwxyz0123456789',k=10))
                    addr=f'{user}@{dom}'
                    pwd=''.join(random.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOP0123456789!@#',k=14))
                    # Create account
                    data=json.dumps({'address':addr,'password':pwd}).encode()
                    req=_urm.Request('https://api.mail.tm/accounts',data=data,method='POST',headers={'Content-Type':'application/json'})
                    with _urm.urlopen(req,timeout=10) as r:r.read()
                    # Get token
                    data=json.dumps({'address':addr,'password':pwd}).encode()
                    req=_urm.Request('https://api.mail.tm/token',data=data,method='POST',headers={'Content-Type':'application/json'})
                    with _urm.urlopen(req,timeout=10) as r:tok=json.loads(r.read())
                    token=tok.get('token','')
                    q("INSERT OR IGNORE INTO mailtm_accounts(key_id,address,password,token)VALUES(?,?,?,?)",(_ukid,addr,pwd,token))
                    created.append({'address':addr,'password':pwd,'token':token[:20]+'...' if token else ''})
                except Exception as ex:
                    created.append({'error':str(ex)[:80]})
            import concurrent.futures as _cfm
            with _cfm.ThreadPoolExecutor(max_workers=min(10,count)) as ex:
                list(ex.map(lambda _:_mk_tm(),range(count)))
            return self._j({"ok":True,"created":created})

        if path=='/api/mailtm/delete':
            amid=body.get('id')
            _uf,_up=_ufilter(auth)
            if amid:q(f"DELETE FROM mailtm_accounts WHERE id=? {_uf}",(amid,)+_up)
            return self._j({"ok":True})

        if path=='/api/checker/clear':
            _uf,_up=_ufilter(auth)
            ctype=body.get('type','')
            if ctype:q(f"DELETE FROM checker_results WHERE check_type=? {_uf}",(ctype,)+_up)
            else:q(f"DELETE FROM checker_results {_uf.replace('AND','WHERE',1) if _uf else ''}",_up)
            return self._j({"ok":True})

        return self._j({"error":"Not found"},404)

    def do_DELETE(self):
        try:
            self._do_DELETE_inner()
        except Exception as e:
            log.error(f"[DELETE] unhandled: {e}")
            try:self._j({"error":"Internal server error"},500)
            except:pass

    def _do_DELETE_inner(self):
        if not self._sec():return
        path=urlparse(self.path).path;auth=self._auth()
        if not auth:return self._j({"error":"Auth required"},401)
        _uf,_up=_ufilter(auth)
        _uw,_uwp=_uwhere(auth)
        if path=='/api/smtp/die':return self._j({"deleted":q(f"DELETE FROM smtp WHERE status='die' {_uf}",_up)})
        if path=='/api/smtp':return self._j({"deleted":q(f"DELETE FROM smtp {_uw}",_uwp)})
        if path.startswith('/api/smtp/'):return self._j({"deleted":q(f"DELETE FROM smtp WHERE id=? {_uf}",(int(path.split('/')[-1]),)+_up)})
        if path=='/api/webmail/die':return self._j({"deleted":q(f"DELETE FROM webmail WHERE status='die' {_uf}",_up)})
        if path=='/api/webmail':return self._j({"deleted":q(f"DELETE FROM webmail {_uw}",_uwp)})
        if path.startswith('/api/webmail/'):return self._j({"deleted":q(f"DELETE FROM webmail WHERE id=? {_uf}",(int(path.split('/')[-1]),)+_up)})
        if path=='/api/proxy/die':return self._j({"deleted":q(f"DELETE FROM proxy WHERE status='die' {_uf}",_up)})
        if path=='/api/proxy':return self._j({"deleted":q(f"DELETE FROM proxy {_uw}",_uwp)})
        if path.startswith('/api/proxy/'):return self._j({"deleted":q(f"DELETE FROM proxy WHERE id=? {_uf}",(int(path.split('/')[-1]),)+_up)})
        if path=='/api/mail':return self._j({"deleted":q(f"DELETE FROM mail {_uw}",_uwp)})
        if path.startswith('/api/templates/'):
            tid=int(path.split('/')[-1])
            q(f"DELETE FROM templates WHERE id=? {_uf}",(tid,)+_up)
            return self._j({"ok":True})
        if path.startswith('/api/blacklist/email/'):
            bid=int(path.split('/')[-1])
            q("DELETE FROM email_blacklist WHERE id=?",(bid,))
            return self._j({"ok":True})
        if path.startswith('/api/mail/'):return self._j({"deleted":q(f"DELETE FROM mail WHERE id=? {_uf}",(int(path.split('/')[-1]),)+_up)})
        if path=='/api/logs':
            if not _is_admin(auth):return self._j({"error":"Admin only"},403)
            q("DELETE FROM logs");return self._j({"ok":True})
        if path.startswith('/api/webhooks/'):q("DELETE FROM webhook_config WHERE id=?",(int(path.split('/')[-1]),));return self._j({"ok":True})
        if path.startswith('/api/custom-hosts/'):
            chid=int(path.split('/')[-1])
            q(f"DELETE FROM custom_hosts WHERE id=? {_uf}",(chid,)+_up)
            return self._j({"ok":True})
        if path.startswith('/api/cloud/'):
            if not _is_admin(auth):return self._j({"error":"Admin only"},403)
            fid=int(path.split('/')[-1])
            row=q("SELECT filename FROM cloud_files WHERE id=?",(fid,),fetch=True)
            if row:
                fp=os.path.join(CLOUD_DIR,row[0]['filename'])
                try:os.remove(fp)
                except:pass
                q("DELETE FROM cloud_files WHERE id=?",(fid,))
            return self._j({"ok":True})
        if path.startswith('/api/checker/'):
            _uf2,_up2=_ufilter(auth)
            rid=int(path.split('/')[-1])
            q(f"DELETE FROM checker_results WHERE id=? {_uf2}",(rid,)+_up2)
            return self._j({"ok":True})
        if path.startswith('/api/mailtm/'):
            _uf2,_up2=_ufilter(auth)
            amid=int(path.split('/')[-1])
            q(f"DELETE FROM mailtm_accounts WHERE id=? {_uf2}",(amid,)+_up2)
            return self._j({"ok":True})
        return self._j({"error":"Not found"},404)

def _start_background_workers():
    init_db()
    threading.Thread(target=sched_worker,   daemon=True).start()
    threading.Thread(target=_session_cleanup,daemon=True).start()
    if BOT_TOKEN and ADMIN_TG:
        threading.Thread(target=bot_polling,daemon=True).start()
    else:
        log.warning("Bot polling disabled: MAILER_BOT_TOKEN or MAILER_ADMIN_TG not set")

# Called on import — works for both direct run and gunicorn
_start_background_workers()

if __name__=='__main__':
    log.info(f"Server  : http://0.0.0.0:{PORT}")
    log.info(f"Login   : http://localhost:{PORT}/login")
    log.info(f"Bot     : polling ...{BOT_TOKEN[-8:]}")
    log.info(f"Logs    : {LOG_DIR}/")
    # SO_REUSEADDR — prevents 'Address already in use' on restart
    import socket as _sock
    class _Server(HTTPServer):
        allow_reuse_address = True
        def server_bind(self):
            self.socket.setsockopt(_sock.SOL_SOCKET, _sock.SO_REUSEADDR, 1)
            super().server_bind()
    server = _Server(('0.0.0.0', PORT), H)
    log.info(f"Listening on :{PORT}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        log.info("Shutdown")
        server.server_close()
