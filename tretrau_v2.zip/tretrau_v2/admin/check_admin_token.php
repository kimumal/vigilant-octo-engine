<?php
/**
 * Check if admin token has been verified via Telegram
 * Called by JS polling in admin auth page
 */
require_once '../config.php';
startSession();

header('Content-Type: application/json');

$token = preg_replace('/[^a-zA-Z0-9]/', '', $_GET['token'] ?? '');
if (!$token) {
    echo json_encode(['verified' => false, 'denied' => false]);
    exit;
}

$user = currentUser();
if (!$user) {
    echo json_encode(['verified' => false, 'denied' => false, 'error' => 'not_logged_in']);
    exit;
}

$db = getDB();

// Check if token exists and used=1 (verified by bot)
$stmt = $db->prepare("SELECT * FROM admin_tokens WHERE token=? AND user_id=?");
$stmt->execute([$token, $user['id']]);
$row = $stmt->fetch();

if (!$row) {
    // Token deleted = denied by bot
    echo json_encode(['verified' => false, 'denied' => true]);
    exit;
}

if ((int)$row['used'] === 1 && strtotime($row['expires_at']) > time()) {
    // Verified! Set session so redirect works
    $_SESSION['admin_verified'] = time();
    echo json_encode(['verified' => true, 'denied' => false]);
    exit;
}

if (strtotime($row['expires_at']) <= time()) {
    // Expired
    $db->prepare("DELETE FROM admin_tokens WHERE token=?")->execute([$token]);
    echo json_encode(['verified' => false, 'denied' => false, 'expired' => true]);
    exit;
}

// Still waiting
echo json_encode(['verified' => false, 'denied' => false, 'waiting' => true]);
