<?php
/**
 * Telegram Webhook — xử lý callback từ inline buttons
 *
 * Đăng ký webhook (chạy 1 lần):
 * https://api.telegram.org/botTOKEN/setWebhook?url=https://YOURDOMAIN.COM/admin/webhook.php
 *
 * Hoặc dùng start.py để polling thay thế webhook.
 */
require_once '../config.php';

// GET request — just confirm webhook is alive (no info leak)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    header('Content-Type: application/json');
    echo json_encode(['status' => 'ok']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

$input  = file_get_contents('php://input');
$update = json_decode($input, true);
if (!$update) { http_response_code(400); exit; }

$botToken = TELEGRAM_BOT_TOKEN;
$db       = getDB();

// ── Helpers ──────────────────────────────────────────────────

function tgPost(string $method, array $data): ?array {
    global $botToken;
    $json = json_encode($data, JSON_UNESCAPED_UNICODE);
    $opts = [
        'http' => [
            'method'        => 'POST',
            'header'        => "Content-Type: application/json\r\n",
            'content'       => $json,
            'timeout'       => 5,
            'ignore_errors' => true,
        ],
        'ssl' => ['verify_peer' => false, 'verify_peer_name' => false],
    ];
    $result = @file_get_contents(
        "https://api.telegram.org/bot{$botToken}/{$method}",
        false,
        stream_context_create($opts)
    );
    return $result ? json_decode($result, true) : null;
}

function answerCallback(string $cbId, string $text = '', bool $alert = false): void {
    tgPost('answerCallbackQuery', [
        'callback_query_id' => $cbId,
        'text'              => $text,
        'show_alert'        => $alert,
    ]);
}

function editMessage(string|int $chatId, int $msgId, string $text): void {
    tgPost('editMessageText', [
        'chat_id'    => $chatId,
        'message_id' => $msgId,
        'text'       => $text,
        'parse_mode' => 'HTML',
    ]);
}

// ── Xử lý callback_query ─────────────────────────────────────

if (isset($update['callback_query'])) {
    $cb     = $update['callback_query'];
    $cbId   = $cb['id'];
    $data   = $cb['data'] ?? '';
    $chatId = (string)($cb['message']['chat']['id'] ?? 0);
    $msgId  = (int)($cb['message']['message_id'] ?? 0);
    $from   = '@' . ($cb['from']['username'] ?? $cb['from']['first_name'] ?? 'Admin');

    // Bảo vệ: chỉ xử lý từ đúng chat admin
    if (trim($chatId) !== trim((string)TELEGRAM_ADMIN_CHAT_ID)) {
        answerCallback($cbId, 'Khong co quyen!', true);
        http_response_code(200); exit;
    }

    // ── ✅ DUYỆT BÀI ĐĂNG ───────────────────────────────────
    if (str_starts_with($data, 'approve_product:')) {
        $pid = (int)preg_replace('/[^0-9]/', '', substr($data, 16));

        $stmt = $db->prepare("SELECT p.*, u.username FROM products p JOIN users u ON u.id=p.user_id WHERE p.id=? AND p.status='pending'");
        $stmt->execute([$pid]);
        $product = $stmt->fetch();

        if ($product) {
            $db->prepare("UPDATE products SET status='active' WHERE id=?")->execute([$pid]);
            answerCallback($cbId, '✅ Đã duyệt bài đăng!', false);
            editMessage($chatId, $msgId,
                "✅ <b>ĐÃ DUYỆT BÀI ĐĂNG</b>\n\n" .
                "📦 <b>" . htmlspecialchars($product['title']) . "</b>\n" .
                "👤 Người đăng: " . htmlspecialchars($product['username']) . "\n" .
                "🆔 ID: <code>{$pid}</code>\n" .
                "✅ Duyệt bởi: {$from}\n" .
                "🕐 " . date('d/m/Y H:i:s')
            );
        } else {
            answerCallback($cbId, '⚠️ Bài đăng không tồn tại hoặc đã xử lý!', true);
            editMessage($chatId, $msgId, "⚠️ <b>Bài đăng #{$pid}</b> không tồn tại hoặc đã được xử lý trước đó.");
        }
    }

    // ── ❌ TỪ CHỐI BÀI ĐĂNG ─────────────────────────────────
    elseif (str_starts_with($data, 'reject_product:')) {
        $pid = (int)preg_replace('/[^0-9]/', '', substr($data, 15));

        $stmt = $db->prepare("SELECT p.*, u.username FROM products p JOIN users u ON u.id=p.user_id WHERE p.id=? AND p.status='pending'");
        $stmt->execute([$pid]);
        $product = $stmt->fetch();

        if ($product) {
            $db->prepare("UPDATE products SET status='rejected', deleted_at=NOW(), rejection_reason='Bị từ chối bởi admin' WHERE id=?")->execute([$pid]);
            answerCallback($cbId, '❌ Đã từ chối bài đăng!', false);
            editMessage($chatId, $msgId,
                "❌ <b>ĐÃ TỪ CHỐI BÀI ĐĂNG</b>\n\n" .
                "📦 <b>" . htmlspecialchars($product['title']) . "</b>\n" .
                "👤 Người đăng: " . htmlspecialchars($product['username']) . "\n" .
                "🆔 ID: <code>{$pid}</code>\n" .
                "❌ Từ chối bởi: {$from}\n" .
                "🕐 " . date('d/m/Y H:i:s')
            );
        } else {
            answerCallback($cbId, '⚠️ Bài đăng không tồn tại hoặc đã xử lý!', true);
            editMessage($chatId, $msgId, "⚠️ <b>Bài đăng #{$pid}</b> không tồn tại hoặc đã được xử lý trước đó.");
        }
    }

    // ── ✅ XÁC THỰC ADMIN ────────────────────────────────────
    elseif (str_starts_with($data, 'verify_admin:')) {
        $token = preg_replace('/[^a-zA-Z0-9]/', '', substr($data, 13));

        $stmt = $db->prepare("UPDATE admin_tokens SET used=1 WHERE token=? AND used=0 AND expires_at > NOW()");
        $stmt->execute([$token]);

        if ($stmt->rowCount() > 0) {
            answerCallback($cbId, '✅ Đã xác thực! Admin đang vào panel...', false);
            editMessage($chatId, $msgId,
                "✅ <b>ĐÃ XÁC THỰC ADMIN</b>\n" .
                "🔑 Token: <code>" . substr($token, 0, 12) . "...</code>\n" .
                "✅ Xác thực bởi: {$from}\n" .
                "🕐 " . date('d/m/Y H:i:s')
            );
        } else {
            answerCallback($cbId, '⚠️ Token đã hết hạn hoặc đã dùng!', true);
        }
    }

    // ── ❌ TỪ CHỐI ADMIN ─────────────────────────────────────
    elseif (str_starts_with($data, 'deny_admin:')) {
        $token = preg_replace('/[^a-zA-Z0-9]/', '', substr($data, 11));

        $db->prepare("DELETE FROM admin_tokens WHERE token=?")->execute([$token]);

        answerCallback($cbId, '❌ Đã từ chối truy cập admin!', false);
        editMessage($chatId, $msgId,
            "❌ <b>ĐÃ TỪ CHỐI ADMIN</b>\n" .
            "🔑 Token: <code>" . substr($token, 0, 12) . "...</code>\n" .
            "❌ Từ chối bởi: {$from}\n" .
            "🕐 " . date('d/m/Y H:i:s')
        );
    }

    // Legacy fallback
    elseif ($data === 'deny_admin') {
        answerCallback($cbId, 'Da tu choi!', false);
    }
}

http_response_code(200);
echo 'OK';
