<?php
/**
 * backup.php — Full Backup Tool (Database + Uploads)
 * Only accessible by logged-in admin users via admin panel
 * Additional protections: 2FA session, rate limiting, Telegram notification
 */
require_once 'config.php';

startSession();
$_bkUser = currentUser();
if (!$_bkUser || $_bkUser['role'] !== 'admin') {
    http_response_code(403);
    die(json_encode(['error' => 'Access denied. Admin login required.']));
}

// Require admin session verification (Telegram 2FA must have been completed)
if (empty($_SESSION['admin_verified']) || (time() - $_SESSION['admin_verified']) > 7200) {
    http_response_code(403);
    die(json_encode(['error' => 'Admin 2FA session expired. Please verify via Telegram first.']));
}

// Rate limit backups: max 3 per hour
if (!rateLimit('backup_' . $_bkUser['id'], 3, 3600)) {
    http_response_code(429);
    die(json_encode(['error' => 'Too many backup requests. Max 3 per hour.']));
}

logTraffic('backup', 'admin_backup', ['admin_id' => $_bkUser['id'], 'ip' => getUserIP()]);

try {
    $act = $_GET['action'] ?? 'ui';
    $msg = "📦 <b>BACKUP REQUEST</b>\n"
         . "Action: <code>{$act}</code>\n"
         . "Admin: <code>" . htmlspecialchars($_bkUser['username']) . "</code>\n"
         . "IP: <code>" . getUserIP() . "</code>\n"
         . "Time: " . date('d/m/Y H:i:s');
    sendTelegram($msg);
} catch (\Throwable $e) {}

$action = $_GET['action'] ?? 'ui';

// ============================================================
// TẠO SQL BACKUP STRING
// ============================================================
function createSQLBackup(PDO $db): string {
    $tables = ['users','products','chat_channels','messages','traffic_logs','reports','admin_tokens','pending_notifications'];
    $sql  = "-- TreTrau Network Database Backup\n";
    $sql .= "-- Generated: " . date('Y-m-d H:i:s') . "\n";
    $sql .= "-- Server: " . ($_SERVER['HTTP_HOST'] ?? 'localhost') . "\n\n";
    $sql .= "SET FOREIGN_KEY_CHECKS=0;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\nSET NAMES utf8mb4;\n\n";

    foreach ($tables as $table) {
        try {
            $row = $db->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
            if (!$row) continue;
            $sql .= "-- --------------------------------------------------------\n-- Table: `$table`\n-- --------------------------------------------------------\n\n";
            $sql .= "DROP TABLE IF EXISTS `$table`;\n" . $row[1] . ";\n\n";
            $rows = $db->query("SELECT * FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
            if (empty($rows)) { $sql .= "-- No data in `$table`\n\n"; continue; }
            $colList = '`' . implode('`, `', array_keys($rows[0])) . '`';
            $sql .= "INSERT INTO `$table` ($colList) VALUES\n";
            $vals = [];
            foreach ($rows as $r) {
                $escaped = array_map(fn($v) => $v === null ? 'NULL' : $db->quote((string)$v), array_values($r));
                $vals[] = '(' . implode(', ', $escaped) . ')';
            }
            $sql .= implode(",\n", $vals) . ";\n\n";
        } catch (\Throwable $e) {
            $sql .= "-- ERROR backing up `$table`: " . $e->getMessage() . "\n\n";
        }
    }
    $sql .= "SET FOREIGN_KEY_CHECKS=1;\n-- End of backup\n";
    return $sql;
}

// ============================================================
// TẠO FULL ZIP (Database SQL + Uploads folder)
// ============================================================
function createFullZipBackup(PDO $db, string $destPath): array {
    $zip = new ZipArchive();
    $result = $zip->open($destPath, ZipArchive::CREATE | ZipArchive::OVERWRITE);
    if ($result !== true) return ['error' => 'Cannot create ZIP (code: ' . $result . ')'];

    $stats = ['sql_size'=>0, 'upload_files'=>0, 'upload_size'=>0, 'total_size'=>0, 'skipped'=>0];

    // 1. SQL dump
    $sql = createSQLBackup($db);
    $sqlFile = 'database_' . date('Y-m-d_H-i-s') . '.sql';
    $zip->addFromString($sqlFile, $sql);
    $stats['sql_size'] = strlen($sql);

    // 2. Folder uploads
    $uploadsDir = realpath(__DIR__ . '/uploads');
    if ($uploadsDir && is_dir($uploadsDir)) {
        $iter = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($uploadsDir, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        $maxSingle = 50 * 1024 * 1024;   // 50MB per file
        $maxTotal  = 500 * 1024 * 1024;   // 500MB total uploads
        $dangerousExt = ['php','php3','php4','php5','php7','phtml','phar','sh','py','pl','cgi','log','htaccess','htpasswd'];

        foreach ($iter as $file) {
            if (!$file->isFile()) continue;
            $basename = $file->getBasename();
            if (str_starts_with($basename, '.')) continue;
            $ext = strtolower($file->getExtension());
            if (in_array($ext, $dangerousExt)) continue;
            $sz = $file->getSize();
            if ($sz > $maxSingle || $stats['upload_size'] + $sz > $maxTotal) { $stats['skipped']++; continue; }

            $rel = 'uploads/' . str_replace('\\', '/', substr($file->getRealPath(), strlen($uploadsDir) + 1));
            $zip->addFile($file->getRealPath(), $rel);
            $stats['upload_files']++;
            $stats['upload_size'] += $sz;
        }
    }

    // 3. Info file
    $info  = "TreTrau Network Full Backup\n===========================\n";
    $info .= "Date: " . date('Y-m-d H:i:s') . "\n";
    $info .= "Contents:\n  - {$sqlFile}\n  - uploads/ ({$stats['upload_files']} files, " . fmtSize($stats['upload_size']) . ")\n";
    if ($stats['skipped'] > 0) $info .= "  - Skipped: {$stats['skipped']} files (too large)\n";
    $info .= "\nRestore:\n  1. Extract zip\n  2. Import SQL: mysql -u USER -p DB < {$sqlFile}\n  3. Copy uploads/ to web root\n  4. Update .env.tretrau\n";
    $zip->addFromString('BACKUP_INFO.txt', $info);
    $zip->close();

    $stats['total_size'] = filesize($destPath);
    return $stats;
}

function fmtSize(int $b): string {
    if ($b >= 1073741824) return round($b / 1073741824, 2) . ' GB';
    if ($b >= 1048576) return round($b / 1048576, 2) . ' MB';
    if ($b >= 1024) return round($b / 1024, 1) . ' KB';
    return $b . ' B';
}

// ============================================================
// ACTIONS
// ============================================================

// ── Download full ZIP ──
if ($action === 'download_full') {
    set_time_limit(300);
    $tmp = sys_get_temp_dir() . '/tretrau_full_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.zip';
    $stats = createFullZipBackup(getDB(), $tmp);
    if (isset($stats['error'])) { http_response_code(500); die(json_encode($stats)); }
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="tretrau_full_backup_' . date('Y-m-d_H-i-s') . '.zip"');
    header('Content-Length: ' . filesize($tmp));
    header('Cache-Control: no-store');
    readfile($tmp);
    @unlink($tmp);
    exit;
}

// ── Download SQL only ──
if ($action === 'download') {
    $sql = createSQLBackup(getDB());
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="tretrau_backup_' . date('Y-m-d_H-i-s') . '.sql"');
    header('Content-Length: ' . strlen($sql));
    echo $sql;
    exit;
}

// ── Save full ZIP on server ──
if ($action === 'save_full') {
    set_time_limit(300);
    $dir = __DIR__ . '/backups/';
    if (!is_dir($dir)) mkdir($dir, 0750, true);
    if (!file_exists($dir . '.htaccess')) file_put_contents($dir . '.htaccess', "Order deny,allow\nDeny from all\n");

    $fname = 'tretrau_full_' . date('Y-m-d_H-i-s') . '.zip';
    $stats = createFullZipBackup(getDB(), $dir . $fname);
    if (isset($stats['error'])) { http_response_code(500); die(json_encode($stats)); }

    // Keep max 5 zip backups
    $files = glob($dir . '*.zip');
    if ($files && count($files) > 5) {
        usort($files, fn($a, $b) => filemtime($a) - filemtime($b));
        foreach (array_slice($files, 0, count($files) - 5) as $old) @unlink($old);
    }

    header('Content-Type: application/json');
    echo json_encode(['success'=>true, 'file'=>$fname, 'total_size'=>fmtSize($stats['total_size']),
        'sql_size'=>fmtSize($stats['sql_size']), 'upload_files'=>$stats['upload_files'],
        'upload_size'=>fmtSize($stats['upload_size']), 'skipped'=>$stats['skipped']]);
    exit;
}

// ── Save SQL only ──
if ($action === 'save') {
    $dir = __DIR__ . '/backups/';
    if (!is_dir($dir)) mkdir($dir, 0750, true);
    if (!file_exists($dir . '.htaccess')) file_put_contents($dir . '.htaccess', "Deny from all\n");
    $sql = createSQLBackup(getDB());
    $fname = 'tretrau_backup_' . date('Y-m-d_H-i-s') . '.sql';
    file_put_contents($dir . $fname, $sql);
    $files = glob($dir . '*.sql');
    if ($files && count($files) > 10) {
        usort($files, fn($a, $b) => filemtime($a) - filemtime($b));
        foreach (array_slice($files, 0, count($files) - 10) as $old) @unlink($old);
    }
    header('Content-Type: application/json');
    echo json_encode(['success'=>true, 'file'=>$fname, 'size'=>strlen($sql)]);
    exit;
}

// ── List backups ──
if ($action === 'list') {
    $dir = __DIR__ . '/backups/';
    $all = array_merge(glob($dir . '*.sql') ?: [], glob($dir . '*.zip') ?: []);
    usort($all, fn($a, $b) => filemtime($b) - filemtime($a));
    $list = array_map(fn($f) => [
        'name'=>basename($f), 'type'=>pathinfo($f, PATHINFO_EXTENSION)==='zip'?'full':'sql',
        'size'=>fmtSize(filesize($f)), 'size_bytes'=>filesize($f),
        'date'=>date('d/m/Y H:i:s', filemtime($f)),
    ], $all);
    header('Content-Type: application/json');
    echo json_encode(['backups'=>$list]);
    exit;
}

// ── Delete backup ──
if ($action === 'delete') {
    $file = basename($_GET['file'] ?? '');
    if (!$file || !preg_match('/^tretrau_(full_|backup_)[\d\-_]+\.(sql|zip)$/', $file)) die(json_encode(['error'=>'Invalid filename']));
    $path = __DIR__ . '/backups/' . $file;
    if (file_exists($path)) { @unlink($path); echo json_encode(['success'=>true]); }
    else echo json_encode(['error'=>'File not found']);
    exit;
}

// ── Stats ──
if ($action === 'stats') {
    $db = getDB();
    $stats = [];
    foreach (['users','products','messages','chat_channels'] as $t) {
        try { $stats[$t] = $db->query("SELECT COUNT(*) FROM `$t`")->fetchColumn(); } catch (\Throwable $e) { $stats[$t] = '?'; }
    }
    $uploadsDir = __DIR__ . '/uploads/';
    $uc = 0; $us = 0;
    if (is_dir($uploadsDir)) {
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($uploadsDir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::LEAVES_ONLY);
        foreach ($it as $f) {
            if ($f->isFile() && !str_starts_with($f->getBasename(), '.') && !in_array(strtolower($f->getExtension()), ['php','htaccess','log'])) {
                $uc++; $us += $f->getSize();
            }
        }
    }
    $stats['upload_files'] = $uc;
    $stats['upload_size'] = fmtSize($us);
    $stats['upload_size_bytes'] = $us;
    header('Content-Type: application/json');
    echo json_encode($stats);
    exit;
}

// ── Send full ZIP qua Telegram ──
if ($action === 'send_telegram') {
    set_time_limit(300);
    $tmp = sys_get_temp_dir() . '/tretrau_tg_' . date('Ymd_His') . '.zip';
    $stats = createFullZipBackup(getDB(), $tmp);
    if (isset($stats['error'])) { @unlink($tmp); die(json_encode($stats)); }
    $fsize = filesize($tmp);
    if ($fsize > 49 * 1024 * 1024) { @unlink($tmp); die(json_encode(['error'=>'ZIP quá lớn cho Telegram ('.fmtSize($fsize).'). Max 50MB. Hãy tải xuống thay thế.'])); }

    $caption = "💾 TreTrau Full Backup\n📅 " . date('d/m/Y H:i:s') . "\n📦 " . fmtSize($fsize) . "\n🗄 DB: " . fmtSize($stats['sql_size']) . "\n🖼 Uploads: {$stats['upload_files']} files (" . fmtSize($stats['upload_size']) . ")";
    $ch = curl_init("https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendDocument");
    curl_setopt_array($ch, [CURLOPT_POST=>true, CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>120, CURLOPT_CONNECTTIMEOUT=>10, CURLOPT_SSL_VERIFYPEER=>false,
        CURLOPT_POSTFIELDS=>['chat_id'=>TELEGRAM_ADMIN_CHAT_ID, 'document'=>new CURLFile($tmp,'application/zip','tretrau_full_backup_'.date('Y-m-d_H-i-s').'.zip'), 'caption'=>$caption]]);
    $result = curl_exec($ch); $err = curl_error($ch); curl_close($ch);
    @unlink($tmp);
    header('Content-Type: application/json');
    if ($err) { echo json_encode(['error'=>'Curl: '.$err]); exit; }
    $resp = json_decode($result, true);
    echo json_encode(($resp['ok'] ?? false) ? ['success'=>true,'message'=>'Đã gửi Full Backup ZIP qua Telegram! ('.fmtSize($fsize).')'] : ['error'=>$resp['description'] ?? 'Telegram error']);
    exit;
}

// ── Send SQL only qua Telegram ──
if ($action === 'send_telegram_sql') {
    $sql = createSQLBackup(getDB());
    $tmp = sys_get_temp_dir() . '/tretrau_backup_' . date('Y-m-d_H-i-s') . '.sql';
    file_put_contents($tmp, $sql);
    $caption = "🗄 TreTrau SQL Backup\n📅 " . date('d/m/Y H:i:s') . "\n📦 " . fmtSize(strlen($sql));
    $ch = curl_init("https://api.telegram.org/bot" . TELEGRAM_BOT_TOKEN . "/sendDocument");
    curl_setopt_array($ch, [CURLOPT_POST=>true, CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>30, CURLOPT_SSL_VERIFYPEER=>false,
        CURLOPT_POSTFIELDS=>['chat_id'=>TELEGRAM_ADMIN_CHAT_ID, 'document'=>new CURLFile($tmp,'application/sql',basename($tmp)), 'caption'=>$caption]]);
    $result = curl_exec($ch); $err = curl_error($ch); curl_close($ch);
    @unlink($tmp);
    header('Content-Type: application/json');
    if ($err) { echo json_encode(['error'=>'Curl: '.$err]); exit; }
    $resp = json_decode($result, true);
    echo json_encode(($resp['ok'] ?? false) ? ['success'=>true,'message'=>'Đã gửi SQL qua Telegram!'] : ['error'=>$resp['description'] ?? 'Telegram error']);
    exit;
}

// ============================================================
// UI
// ============================================================
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>TreTrau Backup</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
body{background:#0d1117;color:#e6edf3;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;min-height:100vh;padding:24px}
.container{max-width:750px;margin:0 auto}
.header{display:flex;align-items:center;gap:12px;margin-bottom:32px;padding-bottom:16px;border-bottom:1px solid #21262d}
.logo{width:40px;height:40px;border-radius:8px;overflow:hidden}
.logo img{width:100%;height:100%;object-fit:cover}
h1{font-size:1.4rem;font-weight:700}
.card{background:#161b22;border:1px solid #21262d;border-radius:12px;padding:20px;margin-bottom:16px}
.card-title{font-size:.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.08em;color:#8b949e;margin-bottom:16px}
.btn{display:inline-flex;align-items:center;gap:8px;padding:10px 18px;border-radius:8px;border:none;cursor:pointer;font-size:.85rem;font-weight:600;transition:all .15s;text-decoration:none;color:#fff}
.btn-green{background:#238636}.btn-green:hover{background:#2ea043}
.btn-blue{background:#1f6feb}.btn-blue:hover{background:#388bfd}
.btn-tg{background:#0088cc}.btn-tg:hover{background:#00a0e9}
.btn-dark{background:#21262d;color:#e6edf3;border:1px solid #30363d}.btn-dark:hover{background:#30363d}
.btn-red{background:#da3633}.btn-red:hover{background:#f85149}
.btn:disabled{opacity:.5;cursor:not-allowed}
.btn svg{flex-shrink:0}
.stats-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}
@media(max-width:600px){.stats-grid{grid-template-columns:repeat(2,1fr)}}
.stat-item{background:#0d1117;border:1px solid #21262d;border-radius:8px;padding:12px 14px}
.stat-value{font-size:1.4rem;font-weight:800;color:#58a6ff}
.stat-label{font-size:.72rem;color:#8b949e;margin-top:2px}
.actions{display:flex;gap:10px;flex-wrap:wrap}
.backup-list{display:flex;flex-direction:column;gap:8px}
.backup-item{display:flex;align-items:center;gap:10px;padding:10px 12px;background:#0d1117;border:1px solid #21262d;border-radius:8px;font-size:.83rem}
.backup-icon{font-size:1.2rem}
.backup-info{flex:1;min-width:0}
.backup-name{font-family:monospace;color:#58a6ff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:.8rem}
.backup-meta{color:#8b949e;font-size:.72rem;margin-top:2px}
.backup-type{display:inline-block;padding:2px 6px;border-radius:4px;font-size:.65rem;font-weight:700;text-transform:uppercase}
.type-full{background:rgba(31,111,235,.2);color:#58a6ff}
.type-sql{background:rgba(35,134,54,.2);color:#56d364}
.btn-sm{padding:5px 10px;font-size:.75rem;border-radius:6px}
.status{padding:10px 14px;border-radius:8px;font-size:.85rem;margin-top:12px;display:none}
.status.success{background:rgba(35,134,54,.15);border:1px solid #238636;color:#56d364;display:block}
.status.error{background:rgba(218,54,51,.15);border:1px solid #da3633;color:#f85149;display:block}
.status.info{background:rgba(31,111,235,.15);border:1px solid #1f6feb;color:#58a6ff;display:block}
.warning{background:rgba(210,153,34,.12);border:1px solid #9e6a03;border-radius:8px;padding:12px 16px;font-size:.83rem;color:#e3b341;margin-bottom:16px}
.warning strong{display:block;margin-bottom:4px}
.progress-wrap{margin-top:12px;display:none}
.progress-bar{height:6px;background:#21262d;border-radius:3px;overflow:hidden}
.progress-fill{height:100%;background:linear-gradient(90deg,#238636,#58a6ff);border-radius:3px;transition:width .3s;width:0%}
.progress-text{font-size:.75rem;color:#8b949e;margin-top:4px}
.spinner{width:14px;height:14px;border:2px solid rgba(255,255,255,.3);border-top-color:#fff;border-radius:50%;animation:spin .6s linear infinite}
@keyframes spin{to{transform:rotate(360deg)}}
.tab-bar{display:flex;gap:0;margin-bottom:16px;border-bottom:1px solid #21262d}
.tab{padding:10px 16px;font-size:.85rem;font-weight:600;color:#8b949e;cursor:pointer;border-bottom:2px solid transparent;transition:all .15s}
.tab:hover{color:#e6edf3}
.tab.active{color:#58a6ff;border-bottom-color:#58a6ff}
.tab-panel{display:none}
.tab-panel.active{display:block}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div class="logo"><img src="assets/dragon-icon.jpg" alt=""></div>
    <div>
      <div style="font-size:.68rem;color:#8b949e;margin-bottom:2px;">TRETRAU NETWORK</div>
      <h1>🗄️ Backup Manager</h1>
    </div>
  </div>

  <div class="warning">
    <strong>⚠️ Security Notice</strong>
    Full backup bao gồm toàn bộ database + tất cả ảnh trong uploads. File ZIP có thể rất lớn. Xóa file backup sau khi download.
  </div>

  <div class="card">
    <div class="card-title">📊 Thống kê</div>
    <div class="stats-grid" id="stats-grid">
      <div class="stat-item"><div class="stat-value" id="s-users">...</div><div class="stat-label">Users</div></div>
      <div class="stat-item"><div class="stat-value" id="s-products">...</div><div class="stat-label">Sản phẩm</div></div>
      <div class="stat-item"><div class="stat-value" id="s-messages">...</div><div class="stat-label">Tin nhắn</div></div>
      <div class="stat-item"><div class="stat-value" id="s-channels">...</div><div class="stat-label">Kênh chat</div></div>
      <div class="stat-item"><div class="stat-value" id="s-files">...</div><div class="stat-label">Files upload</div></div>
      <div class="stat-item"><div class="stat-value" id="s-upsize">...</div><div class="stat-label">Dung lượng uploads</div></div>
    </div>
  </div>

  <div class="card">
    <div class="card-title">💾 Tạo Backup</div>
    <div class="tab-bar">
      <div class="tab active" onclick="switchTab(this,'full')">📦 Full Backup (DB + Uploads)</div>
      <div class="tab" onclick="switchTab(this,'sql')">🗄️ SQL Only</div>
    </div>

    <div class="tab-panel active" id="tab-full">
      <p style="font-size:.83rem;color:#8b949e;margin-bottom:14px;">
        Nén toàn bộ <strong style="color:#e6edf3;">database SQL</strong> + <strong style="color:#e6edf3;">folder uploads</strong> (ảnh sản phẩm, avatar...) thành 1 file ZIP.
      </p>
      <div class="actions">
        <button class="btn btn-green" onclick="downloadFull(this)">
          <svg width="15" height="15" viewBox="0 0 16 16" fill="currentColor"><path d="M8 12L3 7h3V1h4v6h3L8 12z"/><path d="M1 14h14v1.5H1z"/></svg>
          Tải xuống ZIP
        </button>
        <button class="btn btn-blue" onclick="saveFull(this)">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/></svg>
          Lưu trên server
        </button>
        <button class="btn btn-tg" onclick="sendTgFull(this)">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L8.32 13.617l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.828.942z"/></svg>
          Gửi ZIP qua Telegram
        </button>
      </div>
    </div>

    <div class="tab-panel" id="tab-sql">
      <p style="font-size:.83rem;color:#8b949e;margin-bottom:14px;">
        Chỉ backup <strong style="color:#e6edf3;">database SQL</strong> (không bao gồm ảnh). File nhỏ, nhanh.
      </p>
      <div class="actions">
        <button class="btn btn-green" onclick="downloadSQL()">
          <svg width="15" height="15" viewBox="0 0 16 16" fill="currentColor"><path d="M8 12L3 7h3V1h4v6h3L8 12z"/><path d="M1 14h14v1.5H1z"/></svg>
          Tải xuống .sql
        </button>
        <button class="btn btn-dark" onclick="saveSQL(this)">💾 Lưu SQL trên server</button>
        <button class="btn btn-tg" onclick="sendTgSQL(this)">📤 Gửi SQL qua Telegram</button>
      </div>
    </div>

    <div id="action-status" class="status"></div>
    <div class="progress-wrap" id="progress-wrap">
      <div class="progress-bar"><div class="progress-fill" id="progress-fill"></div></div>
      <div class="progress-text" id="progress-text">Đang tạo backup...</div>
    </div>
  </div>

  <div class="card">
    <div class="card-title">📁 Backup đã lưu trên server</div>
    <div id="backup-list-wrap"><div style="color:#8b949e;font-size:.83rem;">Đang tải...</div></div>
    <button class="btn btn-dark btn-sm" style="margin-top:12px;" onclick="loadList()">🔄 Làm mới</button>
  </div>

  <div class="card">
    <div class="card-title">📖 Hướng dẫn Restore</div>
    <div style="font-size:.83rem;line-height:1.8;color:#8b949e;">
      <p style="margin-bottom:6px;"><strong style="color:#e6edf3;">1.</strong> Tải file <code style="color:#58a6ff;">.zip</code> (Full Backup) về máy</p>
      <p style="margin-bottom:6px;"><strong style="color:#e6edf3;">2.</strong> Giải nén → được <code style="color:#58a6ff;">uploads/</code> + file <code style="color:#58a6ff;">.sql</code></p>
      <p style="margin-bottom:6px;"><strong style="color:#e6edf3;">3.</strong> Upload code tretrau lên server mới</p>
      <p style="margin-bottom:6px;"><strong style="color:#e6edf3;">4.</strong> Copy thư mục <code style="color:#58a6ff;">uploads/</code> vào web root</p>
      <p style="margin-bottom:6px;"><strong style="color:#e6edf3;">5.</strong> Import SQL:</p>
      <code style="display:block;background:#0d1117;padding:10px;border-radius:6px;border:1px solid #21262d;margin:6px 0 10px;font-size:.78rem;color:#58a6ff;">mysql -u USER -p DATABASE &lt; database_YYYY-MM-DD.sql</code>
      <p><strong style="color:#e6edf3;">6.</strong> Cập nhật <code style="color:#58a6ff;">.env.tretrau</code></p>
    </div>
  </div>
</div>

<script>
const B='backup.php';
function switchTab(el,t){document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));document.querySelectorAll('.tab-panel').forEach(x=>x.classList.remove('active'));el.classList.add('active');document.getElementById('tab-'+t).classList.add('active')}
function sts(m,t='success'){const e=document.getElementById('action-status');e.className='status '+t;e.textContent=m}
function prog(on,txt='',p=0){const w=document.getElementById('progress-wrap');w.style.display=on?'block':'none';if(txt)document.getElementById('progress-text').textContent=txt;document.getElementById('progress-fill').style.width=p+'%'}
function bl(b,on){if(on){b._h=b.innerHTML;b.disabled=true;b.innerHTML='<div class="spinner"></div> Đang xử lý...'}else{b.disabled=false;b.innerHTML=b._h||''}}

async function loadStats(){
  try{const r=await fetch(B+'?action=stats');const d=await r.json();
  document.getElementById('s-users').textContent=d.users??'?';
  document.getElementById('s-products').textContent=d.products??'?';
  document.getElementById('s-messages').textContent=d.messages??'?';
  document.getElementById('s-channels').textContent=d.chat_channels??'?';
  document.getElementById('s-files').textContent=d.upload_files??'?';
  document.getElementById('s-upsize').textContent=d.upload_size??'?'}catch(e){}}

function downloadFull(b){
  sts('Đang tạo ZIP... có thể mất vài phút nếu uploads lớn','info');
  prog(true,'Đang nén database + uploads...',30);
  window.location.href=B+'?action=download_full';
  setTimeout(()=>{prog(true,'Đang tải xuống...',80);setTimeout(()=>{prog(false);sts('✓ File ZIP đã được tải xuống!')},3000)},2000)}

async function saveFull(b){bl(b,true);prog(true,'Đang nén...',20);
  try{prog(true,'Đang ghi ZIP...',50);const r=await fetch(B+'?action=save_full');const d=await r.json();prog(true,'Xong!',100);
  if(d.success){sts('✓ Đã lưu: '+d.file+' ('+d.total_size+') — DB: '+d.sql_size+', Uploads: '+d.upload_files+' files ('+d.upload_size+')'+(d.skipped>0?', Skipped: '+d.skipped:''));loadList()}else throw new Error(d.error)}
  catch(e){sts('✗ '+e.message,'error')}prog(false);bl(b,false)}

async function sendTgFull(b){bl(b,true);prog(true,'Đang nén và gửi...',30);
  try{prog(true,'Upload lên Telegram...',60);const r=await fetch(B+'?action=send_telegram');const d=await r.json();prog(true,'Done!',100);
  if(d.success)sts('✓ '+d.message);else throw new Error(d.error)}
  catch(e){sts('✗ '+e.message,'error')}prog(false);bl(b,false)}

function downloadSQL(){window.location.href=B+'?action=download';sts('✓ Đang tải SQL...')}

async function saveSQL(b){bl(b,true);
  try{const r=await fetch(B+'?action=save');const d=await r.json();
  if(d.success){sts('✓ Đã lưu: '+d.file+' ('+Math.round(d.size/1024)+' KB)');loadList()}else throw new Error(d.error)}
  catch(e){sts('✗ '+e.message,'error')}bl(b,false)}

async function sendTgSQL(b){bl(b,true);
  try{const r=await fetch(B+'?action=send_telegram_sql');const d=await r.json();
  if(d.success)sts('✓ '+d.message);else throw new Error(d.error)}
  catch(e){sts('✗ '+e.message,'error')}bl(b,false)}

async function loadList(){const w=document.getElementById('backup-list-wrap');
  try{const r=await fetch(B+'?action=list');const d=await r.json();
  if(!d.backups||d.backups.length===0){w.innerHTML='<div style="color:#8b949e;font-size:.83rem;">Chưa có backup nào.</div>';return}
  w.innerHTML='<div class="backup-list">'+d.backups.map(b=>`
    <div class="backup-item">
      <div class="backup-icon">${b.type==='full'?'📦':'🗄️'}</div>
      <div class="backup-info">
        <div class="backup-name">${b.name}</div>
        <div class="backup-meta">
          <span class="backup-type ${b.type==='full'?'type-full':'type-sql'}">${b.type==='full'?'FULL ZIP':'SQL'}</span>
          ${b.size} · ${b.date}
        </div>
      </div>
      <button class="btn btn-red btn-sm" onclick="delBk('${b.name}')" title="Xóa">🗑️</button>
    </div>`).join('')+'</div>'}catch(e){w.innerHTML='<div style="color:#8b949e;">Lỗi tải danh sách.</div>'}}

async function delBk(f){if(!confirm('Xóa: '+f+'?'))return;
  try{const r=await fetch(B+'?action=delete&file='+encodeURIComponent(f));const d=await r.json();if(d.success)loadList();else alert(d.error)}catch(e){alert(e.message)}}

loadStats();loadList();
</script>
</body>
</html>
