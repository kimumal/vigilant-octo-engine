<style>.site-footer{display:none!important}</style>
<?php
// Community avatar - read from file to avoid encoding issues
$_dragonPath = __DIR__ . '/../assets/dragon-icon.jpg';
if (!file_exists($_dragonPath)) $_dragonPath = __DIR__ . '/assets/dragon-icon.jpg';
if (file_exists($_dragonPath)) {
    define('COMMUNITY_AVATAR', 'data:image/jpeg;base64,' . base64_encode(file_get_contents($_dragonPath)));
} else {
    define('COMMUNITY_AVATAR', 'assets/dragon-icon.jpg');
}
$db=getDB(); $activeChannel=(int)($_GET['channel']??0); $dmUserId=(int)($_GET['dm']??0); $dmName=sanitizeInput($_GET['name']??'');
$isGlobalActive = isset($_GET['view']) && $_GET['view']==='global';
$stmt=$db->prepare("SELECT cc.*,p.title as product_title,buyer.username as buyer_name,buyer.avatar as buyer_avatar,buyer.role as buyer_role,seller.username as seller_name,seller.avatar as seller_avatar,seller.role as seller_role FROM chat_channels cc JOIN products p ON p.id=cc.product_id JOIN users buyer ON buyer.id=cc.buyer_id JOIN users seller ON seller.id=cc.seller_id WHERE (cc.buyer_id=? OR cc.seller_id=?) AND cc.status='active' ORDER BY cc.created_at DESC");
$stmt->execute([$user['id'],$user['id']]); $channels=$stmt->fetchAll();
$stmt2=$db->prepare("SELECT DISTINCT CASE WHEN m.sender_id=? THEN m.receiver_id ELSE m.sender_id END as peer_id,u.username as peer_name,u.avatar as peer_avatar,u.role as peer_role,MAX(m.created_at) as last_time FROM messages m JOIN users u ON u.id=CASE WHEN m.sender_id=? THEN m.receiver_id ELSE m.sender_id END WHERE m.is_dm=1 AND (m.sender_id=? OR m.receiver_id=?) AND u.id IS NOT NULL GROUP BY peer_id,peer_name,peer_avatar,peer_role ORDER BY last_time DESC");
$stmt2->execute([$user['id'],$user['id'],$user['id'],$user['id']]); $dmList=$stmt2->fetchAll();
$isDm=$dmUserId>0; $isChannel=!$isDm&&!$isGlobalActive&&$activeChannel>0; $currentChannel=null;
if($isChannel){foreach($channels as $ch){if((int)$ch['id']===$activeChannel){$currentChannel=$ch;break;}}if(!$currentChannel)$isChannel=false;}
if(!$isChannel&&!$isDm&&!$isGlobalActive&&count($channels)>0){$activeChannel=(int)$channels[0]['id'];$currentChannel=$channels[0];$isChannel=true;}

$onlineStmt = $db->query("SELECT u.id, u.username, u.avatar, u.role FROM users u JOIN traffic_logs t ON t.user_id=u.id WHERE t.created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE) GROUP BY u.id ORDER BY MAX(t.created_at) DESC LIMIT 20");
$onlineUsers = $onlineStmt->fetchAll();

// Build initial conv header HTML for PHP-side rendering
function convHeaderHtml($avatarSrc, $name, $roleBadge, $subHtml, $profileId, $isDm) {
  $e2e = !$isDm ? '<div class="chat-secure-badge"><span class="icon-lock"></span> E2E</div>' : '';
  return '<button class="chat-mob-back-btn" onclick="openMobileList()"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M11 4L6 9l5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
    <img src="'.htmlspecialchars($avatarSrc).'" class="chat-hdr-avatar" onclick="showUserProfile('.(int)$profileId.')" alt="">
    <div class="chat-panel-info"><div class="chat-panel-name" id="conv-hdr-name">'.htmlspecialchars($name).$roleBadge.'</div><div class="chat-panel-sub" id="conv-hdr-sub">'.$subHtml.'</div></div>
    <div class="chat-header-actions"><button class="chat-header-btn" onclick="showUserProfile('.(int)$profileId.')"><span class="icon-user"></span></button>'.$e2e.'</div>';
}

function roleBadge($role) {
  if ($role==='admin') return '<span class="chat-hdr-tick"><svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="8" fill="#e8192c"/><path d="M4.5 8.3l2.3 2.3 4.5-4.6" stroke="#fff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></span>';
  if ($role==='premium') return '<span class="chat-hdr-tick"><svg viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="8" fill="#1877f2"/><path d="M4.5 8.3l2.3 2.3 4.5-4.6" stroke="#fff" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></span>';
  return '';
}

// Compute initial conv header
$convHeaderContent = '';
$convInitChannelId = 0; $convInitPeerId = 0; $convInitIsGlobal = false; $convInitIsDm = false;
if ($isChannel && $currentChannel) {
  $ib=(int)$currentChannel['buyer_id']===(int)$user['id'];
  $pn=$ib?$currentChannel['seller_name']:$currentChannel['buyer_name'];
  $pa=$ib?$currentChannel['seller_avatar']:$currentChannel['buyer_avatar'];
  $pr=$ib?$currentChannel['seller_role']:$currentChannel['buyer_role'];
  $pi=$ib?$currentChannel['seller_id']:$currentChannel['buyer_id'];
  $convHeaderContent = convHeaderHtml(getAvatarUrl($pa), $pn, roleBadge($pr), '<span class="icon-box" style="font-size:.7rem;"></span> '.htmlspecialchars(mb_substr($currentChannel['product_title'],0,42)), $pi, false);
  $convInitChannelId = $activeChannel;
} elseif ($isDm && $dmUserId) {
  $ps=$db->prepare("SELECT id,username,avatar,role FROM users WHERE id=?"); $ps->execute([$dmUserId]); $peer=$ps->fetch();
  if ($peer) {
    $convHeaderContent = convHeaderHtml(getAvatarUrl($peer['avatar']), $peer['username'], roleBadge($peer['role']??''), '<span class="online-status">Online</span>', $peer['id'], true);
  } else {
    $convHeaderContent = '<div class="chat-panel-info"><div class="chat-panel-name" id="conv-hdr-name">'.htmlspecialchars($dmName).'</div><div class="chat-panel-sub" id="conv-hdr-sub"><span data-lang="chat_dm_preview">Direct message</span></div></div>';
  }
  $convInitPeerId = $dmUserId; $convInitIsDm = true;
}
?>
<div class="chat-layout">
  <!-- ══ LEFT: List panel ══ -->
  <div class="chat-list-panel" id="chat-list-panel">
    <div class="chat-list-mobile-hdr"><button class="chat-list-back-btn" onclick="window.location.href='index.php'"><svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M13 4L7 10l6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button><span class="icon-chat"></span><span data-lang="chat_messages">Messages</span></div>
    <div class="chat-list-header"><button class="chat-list-back-arrow" onclick="window.location.href='index.php'">←</button><span class="icon-chat"></span> <span data-lang="chat_messages">Messages</span><button class="chat-new-msg-btn" id="new-dm-btn"><span class="icon-plus"></span> <span data-lang="chat_new">New</span></button></div>
    <div class="chat-list-search"><div class="chat-list-search-inner"><span class="icon-search"></span><input type="text" data-lang-placeholder="chat_search_ph" placeholder="Search conversations..." oninput="filterChatList(this.value)"></div></div>
    <div class="chat-list-tabs"><button class="chat-tab active" onclick="switchChatTab('all',this)" data-lang="chat_tab_all">All</button><button class="chat-tab" onclick="switchChatTab('trade',this)" data-lang="chat_tab_trade">Trade</button><button class="chat-tab" onclick="switchChatTab('dm',this)" data-lang="chat_tab_dm">Messages</button></div>
    <div class="chat-list-scroll">
      <div class="chat-section-label" data-lang="chat_community">Community</div>
      <div class="chat-list-item chat-item-community <?=$isGlobalActive?'active':''?>" id="community-item" onclick="openGlobalChat(this)" style="cursor:pointer;">
        <div class="chat-list-avatar" style="position:relative;"><img src="<?=COMMUNITY_AVATAR?>" alt="" style="width:48px;height:48px;border-radius:50%;object-fit:cover;"><div class="online-dot"></div></div>
        <div class="chat-list-info"><div class="chat-list-name">TreTrau Network <span style="display:inline-flex;align-items:center;gap:3px;background:linear-gradient(135deg,#ff3d00,#ff6d00);color:#fff;font-size:.52rem;font-weight:900;letter-spacing:.1em;padding:1px 5px;border-radius:99px;"><span style="width:4px;height:4px;background:#fff;border-radius:50%;animation:live-blink 1s infinite;display:inline-block;"></span>LIVE</span></div><div class="chat-list-preview"><span data-lang="chat_community_chat">Community chat</span></div></div>
        <div class="chat-list-meta"><span class="chat-list-time" style="color:var(--accent);font-weight:700;"><span class="icon-pin" style="font-size:.75rem;"></span></span></div>
      </div>

      <?php if($channels):?>
      <div class="chat-section-label" data-lang="chat_trade_channels">Trade Channels</div>
      <?php foreach($channels as $ch):$ib=(int)$ch['buyer_id']===(int)$user['id'];$pn=$ib?$ch['seller_name']:$ch['buyer_name'];$pa=$ib?$ch['seller_avatar']:$ch['buyer_avatar'];$pr=$ib?$ch['seller_role']:$ch['buyer_role'];$ia=$isChannel&&(int)$ch['id']===$activeChannel;?>
      <div class="chat-list-item chat-item-trade <?=$ia?'active':''?>" data-name="<?=htmlspecialchars($pn)?>" data-channel="<?=$ch['id']?>" onclick="openChannel(<?=$ch['id']?>,this)" style="cursor:pointer;">
        <div class="chat-list-avatar"><img src="<?=htmlspecialchars(getAvatarUrl($pa))?>" alt=""></div>
        <div class="chat-list-info"><div class="chat-list-name"><?=htmlspecialchars($pn)?><?=roleBadge($pr)?></div><div class="chat-list-preview"><span class="icon-box" style="font-size:.7rem;"></span> <?=htmlspecialchars(mb_substr($ch['product_title'],0,30))?></div></div>
        <div class="chat-list-meta"><span class="chat-list-time"><?=timeAgo($ch['created_at'])?></span></div>
      </div>
      <?php endforeach; endif;?>

      <?php if($dmList):?>
      <div class="chat-section-label" data-lang="chat_dm_section">Direct Messages</div>
      <?php foreach($dmList as $dm):$ia=$isDm&&(int)$dm['peer_id']===$dmUserId;?>
      <div class="chat-list-item chat-item-dm <?=$ia?'active':''?>" data-name="<?=htmlspecialchars($dm['peer_name'])?>" data-peer="<?=$dm['peer_id']?>" onclick="openDm(<?=$dm['peer_id']?>,this)" style="cursor:pointer;">
        <div class="chat-list-avatar"><img src="<?=htmlspecialchars(getAvatarUrl($dm['peer_avatar']))?>" alt=""></div>
        <div class="chat-list-info"><div class="chat-list-name"><?=htmlspecialchars($dm['peer_name'])?><?=roleBadge($dm['peer_role']??'')?></div><div class="chat-list-preview"><span data-lang="chat_dm_preview">Direct message</span></div></div>
        <div class="chat-list-meta"><span class="chat-list-time"><?=timeAgo($dm['last_time'])?></span></div>
      </div>
      <?php endforeach; endif;?>

      <?php if(!$channels&&!$dmList):?>
      <div class="empty-state" style="padding:var(--sp-xl);"><div class="empty-icon"><span class="icon-chat"></span></div><div class="empty-title" data-lang="chat_no_conversations">No conversations yet</div></div>
      <?php endif;?>
    </div>
  </div>

  <!-- ══ RIGHT: Main panel ══ -->
  <div class="chat-main-panel" id="chat-main-panel">

    <!-- GLOBAL PANEL -->
    <div id="panel-global" class="chat-subpanel" style="display:<?=$isGlobalActive?'flex':'none'?>;">
      <div class="chat-panel-header">
        <button class="chat-mob-back-btn" onclick="openMobileList()"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M11 4L6 9l5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
        <div style="position:relative;flex-shrink:0;width:40px;height:40px;margin-right:10px;">
          <img src="<?=COMMUNITY_AVATAR?>" style="width:40px;height:40px;border-radius:50%;object-fit:cover;" alt="">
          <div style="position:absolute;bottom:1px;right:1px;width:10px;height:10px;background:#4caf50;border-radius:50%;border:2px solid var(--surface);"></div>
        </div>
        <div class="chat-panel-info">
          <div class="chat-panel-name">TreTrau Network <span style="display:inline-flex;align-items:center;gap:3px;background:linear-gradient(135deg,#ff3d00,#ff6d00);color:#fff;font-size:.5rem;font-weight:900;letter-spacing:.1em;padding:1px 5px;border-radius:99px;margin-left:3px;"><span style="width:4px;height:4px;background:#fff;border-radius:50%;animation:live-blink 1s infinite;display:inline-block;"></span>LIVE</span></div>
          <div class="chat-panel-sub" onclick="showGroupInfoFromMenu()" style="cursor:pointer;"><?=count($onlineUsers)?> <span data-lang="chat_members_online">members online</span></div>
        </div>
        <div class="chat-header-actions" style="position:relative;">
          <button class="chat-header-btn" onclick="toggle3DotMenu(this)" title="Menu"><svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="3" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="8" cy="13" r="1.5"/></svg></button>
        </div>
      </div>
      <div class="chat-messages-wrap" id="chat-messages-global">
        <div class="typing-indicator-wrap" id="typing-indicator-global"><div class="typing-dots"><span></span><span></span><span></span></div></div>
      </div>
      <button class="chat-scroll-bottom" id="scroll-bottom-global" onclick="window.chatAppGlobal?.scrollBottom()"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
      <div class="chat-input-area">
        <div id="chat-reply-bar-g" class="chat-reply-bar"><span class="icon-reply" style="color:var(--accent);flex-shrink:0;"></span><span id="chat-reply-text-g"></span><button id="chat-reply-cancel-g" class="chat-reply-cancel"><span class="icon-x"></span></button></div>
        <div id="chat-preview-g" style="display:none;margin-bottom:8px;"><div style="position:relative;display:inline-block;"><img id="chat-preview-img-g" src="" style="max-height:100px;border-radius:12px;border:1px solid var(--border);" alt=""><button onclick="window.chatAppGlobal?.clearPreview()" style="position:absolute;top:-6px;right:-6px;width:22px;height:22px;background:var(--danger);border:2px solid var(--surface);border-radius:50%;color:#fff;cursor:pointer;font-size:.6rem;display:flex;align-items:center;justify-content:center;"><span class="icon-x"></span></button></div></div>
        <div class="chat-input-row">
          <label class="chat-img-btn"><span class="icon-image"></span><input type="file" id="chat-file-g" accept="image/*" style="display:none;"></label>
          <div class="chat-input-wrap"><textarea class="chat-textarea" id="chat-input-g" data-lang-placeholder="chat_input_global_ph" placeholder="Message everyone..." rows="1"></textarea></div>
          <button class="chat-send-btn" id="chat-send-g"><span class="icon-send"></span></button>
        </div>
      </div>
    </div>

    <!-- CONV PANEL (channel / DM) -->
    <div id="panel-conv" class="chat-subpanel" style="display:<?=($isChannel||$isDm)&&!$isGlobalActive?'flex':'none'?>;">
      <div class="chat-panel-header" id="conv-header"><?=$convHeaderContent?></div>
      <div class="chat-messages-wrap" id="chat-messages-conv">
        <div class="typing-indicator-wrap" id="typing-indicator-conv"><div class="typing-dots"><span></span><span></span><span></span></div></div>
      </div>
      <button class="chat-scroll-bottom" id="scroll-bottom-conv" onclick="window.chatAppConv?.scrollBottom()"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M4 6l4 4 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>
      <div class="chat-input-area">
        <div id="chat-reply-bar" class="chat-reply-bar"><span class="icon-reply" style="color:var(--accent);flex-shrink:0;"></span><span id="chat-reply-text"></span><button id="chat-reply-cancel" class="chat-reply-cancel"><span class="icon-x"></span></button></div>
        <div id="chat-preview" style="display:none;margin-bottom:8px;"><div style="position:relative;display:inline-block;"><img id="chat-preview-img" src="" style="max-height:100px;border-radius:12px;border:1px solid var(--border);" alt=""><button onclick="window.chatAppConv?.clearPreview()" style="position:absolute;top:-6px;right:-6px;width:22px;height:22px;background:var(--danger);border:2px solid var(--surface);border-radius:50%;color:#fff;cursor:pointer;font-size:.6rem;display:flex;align-items:center;justify-content:center;"><span class="icon-x"></span></button></div></div>
        <div class="chat-input-row">
          <label class="chat-img-btn"><span class="icon-image"></span><input type="file" id="chat-file" accept="image/*" style="display:none;"></label>
          <div class="chat-input-wrap"><textarea class="chat-textarea" id="chat-input" data-lang-placeholder="chat_input_ph" placeholder="Type a message..." rows="1"></textarea></div>
          <button class="chat-send-btn" id="chat-send"><span class="icon-send"></span></button>
        </div>
      </div>
    </div>

    <!-- EMPTY STATE -->
    <div id="panel-empty" style="display:<?=(!$isChannel&&!$isDm&&!$isGlobalActive)?'flex':'none'?>;flex:1;height:100%;justify-content:center;align-items:center;">
      <div class="empty-state"><div class="empty-icon"><span class="icon-chat" style="font-size:2.5rem;"></span></div><div class="empty-title" data-lang="chat_select_conversation">Select a conversation</div><div class="empty-desc" data-lang="chat_select_desc">Choose a chat channel from the list on the left.</div></div>
    </div>

  </div>
</div>

<style>
.chat-subpanel{flex-direction:column;height:100%;overflow:hidden;flex:1;}
</style>

<script>
window._globalOnlineUsers = <?=json_encode(array_map(function($ou){ return ['id'=>(int)$ou['id'],'username'=>$ou['username'],'avatar'=>getAvatarUrl($ou['avatar']),'role'=>$ou['role']]; }, $onlineUsers))?>;
window._communityAvatar = '<?=COMMUNITY_AVATAR?>';
const CURRENT_USER_ID = <?=(int)$user['id']?>;
let _activeView = '<?=$isGlobalActive?'global':($isDm?'dm':($isChannel?'channel':'empty'))?>';

// Conv panel element IDs — used by all ChatApp instances for channel/DM
const CONV_EL_IDS = {
  messages:'chat-messages-conv', textarea:'chat-input', sendBtn:'chat-send',
  fileInput:'chat-file', previewWrap:'chat-preview', previewImg:'chat-preview-img',
  replyBar:'chat-reply-bar', replyText:'chat-reply-text', replyCancelBtn:'chat-reply-cancel',
  typingIndicator:'typing-indicator-conv'
};

document.addEventListener('DOMContentLoaded', function() {
  // Init global ChatApp once — uses custom element IDs
  window.chatAppGlobal = new ChatApp({
    channelId: null, isGlobal: true, isDm: false, peerId: null,
    currentUserId: CURRENT_USER_ID,
    elIds: {
      messages:'chat-messages-global', textarea:'chat-input-g', sendBtn:'chat-send-g',
      fileInput:'chat-file-g', previewWrap:'chat-preview-g', previewImg:'chat-preview-img-g',
      replyBar:'chat-reply-bar-g', replyText:'chat-reply-text-g', replyCancelBtn:'chat-reply-cancel-g',
      typingIndicator:'typing-indicator-global'
    }
  });

  // Init conv ChatApp if a channel/DM is active on load
  <?php if($isChannel&&$currentChannel):?>
  window.chatAppConv = new ChatApp({channelId:<?=$activeChannel?>,isGlobal:false,isDm:false,peerId:null,currentUserId:CURRENT_USER_ID,elIds:CONV_EL_IDS});
  <?php elseif($isDm&&$dmUserId):?>
  window.chatAppConv = new ChatApp({channelId:null,isGlobal:false,isDm:true,peerId:<?=$dmUserId?>,currentUserId:CURRENT_USER_ID,elIds:CONV_EL_IDS});
  <?php endif;?>

  // Scroll bottom buttons
  setupScrollBtn('chat-messages-global','scroll-bottom-global');
  setupScrollBtn('chat-messages-conv','scroll-bottom-conv');

  if (window.innerWidth <= 768 && _activeView === 'empty') openMobileList();
});

function setupScrollBtn(msgsId, btnId) {
  const msgs = document.getElementById(msgsId);
  const sb = document.getElementById(btnId);
  if (msgs && sb) msgs.addEventListener('scroll', () => sb.classList.toggle('show', msgs.scrollHeight - msgs.scrollTop - msgs.clientHeight > 120));
}

// ─── Panel switcher ───
function showPanel(name) {
  document.getElementById('panel-global').style.display = 'none';
  document.getElementById('panel-conv').style.display = 'none';
  document.getElementById('panel-empty').style.display = 'none';
  document.querySelectorAll('.chat-list-item').forEach(el => el.classList.remove('active'));
  const map = {global:'flex',conv:'flex',empty:'flex'};
  document.getElementById('panel-' + name).style.display = map[name] || 'none';
}

function openGlobalChat(listEl) {
  _activeView = 'global';
  showPanel('global');
  document.getElementById('community-item')?.classList.add('active');
  history.pushState({view:'global'}, '', '/chat&view=global');
  if (window.chatAppConv) window.chatAppConv.stopPolling();
  if (window.innerWidth <= 768) closeMobileList();
}

function openChannel(channelId, listEl) {
  if (window.chatAppConv) window.chatAppConv.stopPolling();
  _activeView = 'channel';
  history.pushState({channelId}, '', '/chat&channel=' + channelId);
  rebuildConvHeader(listEl, false, channelId);
  clearConvMessages();
  window.chatAppConv = new ChatApp({channelId, isGlobal:false, isDm:false, peerId:null, currentUserId:CURRENT_USER_ID, elIds:CONV_EL_IDS});
  showPanel('conv');
  listEl?.classList.add('active');
  if (window.innerWidth <= 768) closeMobileList();
}

function openDm(peerId, listEl) {
  if (window.chatAppConv) window.chatAppConv.stopPolling();
  _activeView = 'dm';
  const name = listEl?.dataset.name || '';
  history.pushState({peerId}, '', '/chat/' + peerId);
  rebuildConvHeader(listEl, true, peerId);
  clearConvMessages();
  window.chatAppConv = new ChatApp({channelId:null, isGlobal:false, isDm:true, peerId, currentUserId:CURRENT_USER_ID, elIds:CONV_EL_IDS});
  showPanel('conv');
  listEl?.classList.add('active');
  if (window.innerWidth <= 768) closeMobileList();
}

function clearConvMessages() {
  const msgs = document.getElementById('chat-messages-conv');
  if (msgs) msgs.innerHTML = '<div class="typing-indicator-wrap" id="typing-indicator-conv"><div class="typing-dots"><span></span><span></span><span></span></div></div>';
}

function rebuildConvHeader(listEl, isDm, id) {
  const header = document.getElementById('conv-header');
  if (!header) return;
  const name = listEl?.dataset?.name || '';
  const avatarEl = listEl?.querySelector('.chat-list-avatar img');
  const avatar = avatarEl ? avatarEl.src : 'assets/default-avatar.png';
  const subHtml = isDm
    ? '<span class="online-status">Online</span>'
    : '<span class="icon-box" style="font-size:.7rem;"></span> ' + Lang.t('chat_trade_channel');
  const e2e = !isDm ? '<div class="chat-secure-badge"><span class="icon-lock"></span> E2E</div>' : '';
  header.innerHTML = `
    <button class="chat-mob-back-btn" onclick="openMobileList()"><svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M11 4L6 9l5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></button>
    <img src="${avatar}" class="chat-hdr-avatar" onclick="if(typeof showUserProfile==='function')showUserProfile(${id})" alt="" style="cursor:pointer;">
    <div class="chat-panel-info">
      <div class="chat-panel-name" id="conv-hdr-name">${escHtml(name)}</div>
      <div class="chat-panel-sub" id="conv-hdr-sub">${subHtml}</div>
    </div>
    <div class="chat-header-actions">
      <button class="chat-header-btn" onclick="if(typeof showUserProfile==='function')showUserProfile(${id})"><span class="icon-user"></span></button>${e2e}
    </div>`;
}

// ─── List helpers ───
function openMobileList(){document.getElementById('chat-list-panel')?.classList.add('mobile-open');}
function closeMobileList(){document.getElementById('chat-list-panel')?.classList.remove('mobile-open');}
function filterChatList(q){q=q.toLowerCase().trim();document.querySelectorAll('.chat-list-item[data-name]').forEach(el=>{el.style.display=!q||(el.dataset.name||'').toLowerCase().includes(q)?'':'none';});}
function switchChatTab(tab,btn){document.querySelectorAll('.chat-tab').forEach(t=>t.classList.remove('active'));btn.classList.add('active');document.querySelectorAll('.chat-list-item').forEach(el=>{if(tab==='all')el.style.display='';else if(tab==='trade')el.style.display=el.classList.contains('chat-item-trade')||el.classList.contains('chat-item-community')?'':'none';else el.style.display=el.classList.contains('chat-item-dm')||el.classList.contains('chat-item-community')?'':'none';});document.querySelectorAll('.chat-section-label').forEach(l=>{l.style.display=tab==='all'?'':'none';});}

window.addEventListener('popstate', function() {
  const p = new URLSearchParams(window.location.search);
  if (p.get('view')==='global') openGlobalChat(document.getElementById('community-item'));
  else if (p.get('channel')) openChannel(parseInt(p.get('channel')), document.querySelector(`.chat-list-item[data-channel="${p.get('channel')}"]`));
  else if (p.get('dm')) openDm(parseInt(p.get('dm')), document.querySelector(`.chat-list-item[data-peer="${p.get('dm')}"]`));
});

// Allow external code to start a DM
window.openDirectMessage = function(peerId, peerName) {
  let el = document.querySelector(`.chat-list-item[data-peer="${peerId}"]`);
  if (!el) {
    // Create temporary list entry
    el = document.createElement('div');
    el.className = 'chat-list-item chat-item-dm';
    el.dataset.name = peerName; el.dataset.peer = peerId;
    el.innerHTML = `<div class="chat-list-avatar"><img src="assets/default-avatar.png" alt=""></div><div class="chat-list-info"><div class="chat-list-name">${escHtml(peerName)}</div><div class="chat-list-preview">${Lang.t('chat_dm_preview')}</div></div>`;
    document.querySelector('.chat-list-scroll')?.appendChild(el);
  }
  openDm(peerId, el);
};
</script>
