<?php
// PRODUCT_PAGE_VERSION=2.0_FIXED_20250225 — NO STATUS FILTER
$pid = (int)($_GET['id'] ?? 0);
$db = getDB();

// DEBUG LOG — tìm lỗi "Product not found"
$_debugLog = function($msg) use ($pid) {
    @error_log("PRODUCT_DEBUG pid={$pid}: {$msg}");
};

if ($pid <= 0) {
    $_debugLog("FAIL: pid is 0 or negative, _GET[id]=" . var_export($_GET['id'] ?? null, true));
}

// Bước 1: Lấy sản phẩm — KHÔNG filter status, cho phép owner/admin xem mọi status
// LEFT JOIN để không mất product nếu user bị xóa
$stmt = $db->prepare("SELECT p.*, u.username, u.avatar, u.bio, u.role, u.id as seller_id FROM products p LEFT JOIN users u ON u.id=p.user_id WHERE p.id=?");
$stmt->execute([$pid]);
$product = $stmt->fetch();

if (!$product) {
    $_debugLog("FAIL: Query returned NULL for pid={$pid}");
    // Thử query không JOIN để check orphan
    $chk = $db->prepare("SELECT id, user_id, status, title FROM products WHERE id=?");
    $chk->execute([$pid]);
    $raw = $chk->fetch();
    if ($raw) {
        $_debugLog("Product EXISTS but query issue. user_id={$raw['user_id']}, status={$raw['status']}, title={$raw['title']}");
    } else {
        $_debugLog("Product id={$pid} does NOT exist in products table.");
    }
}

// Handle orphan product (user deleted) — set defaults
if ($product && !$product['seller_id']) {
    $product['username'] = $product['username'] ?? 'Deleted User';
    $product['avatar'] = $product['avatar'] ?? null;
    $product['bio'] = $product['bio'] ?? '';
    $product['role'] = $product['role'] ?? 'user';
    $product['seller_id'] = $product['user_id'] ?? 0;
}

// Bước 2: Kiểm tra quyền xem
$canView = false;
if ($product) {
    // Dùng user_id trực tiếp từ products table (ổn định hơn seller_id từ LEFT JOIN alias)
    $productOwnerId = (int)($product['user_id'] ?? $product['seller_id'] ?? 0);
    $isOwner = $user && (int)$user['id'] === $productOwnerId;
    $isAdmin = $user && $user['role'] === 'admin';

    if ($product['status'] === 'active') {
        $canView = true; // Ai cũng xem được
    } elseif ($product['status'] === 'pending' && ($isOwner || $isAdmin)) {
        $canView = true; // Owner + admin xem được pending
    } elseif (in_array($product['status'], ['rejected', 'banned']) && ($isOwner || $isAdmin)) {
        $canView = true; // Owner + admin xem được rejected/banned
    } elseif ($product['status'] === 'deleted') {
        $canView = $isAdmin; // Chỉ admin xem được deleted
    } else {
        // Fallback: status không xác định → cho owner/admin xem
        $canView = $isOwner || $isAdmin;
        $_debugLog("WARN: Unknown status='{$product['status']}', falling back to owner/admin check");
    }

    if (!$canView) {
        $_debugLog("FAIL: canView=false. status={$product['status']}, productOwnerId={$productOwnerId}, isOwner=" . ($isOwner?'Y':'N') . ", isAdmin=" . ($isAdmin?'Y':'N') . ", userId=" . ($user['id']??'null'));
    }
}

if (!$product || !$canView) { ?>
<div class="empty-state">
  <div class="empty-icon"><span class="icon-box"></span></div>
  <div class="empty-title" data-lang="product_not_found">Product not found</div>
  <div class="empty-desc" data-lang="product_not_found_desc">This product has been deleted or does not exist.</div>
  <a href="/dashboard" class="btn btn-primary" data-lang="post_go_home">Go Home</a>
</div>
<?php return; }

// Chỉ tăng views cho sản phẩm active
if ($product['status'] === 'active') {
    $db->prepare("UPDATE products SET views=views+1 WHERE id=?")->execute([$pid]);
}
$isOwner = $user && (int)$user['id'] === $productOwnerId;
$isAdmin = $user && $user['role'] === 'admin';
?>

<style>
.product-status-banner { border-radius: var(--r-lg); padding: 12px 16px; margin-bottom: var(--sp-md); display: flex; align-items: center; gap: 10px; font-size: .88rem; font-weight: 600; }
.product-status-banner .status-icon { font-size: 1.2rem; }
.product-status-banner .status-text { flex: 1; }
.product-status-banner .status-sub { font-weight: 400; font-size: .78rem; opacity: .8; margin-top: 2px; }
.status-pending { background: rgba(245,158,11,.1); border: 1px solid rgba(245,158,11,.25); color: #f59e0b; }
.status-rejected { background: rgba(248,113,113,.1); border: 1px solid rgba(248,113,113,.25); color: #f87171; }
.status-banned { background: rgba(239,68,68,.1); border: 1px solid rgba(239,68,68,.25); color: #ef4444; }
.status-deleted { background: rgba(107,114,128,.1); border: 1px solid rgba(107,114,128,.25); color: #9ca3af; }
.product-detail-grid { display: grid; grid-template-columns: 1fr 380px; gap: var(--sp-xl); align-items: start; max-width: 1000px; margin: 0 auto; }
.product-img-wrap { background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-xl); overflow: hidden; aspect-ratio: 4/3; }
.product-img-wrap img { width:100%; height:100%; object-fit:cover; cursor:pointer; transition: transform var(--trans-slow); }
.product-img-wrap img:hover { transform: scale(1.02); }
.product-detail-info { display:flex; flex-direction:column; gap: var(--sp-md); }
.product-detail-title { font-size:1.4rem; font-weight:800; line-height:1.2; }
.product-detail-price { font-size:1.8rem; font-weight:800; }
.product-detail-desc { color: var(--text-secondary); font-size:0.9rem; line-height:1.7; background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--r-md); padding: var(--sp-md); }
.product-meta-row { display:flex; gap: var(--sp-md); flex-wrap:wrap; }
.product-meta-item { display:flex; align-items:center; gap:6px; font-size:0.8rem; color: var(--text-muted); }
.seller-card { background: var(--surface-2); border: 1px solid var(--border); border-radius: var(--r-lg); padding: var(--sp-md); display:flex; align-items:center; gap: var(--sp-md); cursor:pointer; transition: border-color var(--trans-fast); text-decoration:none; color:inherit; }
.seller-card:hover { border-color: var(--border-strong); }
.seller-avatar { width: 44px; height:44px; border-radius: 50%; object-fit: cover; }
.seller-name { font-weight:600; font-size:0.9rem; }
.seller-sub  { font-size:0.78rem; color: var(--text-muted); }
.buy-section { display:flex; flex-direction:column; gap: var(--sp-sm); }
@media (max-width: 768px) { .product-detail-grid { grid-template-columns: 1fr; } .product-detail-price { font-size: 1.4rem; } }
</style>

<div style="margin-bottom: var(--sp-md);">
  <a href="javascript:history.back()" class="btn btn-ghost btn-sm">
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align:middle"><polyline points="15 18 9 12 15 6"></polyline></svg>
    <span data-lang="product_go_back">Go Back</span>
  </a>
</div>

<?php if ($product['status'] !== 'active'): ?>
<?php
  $statusBanners = [
    'pending'  => ['class'=>'status-pending',  'icon'=>'⏳', 'title'=>'Đang chờ duyệt',                'titleLang'=>'product_status_pending',  'desc'=>'Bài đăng đang chờ admin xét duyệt qua Telegram. Chỉ bạn mới nhìn thấy bài này.', 'descLang'=>'product_status_pending_desc'],
    'rejected' => ['class'=>'status-rejected', 'icon'=>'❌', 'title'=>'Bị từ chối',                     'titleLang'=>'product_status_rejected', 'desc'=>$product['rejection_reason'] ?? 'Bài đăng không được duyệt bởi admin.',             'descLang'=>'product_status_rejected_desc'],
    'banned'   => ['class'=>'status-banned',   'icon'=>'🚫', 'title'=>'Bị cấm',                         'titleLang'=>'product_status_banned',   'desc'=>'Bài đăng vi phạm quy định.',                                                       'descLang'=>'product_status_banned_desc'],
    'deleted'  => ['class'=>'status-deleted',  'icon'=>'🗑️', 'title'=>'Đã xóa',                        'titleLang'=>'product_status_deleted',  'desc'=>'Bài đăng đã bị xóa.',                                                             'descLang'=>'product_status_deleted_desc'],
  ];
  $sb = $statusBanners[$product['status']] ?? null;
  if ($sb):
?>
<div class="product-status-banner <?= $sb['class'] ?>">
  <div class="status-icon"><?= $sb['icon'] ?></div>
  <div class="status-text">
    <div data-lang="<?= $sb['titleLang'] ?>"><?= $sb['title'] ?></div>
    <div class="status-sub" data-lang="<?= $sb['descLang'] ?>"><?= htmlspecialchars($sb['desc']) ?></div>
  </div>
</div>
<?php endif; ?>
<?php endif; ?>

<div class="product-detail-grid">
  <div>
    <div class="product-img-wrap">
      <img src="<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['title']) ?>" data-lightbox="<?= htmlspecialchars($product['image']) ?>">
    </div>
  </div>
  <div class="product-detail-info">
    <div>
      <span class="badge badge-user" style="margin-bottom:8px;" data-lang="cat_<?= $product['category'] ?>"><?= $product['category'] ?></span>
      <h1 class="product-detail-title"><?= htmlspecialchars($product['title']) ?></h1>
    </div>
    <div class="product-detail-price"><?= formatPrice($product['price'], $product['currency']) ?></div>
    <div class="product-meta-row">
      <div class="product-meta-item">
        <span class="icon-eye"></span> <?= number_format($product['views']) ?> <span data-lang="product_views">views</span>
      </div>
      <div class="product-meta-item">
        <span class="icon-clock"></span> <?= timeAgo($product['created_at']) ?>
      </div>
      <div class="product-meta-item">
        <span class="icon-tag"></span> #<?= $product['id'] ?>
      </div>
    </div>
    <div class="buy-section">
      <?php if ($product['status'] !== 'active' && $isOwner && !$isAdmin): ?>
      <div style="display:flex; gap:8px;">
        <?php if ($product['status'] === 'pending'): ?>
        <div class="btn btn-ghost" style="flex:1; justify-content:center; opacity:.6; cursor:default;">
          <span>⏳</span> <span data-lang="product_awaiting_approval">Awaiting approval</span>
        </div>
        <?php else: ?>
        <button class="btn btn-ghost" style="flex:1; justify-content:center;" onclick="confirmDelete()">
          <span class="icon-trash"></span> <span data-lang="product_delete">Delete Post</span>
        </button>
        <?php endif; ?>
      </div>
      <?php elseif (!$user): ?>
      <a href="/login" class="btn btn-primary" style="width:100%; justify-content:center; padding:14px; font-size:1rem;">
        <span class="icon-lock"></span> <span data-lang="product_login_to_buy">Login to contact seller</span>
      </a>
      <?php elseif ($isOwner): ?>
      <div style="display:flex; gap:8px;">
        <button class="btn btn-ghost" style="flex:1; justify-content:center;" onclick="confirmDelete()">
          <span class="icon-trash"></span> <span data-lang="product_delete">Delete Post</span>
        </button>
      </div>
      <div class="form-hint" data-lang="product_your_product">This is your product</div>
      <?php elseif ($product['status'] === 'active'): ?>
      <button class="btn btn-primary" id="buy-btn" style="width:100%; justify-content:center; padding:14px; font-size:1rem;">
        <span class="icon-cart"></span> <span data-lang="product_contact_seller">Contact Seller</span>
      </button>
      <?php else: ?>
      <div class="form-hint" data-lang="product_not_available">This product is not available</div>
      <?php endif; ?>
    </div>
    <div>
      <div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:8px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;" data-lang="product_seller">Seller</div>
      <div class="seller-card" onclick="showUserProfile(<?= $product['seller_id'] ?>)">
        <img src="<?= htmlspecialchars(getAvatarUrl($product['avatar'])) ?>" class="seller-avatar" alt="">
        <div>
          <div class="seller-name"><?= htmlspecialchars($product['username']) ?> <?= getRoleBadge($product['role']) ?></div>
          <div class="seller-sub"><?= $product['bio'] ? htmlspecialchars(mb_substr($product['bio'],0,60)) : '<span data-lang="product_no_bio">No bio</span>' ?></div>
        </div>
      </div>
    </div>
    <div>
      <div style="font-size:0.8rem; color:var(--text-muted); margin-bottom:8px; font-weight:600; text-transform:uppercase; letter-spacing:0.05em;" data-lang="product_description">Description</div>
      <div class="product-detail-desc"><?= $product['description'] ?></div>
    </div>
  </div>
</div>

<script>
document.getElementById('buy-btn')?.addEventListener('click', async () => {
  const btn = document.getElementById('buy-btn');
  btn.disabled = true; btn.innerHTML = '<div class="spinner" style="width:18px;height:18px;margin:0 auto;"></div>';
  try {
    const fd = new FormData(); fd.append('action','buy_product'); fd.append('product_id', <?= $pid ?>);
    const res = await fetch('api.php',{method:'POST',body:fd}); const data = await res.json();
    if (data.error) throw new Error(data.error);
    Toast.success(Lang.t('product_opening_chat'));
    setTimeout(() => window.location.href = data.redirect, 800);
  } catch(e) {
    Toast.error(e.message); btn.disabled = false;
    btn.innerHTML = '<span class="icon-cart"></span> ' + Lang.t('product_contact_seller');
  }
});
async function confirmDelete() {
  if (!confirm(Lang.t('product_confirm_delete'))) return;
  const fd = new FormData(); fd.append('action','delete_product'); fd.append('product_id', <?= $pid ?>);
  try {
    const res = await fetch('api.php',{method:'POST',body:fd}); const data = await res.json();
    if (data.error) throw new Error(data.error);
    Toast.success(Lang.t('product_deleted'));
    setTimeout(() => window.location.href = 'index.php', 1000);
  } catch(e) { Toast.error(e.message); }
}
</script>
