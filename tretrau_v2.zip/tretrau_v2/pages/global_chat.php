<?php
$db = getDB();
if (!defined('COMMUNITY_AVATAR')) {
    $_dragonPath = __DIR__ . '/../assets/dragon-icon.jpg';
    if (!file_exists($_dragonPath)) $_dragonPath = __DIR__ . '/assets/dragon-icon.jpg';
    if (file_exists($_dragonPath)) {
        define('COMMUNITY_AVATAR', 'data:image/jpeg;base64,' . base64_encode(file_get_contents($_dragonPath)));
    } else {
        define('COMMUNITY_AVATAR', 'assets/dragon-icon.jpg');
    }
}
$onlineStmt = $db->query("SELECT u.id, u.username, u.avatar, u.role FROM users u JOIN traffic_logs t ON t.user_id=u.id WHERE t.created_at > DATE_SUB(NOW(), INTERVAL 5 MINUTE) GROUP BY u.id ORDER BY MAX(t.created_at) DESC LIMIT 20");
$onlineUsers = $onlineStmt->fetchAll();
?>
<style>
html,body{overflow:hidden;height:100%}
.site-footer{display:none!important}
@media(max-width:768px){
  .site-header{display:flex!important}
  .bottom-nav{display:flex!important}
  .global-wrap{top:var(--header-height)!important;bottom:56px!important}
}
</style>

<div class="global-wrap">
  <div class="global-chat-col">
    <!-- Header with 3-dot menu -->
    <div class="global-hdr">
      <button class="chat-mob-back-btn" onclick="window.location.replace('/chat')" data-lang-title="product_go_back" style="display:flex;">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="none"><path d="M11 4L6 9l5 5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
      </button>
      <div class="global-hdr-avatar-wrap">
        <img src="<?=COMMUNITY_AVATAR?>" class="global-hdr-avatar" alt="">
        <div class="global-online-dot"></div>
      </div>
      <div class="global-hdr-info">
        <div class="global-hdr-name">
          TreTrau Network
          <span class="global-live-badge"><span class="global-live-dot"></span>LIVE</span>
        </div>
        <div class="global-hdr-sub" onclick="showGroupInfoFromMenu()"><?= count($onlineUsers) ?> <span data-lang="chat_members_online">members online</span></div>
      </div>
      <div class="chat-header-actions" style="position:relative;">
        <button class="chat-header-btn" onclick="toggle3DotMenu(this)" title="Menu">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="3" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="8" cy="13" r="1.5"/></svg>
        </button>
      </div>
    </div>

    <div id="chat-messages"></div>

    <!-- Input (same style as DM — no emoji btn) -->
    <div class="g-input-area">
      <div id="chat-reply-bar">
        <span class="icon-reply" style="color:var(--accent);font-size:.85rem;flex-shrink:0;"></span>
        <span id="chat-reply-text"></span>
        <button id="chat-reply-cancel"><span class="icon-x"></span></button>
      </div>
      <div id="chat-preview">
        <img id="chat-preview-img" src="" alt="">
        <button class="g-preview-rm" onclick="window.chatApp?.clearPreview()"><span class="icon-x"></span></button>
      </div>
      <div class="g-input-row">
        <label class="g-file-btn" title="Gửi ảnh">
          <span class="icon-image"></span>
          <input type="file" id="chat-file" accept="image/*" style="display:none;">
        </label>
        <div class="g-textarea-wrap">
          <textarea id="chat-input" class="chat-textarea" placeholder="Nhắn với mọi người..." rows="1"></textarea>
        </div>
        <button id="chat-send"><span class="icon-send"></span></button>
      </div>
    </div>
  </div>

  <!-- Online sidebar (desktop) -->
  <div class="g-sidebar">
    <div class="g-sidebar-hdr">Online ngay</div>
    <div class="g-online-list">
      <?php if ($onlineUsers): foreach ($onlineUsers as $ou): ?>
      <div class="g-user-row" onclick="showUserProfile(<?= $ou['id'] ?>)" data-username="<?= htmlspecialchars($ou['username']) ?>" data-role="<?= $ou['role'] ?>">
        <div class="g-av"><img src="<?= htmlspecialchars(getAvatarUrl($ou['avatar'])) ?>" alt=""></div>
        <div class="g-uname">
          <?= htmlspecialchars($ou['username']) ?>
          <?php if (in_array($ou['role'], ['admin','premium'])): ?>
          <span style="display:inline-flex;align-items:center;margin-left:2px;">
            <svg viewBox="0 0 14 14" fill="none" width="13" height="13"><circle cx="7" cy="7" r="7" fill="<?= $ou['role']==='admin'?'#e8192c':'#1877f2' ?>"/><path d="M4 7.2l2 2 4-4" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </span>
          <?php endif; ?>
        </div>
      </div>
      <?php endforeach; else: ?>
      <div style="padding:14px;text-align:center;color:var(--text-muted);font-size:.8rem;"><span data-lang="chat_no_conversations">No one online</span></div>
      <?php endif; ?>
    </div>
  </div>
</div>

<script>
window._communityAvatar = '<?=COMMUNITY_AVATAR?>';
document.addEventListener('DOMContentLoaded', function() {
  window.chatApp = new ChatApp({
    channelId: null, isGlobal: true, isDm: false, peerId: null,
    currentUserId: <?= (int)$user['id'] ?>
  });
});
</script>
