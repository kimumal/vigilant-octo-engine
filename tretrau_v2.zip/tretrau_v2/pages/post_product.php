<?php
$limit = getDailyPostLimit($user);
$todayCount = getTodayPostCount($user['id']);
$remaining = $limit - $todayCount;
$canPost = $remaining > 0;
$csrf = generateCSRF();
$categoryKeys = ['electronics','fashion','home','books','sports','games','other'];
?>
<style>
.post-form-grid { display: grid; grid-template-columns: 1fr 340px; gap: var(--sp-xl); align-items: start; }
.post-preview-wrap { position: sticky; top: calc(var(--header-height) + 16px); }
.post-preview-card { background: var(--surface); border: 1px solid var(--border); border-radius: var(--r-xl); overflow: hidden; }
.post-limit-bar { padding: var(--sp-md); background: var(--surface-2); border-radius: var(--r-md); border: 1px solid var(--border); margin-bottom: var(--sp-md); display: flex; align-items: center; gap: var(--sp-sm); font-size: 0.85rem; color: var(--text-secondary); }
.post-limit-count { font-weight: 700; color: var(--text-primary); }
.image-upload-area { border: 2px dashed var(--border); border-radius: var(--r-lg); padding: var(--sp-xl); text-align: center; cursor: pointer; transition: all var(--trans-fast); position: relative; }
.image-upload-area:hover, .image-upload-area.drag-over { border-color: var(--border-strong); background: var(--surface-2); }
.image-upload-area input[type=file] { position: absolute; inset:0; opacity:0; cursor:pointer; }
.upload-icon { font-size: 1.8rem; color: var(--text-muted); margin-bottom: 8px; }
.img-preview-box { position: relative; border-radius: var(--r-md); overflow: hidden; margin-top: var(--sp-sm); }
.img-preview-box img { width:100%; max-height:240px; object-fit:cover; }
.img-preview-remove { position: absolute; top:8px; right:8px; width:28px; height:28px; background: rgba(0,0,0,0.7); border-radius:50%; display:flex; align-items:center; justify-content:center; cursor:pointer; color:#fff; font-size:0.8rem; border:none; }
@media (max-width: 768px) { .post-form-grid { grid-template-columns: 1fr; } .post-preview-wrap { position: static; } }
</style>

<div style="margin-bottom: var(--sp-lg);">
  <h1 style="font-size:1.3rem; font-weight:800;" data-lang="post_title">Post Product</h1>
  <p style="color:var(--text-secondary); font-size:0.875rem; margin-top:4px;" data-lang="post_subtitle">Fill in details so your product gets noticed</p>
</div>

<!-- Limit notice -->
<div class="post-limit-bar">
  <span class="icon-tag"></span>
  <?php if ($canPost): ?>
  <span data-lang="post_remaining">You have</span> <span class="post-limit-count"><?= $remaining ?>/<?= $limit ?></span> <span data-lang="post_remaining2">posts remaining today</span>
  <?php else: ?>
  <span style="color:var(--danger);"><span data-lang="post_limit_reached">You have reached the limit of</span> <?= $limit ?> <span data-lang="post_limit_reached2">posts today. Try again tomorrow.</span></span>
  <?php endif; ?>
  <?php if ($user['role'] === 'new' || $user['role'] === 'user'): ?>
  <span style="margin-left:auto; font-size:0.75rem;"><a href="#" style="color:var(--text-secondary);" data-lang="post_upgrade_premium">Upgrade Premium</a> <span data-lang="post_upgrade_to_post">to post more</span></span>
  <?php endif; ?>
</div>

<?php if (!$canPost): ?>
<div class="empty-state">
  <div class="empty-icon"><span class="icon-clock"></span></div>
  <div class="empty-title" data-lang="post_limit_today">Limit reached today</div>
  <div class="empty-desc"><span data-lang="post_limit_account">Account</span> <?= ucfirst($user['role']) ?> <span data-lang="post_limit_max">can post up to</span> <?= $limit ?> <span data-lang="post_limit_per_day">posts/day.</span></div>
  <a href="/dashboard" class="btn btn-primary" data-lang="post_go_home">Go Home</a>
</div>
<?php return; endif; ?>

<div class="post-form-grid">
  <div>
    <form id="post-form" enctype="multipart/form-data">
      <input type="hidden" name="csrf" value="<?= $csrf ?>">
      <div class="card">
        <div class="card-header" data-lang="post_product_info">Product Information</div>
        <div class="card-body" style="display:flex;flex-direction:column;gap:var(--sp-md);">
          <div class="form-group">
            <label class="form-label" data-lang="post_field_title">Title *</label>
            <input type="text" name="title" id="field-title" class="form-input" data-lang-placeholder="post_field_title_ph" placeholder="Enter product title..." required maxlength="200" oninput="updatePreview()">
            <span class="form-hint" data-lang="post_field_title_hint">Max 200 characters. No HTML or special characters.</span>
          </div>
          <div class="form-group">
            <label class="form-label" data-lang="post_field_price">Price *</label>
            <div style="display:flex;gap:8px;">
              <input type="number" name="price" id="field-price" class="form-input" placeholder="0" min="0" required oninput="updatePreview()">
              <select name="currency" class="form-input" style="max-width:100px;">
                <option value="VND">VND</option>
                <option value="USD">USD</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label" data-lang="post_field_category">Category</label>
            <select name="category" class="form-input" id="category-select">
              <?php foreach ($categoryKeys as $k): ?>
              <option value="<?= $k ?>" data-lang="cat_<?= $k ?>"><?= $k ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label" data-lang="post_field_image">Product Image *</label>
            <div class="image-upload-area" id="upload-area">
              <input type="file" name="image" id="img-input" accept="image/*" onchange="previewImage(this)">
              <div id="upload-placeholder">
                <div class="upload-icon"><span class="icon-image"></span></div>
                <div style="font-weight:600; margin-bottom:4px;" data-lang="post_field_image_drag">Drag & drop or click to select image</div>
                <div style="font-size:0.78rem; color:var(--text-muted);" data-lang="post_field_image_hint">JPEG, PNG, WebP, GIF — max 5MB</div>
              </div>
              <div class="img-preview-box" id="img-preview-box" style="display:none;">
                <img id="img-preview" src="" alt="">
                <button type="button" class="img-preview-remove" onclick="clearImage()"><span class="icon-x"></span></button>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label" data-lang="post_field_desc">Product Description *</label>
            <textarea name="description" id="field-desc" class="form-input" rows="6"
              data-lang-placeholder="post_field_desc_ph" placeholder="Describe the product in detail..."
              required oninput="updatePreview()"></textarea>
            <span class="form-hint" data-lang="post_field_desc_hint">Max 5000 characters.</span>
          </div>
        </div>
      </div>
      <button type="submit" id="submit-btn" class="btn btn-primary" style="width:100%; justify-content:center; padding:14px; font-size:1rem; margin-top:var(--sp-md);">
        <span class="icon-check"></span> <span data-lang="post_submit">Post Product</span>
      </button>
    </form>
  </div>

  <div class="post-preview-wrap">
    <div style="font-size:0.8rem; color:var(--text-muted); font-weight:600; text-transform:uppercase; letter-spacing:0.05em; margin-bottom:8px;" data-lang="post_preview">Preview</div>
    <div class="post-preview-card">
      <div style="aspect-ratio:4/3; background:var(--surface-2); display:flex; align-items:center; justify-content:center;" id="preview-img-wrap">
        <span class="icon-image" style="font-size:2rem; color:var(--text-muted);"></span>
      </div>
      <div style="padding:14px;">
        <div id="preview-title" style="font-weight:600; margin-bottom:6px; color:var(--text-muted);" data-lang="post_preview_title">Product title</div>
        <div id="preview-price" style="font-size:1.1rem; font-weight:700;">--</div>
        <div style="display:flex; align-items:center; gap:6px; margin-top:8px; font-size:0.78rem; color:var(--text-muted);">
          <img src="<?= htmlspecialchars(getAvatarUrl($user['avatar'])) ?>" style="width:18px;height:18px;border-radius:50%;object-fit:cover;" alt="">
          <?= htmlspecialchars($user['username']) ?>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function previewImage(input) {
  const file = input.files[0]; if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    document.getElementById('img-preview').src = e.target.result;
    document.getElementById('img-preview-box').style.display = 'block';
    document.getElementById('upload-placeholder').style.display = 'none';
    document.getElementById('preview-img-wrap').innerHTML = `<img src="${e.target.result}" style="width:100%;height:100%;object-fit:cover;" alt="">`;
  };
  reader.readAsDataURL(file);
}
function clearImage() {
  document.getElementById('img-input').value = '';
  document.getElementById('img-preview-box').style.display = 'none';
  document.getElementById('upload-placeholder').style.display = 'block';
  document.getElementById('preview-img-wrap').innerHTML = '<span class="icon-image" style="font-size:2rem;color:var(--text-muted);"></span>';
}
function updatePreview() {
  const title = document.getElementById('field-title').value || Lang.t('post_preview_title');
  const price = document.getElementById('field-price').value;
  const titleEl = document.getElementById('preview-title');
  titleEl.textContent = title;
  titleEl.style.color = document.getElementById('field-title').value ? 'var(--text-primary)' : 'var(--text-muted)';
  document.getElementById('preview-price').textContent = price ? parseInt(price).toLocaleString(Lang.getLocale()) + '₫' : '--';
}
const area = document.getElementById('upload-area');
area.addEventListener('dragover', e => { e.preventDefault(); area.classList.add('drag-over'); });
area.addEventListener('dragleave', () => area.classList.remove('drag-over'));
area.addEventListener('drop', e => {
  e.preventDefault(); area.classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) { const dt = new DataTransfer(); dt.items.add(file); document.getElementById('img-input').files = dt.files; previewImage(document.getElementById('img-input')); }
});
document.getElementById('post-form').addEventListener('submit', async e => {
  e.preventDefault();
  const btn = document.getElementById('submit-btn'); const orig = btn.innerHTML;
  btn.disabled = true; btn.innerHTML = '<div class="spinner" style="width:18px;height:18px;margin:0 auto;"></div>';
  const fd = new FormData(e.target); fd.append('action','post_product');
  try {
    const res = await fetch('api.php',{method:'POST',body:fd}); const data = await res.json();
    if (data.error) throw new Error(data.error);
    if (data.pending) {
      document.getElementById('post-form').innerHTML = `
        <div style="text-align:center;padding:48px 20px;">
          <div style="display:flex;align-items:center;justify-content:center;width:64px;height:64px;background:rgba(124,131,253,.08);border:1px solid rgba(124,131,253,.2);border-radius:20px;margin:0 auto 20px;">
            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#7c83fd" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
          </div>
          <h3 style="font-size:1.15rem;font-weight:800;color:var(--text-primary);margin-bottom:8px;">${Lang.t('post_pending_title')}</h3>
          <p style="color:var(--text-secondary);font-size:.875rem;line-height:1.7;margin-bottom:28px;">
            ${Lang.t('post_pending_desc')}<br>${Lang.t('post_pending_desc2')}
          </p>
          <a href="/dashboard" class="btn btn-primary" style="display:inline-flex;gap:6px;align-items:center;">
            <span>← ${Lang.t('post_go_home')}</span>
          </a>
        </div>`;
    } else {
      Toast.success(Lang.t('post_success'));
      setTimeout(() => window.location.href = data.redirect, 800);
    }
  } catch(err) { Toast.error(err.message); btn.disabled = false; btn.innerHTML = orig; }
});
</script>
