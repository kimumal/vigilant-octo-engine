<?php
/**
 * router.php — Clean URL Router
 * Maps: /dashboard → home, /product/1 → product?id=1, /login → login, etc.
 * Không để lộ ?page= hay file path
 */

// Chỉ được require từ index.php
if (!defined('DB_HOST')) die();

function resolveRoute(): array {
    $uri = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH);
    $uri = '/' . trim($uri, '/');

    // Remove base path nếu chạy trong subdir
    $script = dirname($_SERVER['SCRIPT_NAME'] ?? '/');
    if ($script !== '/' && strpos($uri, $script) === 0) {
        $uri = substr($uri, strlen($script));
    }
    $uri = '/' . ltrim($uri, '/');

    // Route map: URI pattern → [page, extra_get_params]
    $routes = [
        '/'               => ['page' => 'home',         'id' => null],
        '/dashboard'      => ['page' => 'home',         'id' => null],
        '/home'           => ['page' => 'home',         'id' => null],
        '/login'          => ['page' => 'login',        'id' => null],
        '/register'       => ['page' => 'register',     'id' => null],
        '/logout'         => ['page' => 'logout',       'id' => null],
        '/account'        => ['page' => 'account',      'id' => null],
        '/settings'       => ['page' => 'account',      'id' => null],
        '/chat'           => ['page' => 'chat',         'id' => null],
        '/messages'       => ['page' => 'chat',         'id' => null],
        '/post'           => ['page' => 'post-product', 'id' => null],
        '/sell'           => ['page' => 'post-product', 'id' => null],
    ];

    // Static routes
    if (isset($routes[$uri])) {
        $r = $routes[$uri];
        $_GET['page'] = $r['page'];
        return $r;
    }

    // Dynamic: /product/123 or /product/123-slug
    if (preg_match('#^/product/(\d+)#', $uri, $m)) {
        $_GET['page'] = 'product';
        $_GET['id']   = (int)$m[1];
        return ['page' => 'product', 'id' => (int)$m[1]];
    }

    // Dynamic: /profile/123 or /profile/username
    if (preg_match('#^/profile/(\d+)#', $uri, $m)) {
        $_GET['page'] = 'profile';
        $_GET['id']   = (int)$m[1];
        return ['page' => 'profile', 'id' => (int)$m[1]];
    }
    if (preg_match('#^/profile/([a-zA-Z0-9_\-]{2,30})$#', $uri, $m)) {
        $_GET['page'] = 'profile';
        $_GET['username'] = $m[1];
        return ['page' => 'profile', 'username' => $m[1]];
    }

    // Dynamic: /chat/123 (DM)
    if (preg_match('#^/chat/(\d+)#', $uri, $m)) {
        $_GET['page'] = 'chat';
        $_GET['dm']   = (int)$m[1];
        return ['page' => 'chat', 'dm' => (int)$m[1]];
    }

    // Fallback: hỗ trợ ?page= cũ nhưng chuyển redirect sang clean URL
    if (!empty($_GET['page'])) {
        $page = preg_replace('/[^a-z0-9\-]/', '', strtolower($_GET['page']));
        $id   = isset($_GET['id']) ? (int)$_GET['id'] : null;

        // Redirect sang clean URL
        $map = [
            'home'         => '/dashboard',
            'login'        => '/login',
            'register'     => '/register',
            'logout'       => '/logout',
            'account'      => '/account',
            'chat'         => '/chat',
            'post-product' => '/post',
        ];
        if ($page === 'product' && $id) {
            header("Location: /product/{$id}", true, 301);
            exit;
        }
        if ($page === 'profile' && $id) {
            header("Location: /profile/{$id}", true, 301);
            exit;
        }
        if (isset($map[$page])) {
            header("Location: " . $map[$page], true, 301);
            exit;
        }
        return ['page' => $page, 'id' => $id];
    }

    // 404
    return ['page' => '404', 'id' => null];
}

/**
 * Helper: tạo URL sạch
 */
function url(string $page, int $id = 0, array $extra = []): string {
    $map = [
        'home'         => '/dashboard',
        'login'        => '/login',
        'register'     => '/register',
        'logout'       => '/logout',
        'account'      => '/account',
        'settings'     => '/account',
        'chat'         => '/chat',
        'post-product' => '/post',
    ];
    if ($page === 'product' && $id) return "/product/{$id}";
    if ($page === 'profile' && $id) return "/profile/{$id}";
    if ($page === 'chat' && $id)    return "/chat/{$id}";
    if (isset($map[$page])) {
        $u = $map[$page];
        if ($extra) $u .= '?' . http_build_query($extra);
        return $u;
    }
    return '/dashboard';
}
