# 🔒 TreTrau Security Hardening — Changelog

## Các lỗ hổng đã được fix

### 1. 🚨 CRITICAL: Credentials lộ qua web
- **Trước**: `config.php` chứa DB password, Telegram token hardcoded → hacker đọc được qua LFI/source disclosure
- **Sau**: Credentials load từ `.env.tretrau` file (blocked bởi .htaccess), `config.php` bị block truy cập trực tiếp

### 2. 🚨 CRITICAL: Database dump
- **Trước**: `backup.php` chỉ check admin role, không có 2FA, không rate limit
- **Sau**: Yêu cầu Telegram 2FA session + rate limit 3 lần/giờ + Telegram notification khi backup

### 3. 🚨 CRITICAL: Error messages leak DB info
- **Trước**: `api.php` trả về `$e->getMessage()` chứa SQL error, table name, column info
- **Sau**: Log error phía server, trả client message generic "Internal server error"

### 4. 🔥 HIGH: Không có WAF
- **Trước**: Không có protection chống SQL injection, LFI, XSS qua URL/params
- **Sau**: `security.php` WAF với 50+ patterns detect:
  - SQL Injection (union select, sleep, benchmark, etc.)
  - LFI/RFI (../../, php://filter, etc.)
  - XSS (<script>, javascript:, event handlers)
  - Webshell patterns (eval, system, passthru)
  - Path traversal + null byte injection
  - Auto-block IP sau khi detect attack

### 5. 🔥 HIGH: Webhook secret qua GET
- **Trước**: `approve_product`, `reject_product` nhận secret qua `$_GET['secret']` → lộ trong access log, URL bar
- **Sau**: Chỉ nhận qua POST hoặc custom header `X-Webhook-Secret` + `hash_equals()` constant-time comparison

### 6. 🔥 HIGH: Admin auto-promote hardcoded
- **Trước**: Username `phuvanduc` hardcode → ai register username đó trên instance khác = admin
- **Sau**: Đọc từ `$_ENV['ADMIN_USERNAME']`, configurable

### 7. ⚠️ MEDIUM: .htaccess yếu
- **Trước**: Chỉ block một số file extensions
- **Sau**: Block tất cả sensitive files (config.php, backup.php, setup.php, .env, etc.) + WAF rules trong .htaccess

### 8. ⚠️ MEDIUM: .user.ini thiếu
- **Trước**: Chỉ 3 dòng basic
- **Sau**: Disable dangerous functions (exec, shell_exec, etc.), session security, expose_php off, open_basedir

### 9. ⚠️ MEDIUM: Webhook debug endpoint
- **Trước**: `/admin/webhook.php?debug=1` leak bot token status
- **Sau**: Removed, chỉ trả "ok"

### 10. ⚠️ MEDIUM: File integrity check yếu
- **Trước**: Chỉ check file exists, scan extensions
- **Sau**: SHA-256 hash monitoring + webshell content scanning + Telegram alert khi file bị modify

## File mới thêm

| File | Mô tả |
|------|--------|
| `security.php` | WAF firewall — auto-load trước tất cả code |
| `logs/.htaccess` | Block web access tới security logs |
| `init_security.php` | Script chạy 1 lần để setup hashes + permissions |
| `.env.tretrau.example` | Template cho credentials file |

## File đã sửa

| File | Thay đổi |
|------|----------|
| `.htaccess` | Toàn bộ — thêm WAF rules, block sensitive files |
| `.user.ini` | Toàn bộ — hardened PHP settings |
| `config.php` | Load .env, integrate WAF, improved integrity check |
| `api.php` | Fix error leak, secure secret comparison |
| `index.php` | Strict page param sanitization |
| `backup.php` | Require 2FA session, rate limit, Telegram notify |
| `admin/admin.php` | Configurable admin username |
| `admin/webhook.php` | Remove debug info leak |
| `uploads/.htaccess` | Hardened — disable PHP engine, block all scripts |

## Hướng dẫn deploy

```bash
# 1. Upload tất cả files lên server

# 2. Tạo .env.tretrau với credentials thật
cp .env.tretrau.example .env.tretrau
nano .env.tretrau  # Edit với password/token thật

# 3. Chạy init script (1 lần duy nhất)
php init_security.php

# 4. XÓA init script
rm init_security.php

# 5. Tạo MySQL user riêng (QUAN TRỌNG - chống dump DB)
mysql -u root -p
> CREATE USER 'tretrau_user'@'localhost' IDENTIFIED BY 'STRONG_PASSWORD';
> GRANT SELECT, INSERT, UPDATE, DELETE ON marketplace_db.* TO 'tretrau_user'@'localhost';
> FLUSH PRIVILEGES;

# 6. Set permissions
chmod 640 config.php security.php .user.ini
chmod 600 .env.tretrau
chmod 750 logs/ uploads/ backups/
chmod 644 .htaccess

# 7. Test
curl -I https://yourdomain.com/config.php  # Should return 403
curl -I https://yourdomain.com/backup.php  # Should return 403
curl "https://yourdomain.com/index.php?page=../../config"  # Should return 403
```

## ⚠️ LƯU Ý QUAN TRỌNG

1. **Tạo MySQL user riêng** — Đây là cách hiệu quả nhất chống dump DB. User chỉ có SELECT/INSERT/UPDATE/DELETE, KHÔNG có FILE/DROP/ALTER privilege
2. **Đổi DB password** — Password hiện tại (`phuvanduc`) quá yếu
3. **Đổi webhook secret** — Secret hiện tại đang hardcode
4. **Regenerate Telegram bot token** nếu nghi ngờ đã bị lộ
5. **Monitor logs** — Check `/logs/security.log` thường xuyên
