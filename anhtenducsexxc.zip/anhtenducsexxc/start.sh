#!/bin/bash
# MAILER v7 PRO — unified start script
# Starts web server (server.py) + Telegram bot (bot.py) together
set -e
cd "$(dirname "$0")"

# Load .env
if [ -f .env ]; then
  set -o allexport
  source .env
  set +o allexport
fi

PORT=${PORT:-3000}

# Kill anything on the port first
PID=$(lsof -t -i:$PORT 2>/dev/null || true)
if [ -n "$PID" ]; then
  echo "[start] Killing PID $PID on port $PORT..."
  kill -9 $PID 2>/dev/null || true
  sleep 1
fi

# Kill any stale bot.py processes (prevent 409 Conflict)
pkill -f "python3 bot.py" 2>/dev/null || true
sleep 0.5

echo "[start] Starting MAILER v7 PRO server on port $PORT..."
python3 server.py &
SERVER_PID=$!
echo "[start] Server PID: $SERVER_PID"

# Wait for DB to initialize before bot starts
sleep 2

echo "[start] Starting Telegram bot..."
python3 bot.py &
BOT_PID=$!
echo "[start] Bot PID: $BOT_PID"

echo ""
echo "=========================================="
echo "  MAILER v7 PRO — Running"
echo "  Server : http://localhost:$PORT"
echo "  Bot    : polling Telegram"
echo "  Press Ctrl+C to stop both"
echo "=========================================="

# Wait for either process to exit, then kill the other
cleanup() {
  echo ""
  echo "[start] Shutting down..."
  kill $SERVER_PID 2>/dev/null || true
  kill $BOT_PID 2>/dev/null || true
  exit 0
}
trap cleanup SIGINT SIGTERM

# Block until interrupted
wait $SERVER_PID $BOT_PID
