#!/usr/bin/env python3
"""
MAILER v7 PRO — Telegram Bot

Features:
  - Key verification gate: chỉ user có key mới dùng được
  - Profile: lưu key theo Telegram ID
  - Cloud: download file (cần key), admin upload qua bot
  - Anti-spam: rate limit per user
  - Full inline keyboard menu
  - /start /help /key /profile /cloud /admin /pay /buy

Run: python3 bot.py
"""

import os, json, time, sqlite3, hashlib, uuid, logging, threading
import urllib.request, urllib.error
from datetime import datetime, timedelta, timezone
from pathlib import Path
from collections import defaultdict

# ── Load .env ─────────────────────────────────────────────────────────────────
def _load_dotenv():
    env_path = Path(__file__).parent / '.env'
    if not env_path.exists():
        return
    for line in env_path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith('#') or '=' not in line:
            continue
        k, _, v = line.partition('=')
        k = k.strip(); v = v.strip().strip('"').strip("'")
        if k and k not in os.environ:
            os.environ[k] = v

_load_dotenv()

logging.basicConfig(level=logging.INFO, format='%(asctime)s [BOT] %(levelname)s %(message)s')
log = logging.getLogger(__name__)

# ── CONFIG ────────────────────────────────────────────────────────────────────
BOT_TOKEN    = os.environ.get('MAILER_BOT_TOKEN', '').strip()
_admin_tg    = os.environ.get('MAILER_ADMIN_TG', '0').strip()
ADMIN_ID     = int(_admin_tg) if _admin_tg.isdigit() else 0
ADMIN_KEY    = os.environ.get('MAILER_ADMIN_KEY', '').strip()

BASE_DIR     = Path(__file__).parent
DB_PATH      = BASE_DIR / 'data' / 'mailer.db'
CLOUD_DIR    = BASE_DIR / 'data' / 'cloud'
CLOUD_DIR.mkdir(parents=True, exist_ok=True)

# Payment addresses
PAY_BTC_BNB  = '0x1c64960c4125eb231e179b72f6231e16ea4dfac3'
PAY_LTC      = 'ltc1q376u9qnct2575mjejw5hrnw2kh9h9vl8z2j5my'
PAY_USDT_BEP = '0x1c64960c4125eb231e179b72f6231e16ea4dfac3'

if not BOT_TOKEN:
    log.error("MISSING: MAILER_BOT_TOKEN not set in .env")
    raise SystemExit(1)
if not ADMIN_ID:
    log.error("MISSING: MAILER_ADMIN_TG not set in .env")
    raise SystemExit(1)

# ── TELEGRAM API ──────────────────────────────────────────────────────────────
API_BASE = f'https://api.telegram.org/bot{BOT_TOKEN}'
FILE_API = f'https://api.telegram.org/file/bot{BOT_TOKEN}'

_stopped = threading.Event()
_key_lock = threading.Lock()

# ── ANTI-SPAM ─────────────────────────────────────────────────────────────────
# Per-user: max N messages in window seconds
_spam_hits: dict = defaultdict(list)   # uid -> [timestamps]
_spam_lock = threading.Lock()
SPAM_MAX   = 8    # max messages per window
SPAM_WIN   = 10   # window in seconds
_spam_muted: dict = {}  # uid -> muted_until timestamp

def _is_spam(uid: int) -> bool:
    """Return True if user is sending too fast. Mutes for 30s on violation."""
    if uid == ADMIN_ID:
        return False
    now = time.time()
    with _spam_lock:
        if _spam_muted.get(uid, 0) > now:
            return True
        hits = _spam_hits[uid]
        hits[:] = [t for t in hits if now - t < SPAM_WIN]
        hits.append(now)
        if len(hits) >= SPAM_MAX:
            _spam_muted[uid] = now + 30
            hits.clear()
            return True
    return False

# ── STATE ─────────────────────────────────────────────────────────────────────
_pending: dict        = {}   # uid -> plan_key (awaiting screenshot)
_awaiting_reply: dict = {}   # admin_uid -> target_uid
_awaiting_key: set    = set()  # uids typing a key to verify
_awaiting_upload: dict= {}   # admin uid -> {'filename','original_name','file_size'}

# ── TELEGRAM HELPERS ──────────────────────────────────────────────────────────
def tg(method: str, timeout_s: int = 15, **kwargs) -> dict | None:
    url = f'{API_BASE}/{method}'
    data = {k: v for k, v in kwargs.items() if v is not None}
    body = json.dumps(data).encode()
    req = urllib.request.Request(
        url, data=body,
        headers={'Content-Type': 'application/json'},
        method='POST'
    )
    try:
        resp = urllib.request.urlopen(req, timeout=timeout_s)
        result = json.loads(resp.read())
        if not result.get('ok'):
            log.warning(f'tg/{method}: {result.get("description")}')
        return result
    except urllib.error.HTTPError as e:
        log.error(f'tg/{method} HTTP {e.code}: {e.read().decode(errors="replace")[:200]}')
        return None
    except Exception as e:
        log.error(f'tg/{method} error: {e}')
        return None

def tg_get_file(file_id: str) -> tuple | None:
    """Download file from Telegram. Returns (filename, bytes) or None."""
    r = tg('getFile', file_id=file_id)
    if not r or not r.get('ok'):
        return None
    fp = r['result']['file_path']
    try:
        with urllib.request.urlopen(f'{FILE_API}/{fp}', timeout=60) as resp:
            data = resp.read()
        return Path(fp).name, data
    except Exception as e:
        log.error(f'tg_get_file error: {e}')
        return None

def send(chat_id, text, markup=None, parse_mode='HTML'):
    return tg('sendMessage', chat_id=chat_id, text=text, parse_mode=parse_mode,
              reply_markup=json.dumps(markup) if markup else None)

def send_doc(chat_id, file_bytes: bytes, filename: str, caption: str = ''):
    boundary = 'b_' + uuid.uuid4().hex
    CRLF = b'\r\n'
    parts = []
    parts += [f'--{boundary}'.encode(), b'Content-Disposition: form-data; name="chat_id"', b'', str(chat_id).encode()]
    parts += [f'--{boundary}'.encode(),
              f'Content-Disposition: form-data; name="document"; filename="{filename}"'.encode(),
              b'Content-Type: application/octet-stream', b'', file_bytes]
    if caption:
        parts += [f'--{boundary}'.encode(), b'Content-Disposition: form-data; name="caption"', b'', caption.encode()]
    parts.append(f'--{boundary}--'.encode())
    body = CRLF.join(parts)
    req = urllib.request.Request(
        f'{API_BASE}/sendDocument', data=body,
        headers={'Content-Type': f'multipart/form-data; boundary={boundary}'},
        method='POST'
    )
    try:
        return json.loads(urllib.request.urlopen(req, timeout=60).read())
    except Exception as e:
        log.error(f'send_doc error: {e}')
        return None

def edit_text(cid, mid, text, markup=None):
    return tg('editMessageText', chat_id=cid, message_id=mid, text=text,
              parse_mode='HTML', reply_markup=json.dumps(markup) if markup else None)

def edit_markup(cid, mid, markup=None):
    return tg('editMessageReplyMarkup', chat_id=cid, message_id=mid,
              reply_markup=json.dumps(markup) if markup else None)

def answer_cb(cb_id, text='', alert=False):
    return tg('answerCallbackQuery', callback_query_id=cb_id, text=text, show_alert=alert)

def forward_msg(to_cid, from_cid, msg_id):
    return tg('forwardMessage', chat_id=to_cid, from_chat_id=from_cid, message_id=msg_id)

# ── DATABASE ──────────────────────────────────────────────────────────────────
def get_db():
    c = sqlite3.connect(str(DB_PATH), check_same_thread=False, timeout=15)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    return c

def _init_bot_tables():
    """Create bot-specific tables if not present."""
    c = get_db()
    try:
        # Map Telegram user → verified key
        c.execute("""
            CREATE TABLE IF NOT EXISTS tg_user_keys (
                tg_user_id   INTEGER PRIMARY KEY,
                key_display  TEXT NOT NULL,
                verified_at  TEXT DEFAULT CURRENT_TIMESTAMP,
                username     TEXT DEFAULT '',
                first_name   TEXT DEFAULT ''
            )
        """)
        # Cloud files (shared with server.py)
        c.execute("""
            CREATE TABLE IF NOT EXISTS cloud_files (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                filename      TEXT NOT NULL,
                original_name TEXT NOT NULL,
                file_size     INTEGER DEFAULT 0,
                uploaded_by   TEXT DEFAULT 'admin',
                description   TEXT DEFAULT '',
                downloads     INTEGER DEFAULT 0,
                created_at    TEXT DEFAULT CURRENT_TIMESTAMP
            )
        """)
        c.commit()
    finally:
        c.close()

def hk(k: str) -> str:
    return hashlib.sha256(k.encode()).hexdigest()

# ── KEY & USER FUNCTIONS ──────────────────────────────────────────────────────
def verify_key(key: str) -> dict | None:
    """Validate key. Returns record dict or None if invalid/expired."""
    if not key:
        return None
    key = key.strip().strip('​﻿\r\n\t')
    if ADMIN_KEY and key == ADMIN_KEY:
        return {'key_display': ADMIN_KEY, 'is_admin': 1, 'tier': 'admin',
                'expires_at': None, 'created_by': 'system'}
    c = get_db()
    try:
        rec = c.execute('SELECT * FROM api_keys WHERE key_hash=?', (hk(key),)).fetchone()
        if not rec:
            rec = c.execute('SELECT * FROM api_keys WHERE key_display=?', (key,)).fetchone()
        if not rec:
            return None
        rec = dict(rec)
        if rec.get('expires_at'):
            try:
                exp = datetime.fromisoformat(rec['expires_at'].split('+')[0].rstrip('Z'))
                if exp < datetime.utcnow():
                    return None
            except Exception:
                pass
        return rec
    finally:
        c.close()

def get_user_record(uid: int) -> dict | None:
    """Get stored key record for a Telegram user ID. Returns key info or None."""
    c = get_db()
    try:
        row = c.execute('SELECT * FROM tg_user_keys WHERE tg_user_id=?', (uid,)).fetchone()
        if not row:
            return None
        row = dict(row)
        # Re-validate the stored key is still active
        rec = verify_key(row['key_display'])
        if not rec:
            # Key expired/revoked → clean up
            c.execute('DELETE FROM tg_user_keys WHERE tg_user_id=?', (uid,))
            c.commit()
            return None
        return {**row, **rec}
    finally:
        c.close()

def save_user_record(uid: int, key: str, username: str, first_name: str):
    """Bind a Telegram user ID to a verified key."""
    c = get_db()
    try:
        c.execute("""
            INSERT INTO tg_user_keys(tg_user_id, key_display, verified_at, username, first_name)
            VALUES (?, ?, datetime('now'), ?, ?)
            ON CONFLICT(tg_user_id) DO UPDATE SET
                key_display=excluded.key_display,
                verified_at=excluded.verified_at,
                username=excluded.username,
                first_name=excluded.first_name
        """, (uid, key, username, first_name))
        c.commit()
    finally:
        c.close()

def is_verified(uid: int) -> bool:
    return uid == ADMIN_ID or get_user_record(uid) is not None

def get_plans() -> dict:
    try:
        c = get_db()
        rows = c.execute("SELECT * FROM plans WHERE active=1 ORDER BY days").fetchall()
        c.close()
        return {r['plan_key']: dict(r) for r in rows}
    except Exception as e:
        log.error(f'get_plans: {e}')
        return {}

def save_user_key(plan_key: str, creator: str = 'bot') -> tuple:
    plans = get_plans()
    p = plans.get(plan_key)
    if not p:
        return None, f'Unknown plan: {plan_key}'
    is_lifetime = (p['days'] >= 36500)
    exp_iso = None
    exp_display = 'Lifetime ∞'
    if not is_lifetime:
        exp_dt = (datetime.now(timezone.utc) + timedelta(days=p['days'])).replace(microsecond=0)
        exp_iso = exp_dt.isoformat().replace('+00:00', '')
        exp_display = exp_dt.strftime('%Y-%m-%d')
    with _key_lock:
        c = get_db()
        try:
            key = None
            for _ in range(20):
                raw = uuid.uuid4().hex.upper()
                candidate = f'USR-{raw[:8]}-{raw[8:16]}-{raw[16:24]}'
                if not c.execute('SELECT 1 FROM api_keys WHERE key_display=?', (candidate,)).fetchone():
                    key = candidate; break
            if not key:
                return None, 'Key collision'
            c.execute("""INSERT INTO api_keys
                (key_hash,key_display,is_admin,tier,expires_at,created_by,max_smtp,max_emails)
                VALUES (?,?,0,?,?,?,999999,999999)""",
                (hk(key), key, p['tier'], exp_iso, creator))
            c.commit()
            if not c.execute('SELECT 1 FROM api_keys WHERE key_display=?', (key,)).fetchone():
                return None, 'DB write verification failed'
            return key, exp_display
        except Exception as e:
            return None, str(e)
        finally:
            c.close()

def save_admin_key(creator: str = 'admin') -> tuple:
    with _key_lock:
        c = get_db()
        try:
            key = None
            for _ in range(20):
                raw = uuid.uuid4().hex.upper()
                candidate = f'ADM-{raw[:8]}-{raw[8:16]}-{raw[16:24]}'
                if not c.execute('SELECT 1 FROM api_keys WHERE key_display=?', (candidate,)).fetchone():
                    key = candidate; break
            if not key:
                return None, 'Collision'
            c.execute("""INSERT INTO api_keys
                (key_hash,key_display,is_admin,tier,expires_at,created_by,max_smtp,max_emails)
                VALUES (?,?,1,'admin',NULL,?,999999,999999)""",
                (hk(key), key, creator))
            c.commit()
            return key, 'Never (Admin)'
        except Exception as e:
            return None, str(e)
        finally:
            c.close()

def get_stats() -> dict:
    try:
        c = get_db()
        total  = c.execute('SELECT COUNT(*) FROM api_keys').fetchone()[0]
        active = c.execute("SELECT COUNT(*) FROM api_keys WHERE expires_at IS NULL OR expires_at > datetime('now')").fetchone()[0]
        users  = c.execute('SELECT COUNT(*) FROM tg_user_keys').fetchone()[0]
        smtp   = c.execute("SELECT COUNT(*) FROM smtp WHERE status='live'").fetchone()[0]
        sent   = c.execute("SELECT COUNT(*) FROM send_history WHERE status='sent'").fetchone()[0]
        cloud  = c.execute('SELECT COUNT(*) FROM cloud_files').fetchone()[0]
        c.close()
        return {'total_keys': total, 'active_keys': active, 'tg_users': users,
                'smtp_live': smtp, 'emails_sent': sent, 'cloud_files': cloud}
    except Exception as e:
        log.error(f'get_stats: {e}')
        return {}

def get_cloud_files() -> list:
    try:
        c = get_db()
        rows = c.execute('SELECT * FROM cloud_files ORDER BY created_at DESC').fetchall()
        c.close()
        return [dict(r) for r in rows]
    except Exception as e:
        log.error(f'get_cloud_files: {e}')
        return []

def add_cloud_file(filename: str, original_name: str, file_size: int, description: str = '') -> int:
    c = get_db()
    try:
        row_id = c.execute("""
            INSERT INTO cloud_files(filename,original_name,file_size,description)
            VALUES(?,?,?,?)""", (filename, original_name, file_size, description)).lastrowid
        c.commit()
        return row_id
    finally:
        c.close()

# ── KEYBOARDS ─────────────────────────────────────────────────────────────────
def kb(rows: list) -> dict:
    return {'inline_keyboard': rows}

def kb_guest_menu() -> dict:
    """Menu for users without a key."""
    return kb([
        [{'text': '🔑 Activate Key',  'callback_data': 'menu:verify'},
         {'text': '💰 Buy Key',       'callback_data': 'menu:buy'}],
        [{'text': '💳 Payment Info',  'callback_data': 'menu:pay'},
         {'text': '❓ Help',          'callback_data': 'menu:help'}],
    ])

def kb_user_menu() -> dict:
    """Menu for verified users."""
    return kb([
        [{'text': '👤 My Profile',   'callback_data': 'menu:profile'},
         {'text': '☁️ Cloud Files',  'callback_data': 'menu:cloud'}],
        [{'text': '📤 Web Panel',    'callback_data': 'menu:panel'},
         {'text': '💳 Pay Info',     'callback_data': 'menu:pay'}],
        [{'text': '🔑 Change Key',   'callback_data': 'menu:verify'},
         {'text': '❓ Help',         'callback_data': 'menu:help'}],
    ])

def kb_admin_menu() -> dict:
    return kb([
        [{'text': '📊 Stats',         'callback_data': 'adm:stats'},
         {'text': '🔑 Gen User Key',  'callback_data': 'adm:genkey'}],
        [{'text': '🛡️ Gen Admin Key', 'callback_data': 'adm:genadmin'},
         {'text': '☁️ Cloud Mgr',    'callback_data': 'adm:cloud'}],
        [{'text': '📋 List Keys',     'callback_data': 'adm:listkeys'},
         {'text': '🏠 Main Menu',     'callback_data': 'menu:main'}],
    ])

def kb_plans() -> dict:
    plans = get_plans()
    rows = []
    for k, p in plans.items():
        label = f"{p['name']} — {p['price']}"
        if p.get('price_vnd'):
            label += f" / {int(p['price_vnd']):,}₫".replace(',', '.')
        label += f" / {p['dur']}"
        rows.append([{'text': label, 'callback_data': f'plan:{k}'}])
    rows.append([{'text': '🔙 Back', 'callback_data': 'menu:main'}])
    return kb(rows)

def kb_confirm(pk: str) -> dict:
    return kb([
        [{'text': '✅ I paid — Send Screenshot', 'callback_data': f'confirm:{pk}'}],
        [{'text': '❌ Cancel', 'callback_data': 'cancel'}],
    ])

def kb_admin_approve(uid: int, pk: str) -> dict:
    return kb([[
        {'text': '✅ Confirm + Send Key', 'callback_data': f'ok:{uid}:{pk}'},
        {'text': '❌ Reject',             'callback_data': f'no:{uid}'},
    ]])

def kb_admin_msg(uid: int) -> dict:
    return kb([[
        {'text': '↩️ Reply',     'callback_data': f'reply:{uid}'},
        {'text': '🚫 Stop Chat', 'callback_data': f'stop:{uid}'},
    ]])

def kb_back_main() -> dict:
    return kb([[{'text': '🔙 Main Menu', 'callback_data': 'menu:main'}]])

def kb_genkey_plans() -> dict:
    plans = get_plans()
    rows = [[{'text': f"{p['name']} ({p['dur']})", 'callback_data': f'adm:genkey:{k}'}]
            for k, p in plans.items()]
    rows.append([{'text': '🔙 Back', 'callback_data': 'adm:main'}])
    return kb(rows)

def kb_cloud_files_dl() -> dict:
    files = get_cloud_files()
    if not files:
        return kb([[{'text': '🔙 Back', 'callback_data': 'menu:main'}]])
    rows = [[{'text': f"⬇️ {f['original_name']} ({f['file_size']//1024}KB)",
              'callback_data': f"cloud:dl:{f['id']}"}] for f in files[:20]]
    rows.append([{'text': '🔙 Main Menu', 'callback_data': 'menu:main'}])
    return kb(rows)

def kb_cloud_admin() -> dict:
    return kb([
        [{'text': '📤 Upload (send .txt file)', 'callback_data': 'cloud:upload_info'}],
        [{'text': '📋 List Files',  'callback_data': 'cloud:list'},
         {'text': '🗑️ Delete',     'callback_data': 'cloud:del_menu'}],
        [{'text': '🔙 Admin Menu',  'callback_data': 'adm:main'}],
    ])

def kb_cloud_del_menu() -> dict:
    files = get_cloud_files()
    if not files:
        return kb([[{'text': '🔙 Back', 'callback_data': 'adm:cloud'}]])
    rows = [[{'text': f"🗑️ {f['original_name']} ({f['file_size']//1024}KB)",
              'callback_data': f"cloud:del:{f['id']}"}] for f in files[:20]]
    rows.append([{'text': '🔙 Back', 'callback_data': 'adm:cloud'}])
    return kb(rows)

# ── FORMATTERS ────────────────────────────────────────────────────────────────
def fmt_welcome_guest(fname: str) -> str:
    plans = get_plans()
    plan_lines = '\n'.join(f"• {p['name']} — {p['price']} / {p['dur']}"
                           for p in plans.values())
    return (
        f"👋 Xin chào <b>{fname}</b>!\n\n"
        f"<b>MAILER v7 PRO</b> — Platform gửi mail chuyên nghiệp.\n\n"
        f"🔐 Bạn cần <b>key hợp lệ</b> để sử dụng dịch vụ.\n\n"
        f"📦 <b>Các gói:</b>\n{plan_lines}\n\n"
        f"👇 Chọn hành động:"
    )

def fmt_welcome_user(fname: str, rec: dict) -> str:
    exp = rec.get('expires_at') or 'Lifetime ∞'
    if isinstance(exp, str) and len(exp) > 10:
        exp = exp[:10]
    tier = (rec.get('tier') or 'pro').upper()
    return (
        f"👋 Chào lại <b>{fname}</b>!\n\n"
        f"✅ Key đã xác minh\n"
        f"🎫 Tier: <b>{tier}</b> | Expires: <b>{exp}</b>\n\n"
        f"👇 Chọn tính năng:"
    )

def fmt_pay_info() -> str:
    return (
        "💳 <b>Thông tin thanh toán</b>\n\n"
        "🔸 <b>BTC / BNB (BEP20)</b>\n"
        f"<code>{PAY_BTC_BNB}</code>\n\n"
        "🔸 <b>LTC (Litecoin)</b>\n"
        f"<code>{PAY_LTC}</code>\n\n"
        "🔸 <b>USDT (BEP20 / BSC)</b>\n"
        f"<code>{PAY_USDT_BEP}</code>\n\n"
        "⚡ Sau khi chuyển khoản, chọn gói và gửi ảnh chụp màn hình."
    )

def fmt_profile(uid: int) -> str:
    if uid == ADMIN_ID:
        s = get_stats()
        return (
            f"🛡️ <b>Admin Profile</b>\n\n"
            f"Telegram ID: <code>{uid}</code>\n"
            f"Role: <b>ADMIN</b>\n\n"
            f"📊 <b>Thống kê hệ thống:</b>\n"
            f"• Keys: {s.get('total_keys',0)} total / {s.get('active_keys',0)} active\n"
            f"• TG Users verified: {s.get('tg_users',0)}\n"
            f"• SMTP live: {s.get('smtp_live',0)}\n"
            f"• Đã gửi: {s.get('emails_sent',0):,}\n"
            f"• Cloud files: {s.get('cloud_files',0)}"
        )
    rec = get_user_record(uid)
    if not rec:
        return "❌ Bạn chưa xác minh key. Dùng /key để kích hoạt."
    exp = rec.get('expires_at') or 'Lifetime ∞'
    if isinstance(exp, str) and 'T' in exp:
        exp = exp[:10]
    tier = (rec.get('tier') or 'pro').upper()
    created = (rec.get('created_at') or '')[:10]
    veri = (rec.get('verified_at') or '')[:10]
    key_short = rec.get('key_display', '')
    if len(key_short) > 12:
        key_short = key_short[:12] + '...'
    role = '🛡️ Admin' if rec.get('is_admin') else '👤 User'
    return (
        f"👤 <b>Profile của bạn</b>\n\n"
        f"Telegram ID: <code>{uid}</code>\n"
        f"Key: <code>{key_short}</code>\n"
        f"Role: {role}\n"
        f"Tier: <b>{tier}</b>\n"
        f"Expires: <b>{exp}</b>\n"
        f"Key created: {created}\n"
        f"Verified at: {veri}\n\n"
        f"✅ Tài khoản đang hoạt động"
    )

def fmt_cloud_list(files: list) -> str:
    if not files:
        return "☁️ <b>Cloud Storage</b>\n\nChưa có file nào. Admin sẽ upload sớm."
    lines = ["☁️ <b>Cloud Storage</b>\n"]
    for i, f in enumerate(files, 1):
        kb = f['file_size'] // 1024
        size_str = f"{kb}KB" if kb < 1024 else f"{kb//1024}MB"
        lines.append(
            f"{i}. 📄 <b>{f['original_name']}</b>  {size_str}\n"
            + (f"   ↳ {f['description']}\n" if f.get('description') else '')
            + f"   Downloads: {f.get('downloads',0)} | {(f.get('created_at',''))[:10]}"
        )
    lines.append("\n⬇️ Chọn file để tải:")
    return '\n'.join(lines)

def fmt_help(is_admin: bool = False) -> str:
    base = (
        "📋 <b>MAILER v7 PRO — Commands</b>\n\n"
        "/start — Menu chính\n"
        "/help  — Hướng dẫn\n"
        "/key   — Xác minh / đổi key\n"
        "/profile — Xem thông tin tài khoản\n"
        "/cloud — Danh sách file tải về\n"
        "/pay   — Địa chỉ thanh toán\n"
        "/buy   — Mua key\n"
    )
    admin_cmds = (
        "\n<b>Admin:</b>\n"
        "/admin — Panel admin\n"
        "/genkey &lt;plan&gt; — Tạo user key\n"
        "/genadmin — Tạo admin key\n"
        "/stats — Thống kê\n"
        "/reply &lt;uid&gt; &lt;msg&gt; — Trả lời user\n"
        "(Gửi file .txt → Upload lên Cloud)\n"
    )
    return base + (admin_cmds if is_admin else '')

# ── MESSAGE HANDLER ───────────────────────────────────────────────────────────
def handle_message(msg: dict):
    chat_id  = msg['chat']['id']
    uid      = msg['from']['id']
    text     = msg.get('text', '')
    fname    = msg['from'].get('first_name', 'User')
    username = msg['from'].get('username', '')
    is_adm   = (uid == ADMIN_ID)

    # ── Anti-spam (skip for admin) ────────────────────────────────────────────
    if _is_spam(uid):
        send(chat_id, "⏳ Bạn gửi quá nhanh. Vui lòng chờ 30 giây.")
        return

    # ── Admin: document upload to cloud ───────────────────────────────────────
    if 'document' in msg and is_adm:
        doc = msg['document']
        orig = doc.get('file_name', 'file.txt')
        size = doc.get('file_size', 0)
        mime = doc.get('mime_type', '')
        if not orig.endswith('.txt') and 'text' not in mime:
            send(chat_id, "❌ Chỉ nhận file .txt")
            return
        if size > 1024 * 1024 * 1024:
            send(chat_id, "❌ File quá lớn (max 1GB)")
            return
        send(chat_id, f"⏳ Đang tải <b>{orig}</b> ({size//1024}KB)...")
        result = tg_get_file(doc['file_id'])
        if not result:
            send(chat_id, "❌ Không tải được file từ Telegram.")
            return
        _, file_bytes = result
        stored = f"{uuid.uuid4().hex}_{orig}"
        (CLOUD_DIR / stored).write_bytes(file_bytes)
        _awaiting_upload[uid] = {'filename': stored, 'original_name': orig, 'file_size': size}
        send(chat_id, f"✅ Đã lưu <b>{orig}</b>\n\nNhập mô tả cho file (hoặc /skip để bỏ qua):")
        return

    # ── Admin: enter description for uploaded file ─────────────────────────────
    if uid in _awaiting_upload and is_adm:
        info = _awaiting_upload.pop(uid)
        desc = '' if text.startswith('/skip') else text
        fid = add_cloud_file(info['filename'], info['original_name'], info['file_size'], desc)
        send(chat_id,
             f"☁️ <b>File đã thêm vào Cloud!</b>\n\n"
             f"📄 {info['original_name']}\n"
             f"ID: {fid} | Mô tả: {desc or '(không có)'}",
             markup=kb_admin_menu())
        return

    # ── Admin: reply to user ───────────────────────────────────────────────────
    if uid in _awaiting_reply and is_adm:
        target = _awaiting_reply.pop(uid)
        result = send(target, f"<b>💬 Support:</b>\n{text}")
        send(chat_id, f"✅ Đã trả lời <code>{target}</code>" if result and result.get('ok')
             else f"❌ Không gửi được tới <code>{target}</code>")
        return

    # ── User entering key to verify ───────────────────────────────────────────
    if uid in _awaiting_key and text and not text.startswith('/'):
        _awaiting_key.discard(uid)
        rec = verify_key(text.strip())
        if not rec:
            send(chat_id, "❌ Key không hợp lệ hoặc đã hết hạn.\n\nThử lại /key hoặc /buy để mua key.",
                 markup=kb([[{'text': '🔑 Thử lại', 'callback_data': 'menu:verify'},
                              {'text': '💰 Mua Key',  'callback_data': 'menu:buy'}]]))
            return
        save_user_record(uid, text.strip(), username, fname)
        exp = rec.get('expires_at') or 'Lifetime ∞'
        if isinstance(exp, str) and 'T' in exp:
            exp = exp[:10]
        send(chat_id,
             f"✅ <b>Key đã được xác minh!</b>\n\n"
             f"Tier: <b>{(rec.get('tier') or 'pro').upper()}</b>\n"
             f"Expires: <b>{exp}</b>\n\n"
             f"Bạn đã mở khóa đầy đủ tính năng!",
             markup=kb_user_menu())
        log.info(f"[verify] uid={uid} key={text[:14]}... OK")
        return

    # ── Commands ──────────────────────────────────────────────────────────────
    if text.startswith('/start') or text.startswith('/menu'):
        verified = is_adm or is_verified(uid)
        if is_adm:
            send(chat_id,
                 f"⚙️ Chào Admin <b>{fname}</b>!\nAdmin panel sẵn sàng.",
                 markup=kb_admin_menu())
        elif verified:
            rec = get_user_record(uid) or {}
            send(chat_id, fmt_welcome_user(fname, rec), markup=kb_user_menu())
        else:
            send(chat_id, fmt_welcome_guest(fname), markup=kb_guest_menu())
        return

    if text.startswith('/help'):
        send(chat_id, fmt_help(is_adm), markup=kb_back_main())
        return

    if text.startswith('/profile'):
        send(chat_id, fmt_profile(uid), markup=kb_back_main() if not is_adm else kb_admin_menu())
        return

    if text.startswith('/key'):
        _awaiting_key.add(uid)
        send(chat_id,
             "🔑 <b>Xác minh Key</b>\n\n"
             "Nhập key của bạn (dạng USR-XXXXXXXX-XXXXXXXX-XXXXXXXX):")
        return

    if text.startswith('/pay'):
        send(chat_id, fmt_pay_info(), markup=kb_back_main())
        return

    if text.startswith('/buy') or text.startswith('/price'):
        send(chat_id, "💰 <b>Chọn gói:</b>", markup=kb_plans())
        return

    if text.startswith('/cloud'):
        if not (is_adm or is_verified(uid)):
            send(chat_id, "🔐 Cần key hợp lệ để xem file.\n\nDùng /key để xác minh.",
                 markup=kb([[{'text': '🔑 Xác minh Key', 'callback_data': 'menu:verify'}]]))
            return
        files = get_cloud_files()
        send(chat_id, fmt_cloud_list(files), markup=kb_cloud_files_dl())
        return

    if text.startswith('/skip') and is_adm and uid in _awaiting_upload:
        info = _awaiting_upload.pop(uid)
        fid = add_cloud_file(info['filename'], info['original_name'], info['file_size'], '')
        send(chat_id, f"☁️ Đã thêm <b>{info['original_name']}</b> (ID: {fid})")
        return

    # ── Admin commands ─────────────────────────────────────────────────────────
    if text.startswith('/admin') and is_adm:
        send(chat_id, "⚙️ <b>Admin Panel</b>", markup=kb_admin_menu())
        return

    if text.startswith('/stats') and is_adm:
        s = get_stats()
        send(chat_id,
             f"📊 <b>Thống kê</b>\n\n"
             f"Keys: {s.get('total_keys',0)} / Active: {s.get('active_keys',0)}\n"
             f"TG Users verified: {s.get('tg_users',0)}\n"
             f"SMTP live: {s.get('smtp_live',0)}\n"
             f"Đã gửi: {s.get('emails_sent',0):,}\n"
             f"Cloud files: {s.get('cloud_files',0)}",
             markup=kb([[{'text':'🔙 Admin','callback_data':'adm:main'}]]))
        return

    if text.startswith('/genkey') and is_adm:
        parts = text.split()
        if len(parts) < 2:
            send(chat_id, 'Dùng: /genkey &lt;plan_key&gt;\nVí dụ: /genkey pro', markup=kb_genkey_plans())
            return
        key, exp = save_user_key(parts[1].lower(), creator=f'admin:{ADMIN_ID}')
        if not key:
            send(chat_id, f"❌ Lỗi: {exp}")
            return
        p = get_plans().get(parts[1].lower(), {})
        send(chat_id,
             f"✅ <b>User Key đã tạo</b>\n\n"
             f"Plan: <b>{p.get('name','?')}</b> ({p.get('dur','?')})\n"
             f"Key: <code>{key}</code>\n"
             f"Expires: {exp}",
             markup=kb([[{'text':'🔙 Admin','callback_data':'adm:main'}]]))
        return

    if text.startswith('/genadmin') and is_adm:
        key, exp = save_admin_key(creator=f'admin:{ADMIN_ID}')
        if not key:
            send(chat_id, f"❌ Lỗi: {exp}")
            return
        send(chat_id,
             f"🛡️ <b>Admin Key đã tạo</b>\n\n"
             f"Key: <code>{key}</code>\nExpires: {exp}\n\n⚠️ Bảo mật key này!",
             markup=kb([[{'text':'🔙 Admin','callback_data':'adm:main'}]]))
        return

    if text.startswith('/reply') and is_adm:
        parts = text.split(None, 2)
        if len(parts) < 3:
            send(chat_id, 'Dùng: /reply &lt;user_id&gt; &lt;message&gt;')
            return
        try:
            target = int(parts[1])
            r = send(target, f"<b>💬 Support:</b>\n{parts[2]}")
            send(chat_id, f"✅ Đã gửi tới <code>{target}</code>" if r and r.get('ok')
                 else f"❌ Gửi thất bại tới <code>{target}</code>")
        except ValueError:
            send(chat_id, '❌ User ID không hợp lệ')
        return

    if text.startswith('/stopchat') and is_adm:
        parts = text.split()
        if len(parts) < 2:
            send(chat_id, 'Dùng: /stopchat &lt;user_id&gt;')
            return
        try:
            target = int(parts[1])
            send(target, "🚫 Admin đã đóng cuộc trò chuyện này.\nDùng /start để bắt đầu lại.")
            send(chat_id, f"✅ Đã đóng chat với <code>{target}</code>")
        except Exception as e:
            send(chat_id, f"❌ Lỗi: {e}")
        return

    # ── Payment screenshot ─────────────────────────────────────────────────────
    if 'photo' in msg:
        pk = _pending.get(uid)
        if not pk:
            send(chat_id, 'Hãy chọn gói trước. Dùng /start', markup=kb_guest_menu())
            return
        p = get_plans().get(pk, {})
        try:
            forward_msg(ADMIN_ID, chat_id, msg['message_id'])
            uname_display = f"@{username}" if username else fname
            vnd = p.get('price_vnd', 0)
            vnd_str = f" / {int(vnd):,}₫".replace(',', '.') if vnd else ''
            send(ADMIN_ID,
                 f"📸 Thanh toán từ <b>{uname_display}</b> (ID: <code>{uid}</code>)\n"
                 f"Gói: <b>{p.get('name','?')}</b> — {p.get('price','?')}{vnd_str}",
                 markup=kb_admin_approve(uid, pk))
            send(chat_id, "✅ Đã gửi! Admin sẽ xác minh và gửi key sớm.")
        except Exception as e:
            log.error(f'forward screenshot: {e}')
            send(chat_id, '❌ Lỗi gửi ảnh. Thử lại.')
        return

    # ── Non-admin text → forward ───────────────────────────────────────────────
    if not is_adm and text and not text.startswith('/'):
        uname_display = f"@{username}" if username else fname
        send(ADMIN_ID,
             f"💬 Tin từ <b>{uname_display}</b> (ID: <code>{uid}</code>):\n\n{text}",
             markup=kb_admin_msg(uid))
        send(chat_id, "✅ Đã gửi cho admin. Sẽ phản hồi sớm.")
        return

# ── CALLBACK HANDLER ──────────────────────────────────────────────────────────
def handle_callback(cb: dict):
    cid    = cb['message']['chat']['id']
    mid    = cb['message']['message_id']
    uid    = cb['from']['id']
    data   = cb['data']
    cb_id  = cb['id']
    fname  = cb['from'].get('first_name', 'User')
    username = cb['from'].get('username', '')
    is_adm = (uid == ADMIN_ID)

    def ack(text='', alert=False): answer_cb(cb_id, text, alert)

    # ── Anti-spam for callbacks ────────────────────────────────────────────────
    if _is_spam(uid):
        ack("⏳ Quá nhanh, chờ 30 giây", alert=True)
        return

    verified = is_adm or is_verified(uid)

    # ── Main menu ──────────────────────────────────────────────────────────────
    if data == 'menu:main':
        if is_adm:
            edit_text(cid, mid, "⚙️ <b>Admin Panel</b>", markup=kb_admin_menu())
        elif verified:
            rec = get_user_record(uid) or {}
            edit_text(cid, mid, fmt_welcome_user(fname, rec), markup=kb_user_menu())
        else:
            edit_text(cid, mid, fmt_welcome_guest(fname), markup=kb_guest_menu())
        ack(); return

    if data == 'menu:help':
        edit_text(cid, mid, fmt_help(is_adm), markup=kb_back_main())
        ack(); return

    if data == 'menu:pay':
        edit_text(cid, mid, fmt_pay_info(), markup=kb_back_main())
        ack(); return

    if data == 'menu:buy':
        edit_text(cid, mid, "💰 <b>Chọn gói:</b>", markup=kb_plans())
        ack(); return

    if data == 'menu:verify':
        _awaiting_key.add(uid)
        edit_text(cid, mid,
                  "🔑 <b>Xác minh Key</b>\n\n"
                  "Gửi key của bạn vào chat này.\n"
                  "Định dạng: <code>USR-XXXXXXXX-XXXXXXXX-XXXXXXXX</code>",
                  markup=kb([[{'text': '❌ Huỷ', 'callback_data': 'cancel'}]]))
        ack(); return

    if data == 'menu:profile':
        if not verified:
            ack("🔐 Cần key hợp lệ", alert=True); return
        markup = kb_admin_menu() if is_adm else kb_user_menu()
        edit_text(cid, mid, fmt_profile(uid), markup=markup)
        ack(); return

    if data == 'menu:cloud':
        if not verified:
            edit_text(cid, mid,
                      "🔐 <b>Cần xác minh key</b>\n\nChỉ người dùng có key hợp lệ mới tải được file.",
                      markup=kb([[{'text': '🔑 Xác minh Key', 'callback_data': 'menu:verify'},
                                   {'text': '💰 Mua Key',     'callback_data': 'menu:buy'}]]))
            ack(); return
        files = get_cloud_files()
        edit_text(cid, mid, fmt_cloud_list(files), markup=kb_cloud_files_dl())
        ack(); return

    if data == 'menu:panel':
        if not verified:
            ack("🔐 Cần key hợp lệ", alert=True); return
        edit_text(cid, mid,
                  "📤 <b>Web Panel</b>\n\nTruy cập panel tại:\n"
                  "<code>https://tretrauont.lol</code>\n\n"
                  "Đăng nhập bằng key của bạn.",
                  markup=kb_back_main())
        ack(); return

    # ── Admin menu ─────────────────────────────────────────────────────────────
    if data == 'adm:main':
        if not is_adm: ack("⛔ Admin only", alert=True); return
        edit_text(cid, mid, "⚙️ <b>Admin Panel</b>", markup=kb_admin_menu())
        ack(); return

    if data == 'adm:stats':
        if not is_adm: ack("⛔", alert=True); return
        s = get_stats()
        edit_text(cid, mid,
                  f"📊 <b>Thống kê</b>\n\n"
                  f"Keys: {s.get('total_keys',0)} / Active: {s.get('active_keys',0)}\n"
                  f"TG Users: {s.get('tg_users',0)}\n"
                  f"SMTP live: {s.get('smtp_live',0)}\n"
                  f"Đã gửi: {s.get('emails_sent',0):,}\n"
                  f"Cloud files: {s.get('cloud_files',0)}",
                  markup=kb([[{'text':'🔙 Admin','callback_data':'adm:main'}]]))
        ack(); return

    if data == 'adm:genkey':
        if not is_adm: ack("⛔", alert=True); return
        edit_text(cid, mid, "🔑 <b>Tạo User Key</b>\n\nChọn gói:", markup=kb_genkey_plans())
        ack(); return

    if data.startswith('adm:genkey:'):
        if not is_adm: ack("⛔", alert=True); return
        pk = data.split(':', 2)[2]
        key, exp = save_user_key(pk, creator=f'admin:{ADMIN_ID}')
        if not key: ack(f"❌ {exp}", alert=True); return
        p = get_plans().get(pk, {})
        edit_text(cid, mid,
                  f"✅ <b>Key đã tạo</b>\n\n"
                  f"Plan: <b>{p.get('name','?')}</b>\n"
                  f"Key: <code>{key}</code>\n"
                  f"Expires: {exp}",
                  markup=kb([[{'text':'🔑 Tạo thêm','callback_data':'adm:genkey'},
                              {'text':'🔙 Admin','callback_data':'adm:main'}]]))
        ack('Key created!'); return

    if data == 'adm:genadmin':
        if not is_adm: ack("⛔", alert=True); return
        key, exp = save_admin_key(creator=f'admin:{ADMIN_ID}')
        if not key: ack(f"❌ {exp}", alert=True); return
        edit_text(cid, mid,
                  f"🛡️ <b>Admin Key đã tạo</b>\n\nKey: <code>{key}</code>\nExpires: {exp}\n\n⚠️ Bảo mật!",
                  markup=kb([[{'text':'🔙 Admin','callback_data':'adm:main'}]]))
        ack('Admin key created!'); return

    if data == 'adm:listkeys':
        if not is_adm: ack("⛔", alert=True); return
        c = get_db()
        rows = c.execute(
            "SELECT key_display,is_admin,tier,expires_at,created_at "
            "FROM api_keys ORDER BY created_at DESC LIMIT 10"
        ).fetchall()
        c.close()
        if not rows:
            edit_text(cid, mid, "Chưa có key.", markup=kb([[{'text':'🔙','callback_data':'adm:main'}]]))
            ack(); return
        lines = ["🔑 <b>Keys gần đây</b>\n"]
        for r in rows:
            role = '🛡️' if r['is_admin'] else '👤'
            exp = (r['expires_at'] or 'Forever')[:10]
            lines.append(f"{role} <code>{(r['key_display'] or '')[:22]}</code>\n   {r['tier']} | {exp}")
        edit_text(cid, mid, '\n'.join(lines),
                  markup=kb([[{'text':'🔙 Admin','callback_data':'adm:main'}]]))
        ack(); return

    if data == 'adm:cloud':
        if not is_adm: ack("⛔", alert=True); return
        files = get_cloud_files()
        edit_text(cid, mid,
                  f"☁️ <b>Cloud Manager</b>\n\nFiles: {len(files)}\nGửi file .txt vào chat để upload.",
                  markup=kb_cloud_admin())
        ack(); return

    # ── Cloud callbacks ────────────────────────────────────────────────────────
    if data == 'cloud:upload_info':
        if not is_adm: ack("⛔", alert=True); return
        edit_text(cid, mid,
                  "📤 <b>Upload File</b>\n\nGửi file <b>.txt</b> trực tiếp vào chat này.\nMax: 1GB",
                  markup=kb([[{'text':'🔙 Cloud','callback_data':'adm:cloud'}]]))
        ack(); return

    if data == 'cloud:list':
        files = get_cloud_files()
        edit_text(cid, mid, fmt_cloud_list(files), markup=kb_cloud_files_dl())
        ack(); return

    if data == 'cloud:del_menu':
        if not is_adm: ack("⛔", alert=True); return
        edit_text(cid, mid, "🗑️ Chọn file để xoá:", markup=kb_cloud_del_menu())
        ack(); return

    if data.startswith('cloud:del:'):
        if not is_adm: ack("⛔", alert=True); return
        fid = int(data.split(':')[2])
        c = get_db()
        row = c.execute('SELECT filename FROM cloud_files WHERE id=?', (fid,)).fetchone()
        if row:
            fp = CLOUD_DIR / row['filename']
            if fp.exists():
                try: fp.unlink()
                except: pass
            c.execute('DELETE FROM cloud_files WHERE id=?', (fid,))
            c.commit()
        c.close()
        ack('Đã xoá!') if row else ack('Không tìm thấy', alert=True)
        files = get_cloud_files()
        edit_text(cid, mid,
                  f"☁️ <b>Cloud Manager</b>\n\nFiles: {len(files)}",
                  markup=kb_cloud_admin())
        return

    if data.startswith('cloud:dl:'):
        if not verified:
            ack("🔐 Cần key hợp lệ để tải file!", alert=True); return
        fid = int(data.split(':')[2])
        c = get_db()
        row = c.execute('SELECT * FROM cloud_files WHERE id=?', (fid,)).fetchone()
        c.close()
        if not row:
            ack('File không tồn tại', alert=True); return
        fp = CLOUD_DIR / row['filename']
        if not fp.exists():
            ack('File bị mất khỏi server', alert=True); return
        ack('⏳ Đang gửi file...')
        file_bytes = fp.read_bytes()
        result = send_doc(cid, file_bytes, row['original_name'],
                          caption=f"📄 {row['original_name']}\n{row.get('description','')}")
        if result and result.get('ok'):
            c = get_db()
            c.execute('UPDATE cloud_files SET downloads=downloads+1 WHERE id=?', (fid,))
            c.commit(); c.close()
        else:
            send(cid, "❌ Gửi file thất bại. Thử lại sau.")
        return

    # ── Plan selection ─────────────────────────────────────────────────────────
    if data.startswith('plan:'):
        pk = data[5:]
        plans = get_plans(); p = plans.get(pk)
        if not p: ack('Unknown plan', alert=True); return
        _pending[uid] = pk
        vnd = p.get('price_vnd', 0)
        vnd_str = f" / {int(vnd):,}₫".replace(',', '.') if vnd else ''
        edit_text(cid, mid,
                  f"💰 <b>{p['name']} — {p['price']}{vnd_str} / {p['dur']}</b>\n\n"
                  f"Chuyển khoản tới:\n\n"
                  f"💳 BTC/BNB (BEP20):\n<code>{PAY_BTC_BNB}</code>\n\n"
                  f"💳 LTC:\n<code>{PAY_LTC}</code>\n\n"
                  f"💳 USDT (BEP20):\n<code>{PAY_USDT_BEP}</code>\n\n"
                  f"Sau khi chuyển → bấm nút bên dưới và gửi ảnh.",
                  markup=kb_confirm(pk))
        ack(); return

    if data.startswith('confirm:'):
        _pending[uid] = data[8:]
        edit_text(cid, mid,
                  "📸 <b>Gửi ảnh thanh toán</b>\n\nGửi ảnh chụp màn hình giao dịch.\nAdmin sẽ xác minh và gửi key.",
                  markup=kb([[{'text': '❌ Huỷ', 'callback_data': 'cancel'}]]))
        ack(); return

    if data == 'cancel':
        _pending.pop(uid, None)
        _awaiting_key.discard(uid)
        _awaiting_upload.pop(uid, None)
        if is_adm or is_verified(uid):
            menu = kb_admin_menu() if is_adm else kb_user_menu()
        else:
            menu = kb_guest_menu()
        edit_text(cid, mid, "❌ Đã huỷ.", markup=menu)
        ack(); return

    # ── Admin approve/reject ───────────────────────────────────────────────────
    if data.startswith('ok:') and is_adm:
        parts = data.split(':')
        if len(parts) < 3: ack('Invalid', alert=True); return
        target_uid = int(parts[1]); pk = parts[2]
        plans = get_plans()
        p = plans.get(pk) or next(iter(plans.values()), {})
        key, exp = save_user_key(pk, creator=f'bot_admin:{ADMIN_ID}')
        if not key: ack(f'DB error: {exp}', alert=True); return
        r = send(target_uid,
                 f"🎉 <b>Thanh toán xác nhận!</b>\n\n"
                 f"Cảm ơn bạn đã mua <b>MAILER v7 PRO</b>\n\n"
                 f"Gói: <b>{p.get('name','?')}</b>\n"
                 f"🔑 Key: <code>{key}</code>\n"
                 f"Expires: {exp}\n\n"
                 f"Dùng /key để xác minh key và mở khoá tính năng.",
                 markup=kb([[{'text': '🔑 Xác minh Key ngay', 'callback_data': 'menu:verify'}]]))
        if r and r.get('ok'):
            edit_markup(cid, mid, markup={'inline_keyboard': []})
            send(ADMIN_ID, f"✅ Key gửi cho <code>{target_uid}</code>\nKey: <code>{key}</code>")
            _pending.pop(target_uid, None)
            ack('Key sent!')
        else:
            ack(f'Gửi thất bại tới {target_uid}', alert=True)
        return

    if data.startswith('no:') and is_adm:
        target_uid = int(data[3:])
        try:
            send(target_uid,
                 "❌ <b>Chưa xác nhận thanh toán.</b>\n\nGửi ảnh rõ hơn hoặc liên hệ admin.")
        except Exception:
            pass
        edit_markup(cid, mid, markup={'inline_keyboard': []})
        _pending.pop(target_uid, None)
        ack('Rejected'); return

    # ── Reply callbacks ────────────────────────────────────────────────────────
    if data.startswith('reply:') and is_adm:
        target_uid = int(data[6:])
        _awaiting_reply[uid] = target_uid
        edit_markup(cid, mid, markup={'inline_keyboard': []})
        send(ADMIN_ID, f"↩️ Đang trả lời <code>{target_uid}</code>\n\nNhập tin nhắn:")
        ack(); return

    if data.startswith('stop:') and is_adm:
        target_uid = int(data[5:])
        try:
            send(target_uid, "🚫 Admin đã đóng cuộc trò chuyện này.\nDùng /start để bắt đầu lại.")
        except Exception:
            pass
        edit_markup(cid, mid, markup={'inline_keyboard': []})
        ack('Stopped'); return

    ack()

# ── POLLING LOOP ──────────────────────────────────────────────────────────────
def poll():
    log.info('=' * 55)
    log.info('MAILER v7 BOT — STARTING')
    log.info(f'Admin TG ID : {ADMIN_ID}')
    log.info(f'DB Path     : {DB_PATH}')
    log.info(f'Cloud Dir   : {CLOUD_DIR}')
    log.info(f'Token (tail): ...{BOT_TOKEN[-8:]}')
    log.info('=' * 55)

    if not DB_PATH.exists():
        log.error(f'DB not found: {DB_PATH} — chạy server.py trước')
        raise SystemExit(1)

    _init_bot_tables()

    # Clear webhook → polling mode
    r = tg('deleteWebhook', drop_pending_updates=False)
    if r and r.get('ok'):
        log.info('Webhook cleared — polling mode active')

    offset = None
    conflict_wait = 5

    while not _stopped.is_set():
        try:
            params = {'timeout': 30, 'allowed_updates': ['message', 'callback_query']}
            if offset is not None:
                params['offset'] = offset

            result = tg('getUpdates', timeout_s=45, **params)

            if result is None:
                time.sleep(3); continue

            if not result.get('ok'):
                code = result.get('error_code', 0)
                desc = result.get('description', '')
                if code == 409:
                    log.warning(f'409 Conflict — retry in {conflict_wait}s')
                    time.sleep(conflict_wait)
                    conflict_wait = min(conflict_wait * 2, 60)
                    continue
                log.warning(f'getUpdates not ok ({code}): {desc}')
                time.sleep(3); continue

            conflict_wait = 5
            for upd in result.get('result', []):
                offset = upd['update_id'] + 1
                try:
                    if 'message' in upd:
                        handle_message(upd['message'])
                    elif 'callback_query' in upd:
                        handle_callback(upd['callback_query'])
                except Exception as e:
                    log.error(f'Handler error (upd {upd["update_id"]}): {e}', exc_info=True)

        except KeyboardInterrupt:
            log.info('Bot stopped (Ctrl+C)')
            _stopped.set()
            break
        except Exception as e:
            log.error(f'Poll error: {e} — retry in 5s', exc_info=True)
            time.sleep(5)

if __name__ == '__main__':
    poll()
