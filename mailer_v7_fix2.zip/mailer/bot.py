#!/usr/bin/env python3
"""
MAILER v7 — Telegram Bot (stdlib only, no external deps)
Run: python3 bot.py
"""
import os, json, time, sqlite3, hashlib, random, logging, threading
import urllib.request, urllib.error
from datetime import datetime, timedelta, timezone

logging.basicConfig(level=logging.INFO, format='%(asctime)s [BOT] %(message)s')
log = logging.getLogger(__name__)

# ── CONFIG ────────────────────────────────────────────────────────────────────
BOT_TOKEN = os.environ.get('MAILER_BOT_TOKEN', '7973100374:AAExJlPR7ucLa1v4wh1XhRlJGydhq_SvJCI')
ADMIN_ID  = int(os.environ.get('MAILER_ADMIN_TG', '7490574579'))
USDT_ADDR = os.environ.get('MAILER_USDT', '0x1c64960c4125eb231e179b72f6231e16ea4dfac3')
DB_PATH   = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'data', 'mailer.db')

# CORRECT PRICES
PLANS = {
    'starter':  {'name': 'Starter',  'price': '$10',  'dur': '1 Week',   'days': 7,   'tier': 'basic'},
    'pro':      {'name': 'Pro',      'price': '$30',  'dur': '1 Month',  'days': 30,  'tier': 'pro'},
    'advanced': {'name': 'Advanced', 'price': '$100', 'dur': '4 Months', 'days': 120, 'tier': 'pro'},
    'ultimate': {'name': 'Ultimate', 'price': '$180', 'dur': '7 Months', 'days': 210, 'tier': 'unlimited'},
}

# State
pending: dict = {}   # uid -> plan_key
stopped = threading.Event()

# ── TELEGRAM API ──────────────────────────────────────────────────────────────
API_BASE = f'https://api.telegram.org/bot{BOT_TOKEN}'

def tg(method: str, **kwargs) -> dict | None:
    """Call Telegram Bot API. Returns result dict or None on error."""
    url = f'{API_BASE}/{method}'
    # Remove None values
    data = {k: v for k, v in kwargs.items() if v is not None}
    body = json.dumps(data).encode()
    req = urllib.request.Request(
        url, data=body,
        headers={'Content-Type': 'application/json'},
        method='POST'
    )
    try:
        resp = urllib.request.urlopen(req, timeout=15)
        result = json.loads(resp.read())
        if not result.get('ok'):
            log.warning(f'tg {method} not ok: {result.get("description")}')
        return result
    except urllib.error.HTTPError as e:
        body_err = e.read().decode()
        log.error(f'tg {method} HTTP {e.code}: {body_err[:200]}')
        return None
    except Exception as e:
        log.error(f'tg {method} error: {e}')
        return None

def send(chat_id, text, reply_markup=None, parse_mode='HTML'):
    return tg('sendMessage',
        chat_id=chat_id, text=text,
        parse_mode=parse_mode,
        reply_markup=json.dumps(reply_markup) if reply_markup else None
    )

def edit_text(chat_id, message_id, text, reply_markup=None):
    return tg('editMessageText',
        chat_id=chat_id, message_id=message_id,
        text=text, parse_mode='HTML',
        reply_markup=json.dumps(reply_markup) if reply_markup else None
    )

def edit_markup(chat_id, message_id, reply_markup=None):
    return tg('editMessageReplyMarkup',
        chat_id=chat_id, message_id=message_id,
        reply_markup=json.dumps(reply_markup) if reply_markup else None
    )

def answer_cb(callback_query_id, text='', show_alert=False):
    return tg('answerCallbackQuery',
        callback_query_id=callback_query_id,
        text=text, show_alert=show_alert
    )

def forward(to_chat_id, from_chat_id, message_id):
    return tg('forwardMessage',
        chat_id=to_chat_id,
        from_chat_id=from_chat_id,
        message_id=message_id
    )

# ── KEYBOARDS ─────────────────────────────────────────────────────────────────
def kb_plans():
    return {'inline_keyboard': [
        [{'text': f"{p['name']}  —  {p['price']} / {p['dur']}", 'callback_data': f'plan:{k}'}]
        for k, p in PLANS.items()
    ]}

def kb_confirm(plan_key):
    return {'inline_keyboard': [
        [{'text': 'I sent payment — Submit screenshot', 'callback_data': f'confirm:{plan_key}'}],
        [{'text': 'Cancel', 'callback_data': 'cancel'}],
    ]}

def kb_admin(uid, plan_key):
    return {'inline_keyboard': [[
        {'text': 'Confirm + Send Key', 'callback_data': f'ok:{uid}:{plan_key}'},
        {'text': 'Reject',             'callback_data': f'no:{uid}'},
    ]]}

def kb_admin_msg(uid):
    """Admin keyboard for forwarded user messages."""
    return {'inline_keyboard': [[
        {'text': 'Reply',     'callback_data': f'reply:{uid}'},
        {'text': 'Stop Chat', 'callback_data': f'stop:{uid}'},
    ]]}

def kb_empty():
    return {'inline_keyboard': []}

# ── DATABASE ──────────────────────────────────────────────────────────────────
def get_db():
    c = sqlite3.connect(DB_PATH, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c

def hk(k): return hashlib.sha256(k.encode()).hexdigest()

def make_key():
    return 'MAILER-' + ''.join(random.choices('0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=16))

def save_key(plan_key, creator='bot'):
    p = PLANS[plan_key]
    key = make_key()
    exp = (datetime.now() + timedelta(days=p['days'])).isoformat()
    try:
        c = get_db()
        c.execute(
            'INSERT INTO api_keys(key_hash,key_display,is_admin,tier,expires_at,created_by,max_smtp,max_emails)'
            ' VALUES(?,?,0,?,?,?,999999,999999)',
            (hk(key), key, p['tier'], exp, creator)
        )
        c.commit(); c.close()
        return key, datetime.fromisoformat(exp).strftime('%Y-%m-%d')
    except Exception as e:
        log.error(f'save_key error: {e}')
        return None, str(e)

def get_stats():
    try:
        c = get_db()
        total  = c.execute('SELECT COUNT(*) FROM api_keys').fetchone()[0]
        active = c.execute(
            'SELECT COUNT(*) FROM api_keys WHERE (expires_at IS NULL OR expires_at > ?)',
            (datetime.now().isoformat(),)
        ).fetchone()[0]
        smtp   = c.execute("SELECT COUNT(*) FROM smtp WHERE status='live'").fetchone()[0]
        sent   = c.execute("SELECT COUNT(*) FROM send_history WHERE status='sent'").fetchone()[0]
        c.close()
        return total, active, smtp, sent
    except Exception as e:
        log.error(f'stats error: {e}')
        return 0, 0, 0, 0

# ── MESSAGE HANDLERS ──────────────────────────────────────────────────────────
def handle_message(msg: dict):
    chat_id = msg['chat']['id']
    uid     = msg['from']['id']
    text    = msg.get('text', '')
    fname   = msg['from'].get('first_name', 'there')
    uname   = f"@{msg['from']['username']}" if msg['from'].get('username') else fname

    # ── /start or /help ──
    if text.startswith('/start') or text.startswith('/help'):
        send(chat_id,
            f"Hello <b>{fname}</b>! Welcome to <b>MAILER v7 PRO</b>\n\n"
            f"Professional bulk email sender platform.\n"
            f"Choose a plan to get your license key.\n\n"
            f"<b>Pricing:</b>\n"
            f"Starter — <b>$10</b> / 1 Week\n"
            f"Pro — <b>$30</b> / 1 Month\n"
            f"Advanced — <b>$100</b> / 4 Months\n"
            f"Ultimate — <b>$180</b> / 7 Months\n\n"
            f"Payment: <b>USDT BEP20 (BSC)</b>\n"
            f"Address:\n<code>{USDT_ADDR}</code>",
            reply_markup=kb_plans()
        )
        return

    # ── /price or /buy ──
    if text.startswith('/price') or text.startswith('/buy') or text.startswith('/plans'):
        lines = ['<b>MAILER v7 PRO — Pricing</b>\n']
        for p in PLANS.values():
            lines.append(f"<b>{p['name']}</b>  {p['price']}  /  {p['dur']}")
        lines.append(f'\nPayment: USDT BEP20 (BSC)\n<code>{USDT_ADDR}</code>')
        send(chat_id, '\n'.join(lines), reply_markup=kb_plans())
        return

    # ── Admin: /genkey <plan> ──
    if text.startswith('/genkey') and uid == ADMIN_ID:
        parts = text.split()
        pk = parts[1].lower() if len(parts) > 1 else 'pro'
        if pk not in PLANS:
            send(chat_id, f"Unknown plan. Valid: {', '.join(PLANS)}")
            return
        key, exp = save_key(pk, creator='admin_manual')
        if not key:
            send(chat_id, f"Error: {exp}")
            return
        p = PLANS[pk]
        send(chat_id,
            f"Key generated\n"
            f"Plan: <b>{p['name']}</b> / {p['dur']}\n"
            f"Key: <code>{key}</code>\n"
            f"Expires: {exp}"
        )
        return

    # ── Admin: /stats ──
    if text.startswith('/stats') and uid == ADMIN_ID:
        total, active, smtp, sent = get_stats()
        send(chat_id,
            f"<b>MAILER v7 Stats</b>\n\n"
            f"Keys: {total} total / {active} active\n"
            f"SMTP live: {smtp}\n"
            f"Total sent: {sent:,}"
        )
        return

    # ── Admin: /reply <uid> <message> ──
    if text.startswith('/reply') and uid == ADMIN_ID:
        parts = text.split(None, 2)
        if len(parts) < 3:
            send(chat_id, 'Usage: /reply &lt;user_id&gt; &lt;message&gt;')
            return
        try:
            target = int(parts[1])
            msg_text = parts[2]
            result = send(target, f"<b>Support:</b>\n{msg_text}")
            if result and result.get('ok'):
                send(chat_id, f"Replied to <code>{target}</code>")
            else:
                send(chat_id, f"Failed to send to <code>{target}</code>")
        except ValueError:
            send(chat_id, 'Invalid user ID')
        return

    # ── Admin: /stopchat <uid> ──
    if text.startswith('/stopchat') and uid == ADMIN_ID:
        parts = text.split()
        if len(parts) < 2:
            send(chat_id, 'Usage: /stopchat &lt;user_id&gt;')
            return
        try:
            target = int(parts[1])
            send(target,
                "This conversation has been closed by admin.\n"
                "Use /start to open a new conversation."
            )
            send(chat_id, f"Closed chat with <code>{target}</code>")
        except (ValueError, Exception) as e:
            send(chat_id, f"Error: {e}")
        return

    # ── Photo = payment screenshot ──
    if 'photo' in msg:
        pk = pending.get(uid)
        if not pk:
            send(chat_id, 'Please select a plan first. Use /start')
            return
        p = PLANS[pk]
        try:
            forward(ADMIN_ID, chat_id, msg['message_id'])
            send(ADMIN_ID,
                f"Payment screenshot from <b>{uname}</b> (ID: <code>{uid}</code>)\n"
                f"Plan: <b>{p['name']}</b> — {p['price']} / {p['dur']}",
                reply_markup=kb_admin(uid, pk)
            )
            send(chat_id, 'Screenshot received! Admin will verify and send your key shortly.')
        except Exception as e:
            log.error(f'forward screenshot error: {e}')
            send(chat_id, 'Error forwarding to admin. Please try again.')
        return

    # ── User text message → forward to admin ──
    if uid != ADMIN_ID and text and not text.startswith('/'):
        send(ADMIN_ID,
            f"Message from <b>{uname}</b> (ID: <code>{uid}</code>):\n\n{text}",
            reply_markup=kb_admin_msg(uid)
        )
        send(chat_id,
            "Your message has been sent to admin.\n"
            "You will receive a reply shortly.\n\n"
            "Use /start to view plans or /price for pricing."
        )
        return

# ── CALLBACK HANDLERS ─────────────────────────────────────────────────────────
def handle_callback(cb: dict):
    cid   = cb['message']['chat']['id']
    mid   = cb['message']['message_id']
    uid   = cb['from']['id']
    data  = cb['data']
    cb_id = cb['id']

    # ── plan:<key> ──
    if data.startswith('plan:'):
        pk = data[5:]
        p  = PLANS.get(pk)
        if not p:
            answer_cb(cb_id, 'Unknown plan'); return
        pending[uid] = pk
        edit_text(cid, mid,
            f"<b>{p['name']} — {p['price']} / {p['dur']}</b>\n\n"
            f"Send exactly <b>{p['price']}</b> USDT (BEP20) to:\n"
            f"<code>{USDT_ADDR}</code>\n\n"
            f"After sending, press the button below and send your payment screenshot.",
            reply_markup=kb_confirm(pk)
        )
        answer_cb(cb_id)
        return

    # ── confirm:<key> ──
    if data.startswith('confirm:'):
        pk = data[8:]
        pending[uid] = pk
        edit_text(cid, mid,
            "Send your payment screenshot in this chat.\n"
            "Admin will verify and send your key shortly."
        )
        answer_cb(cb_id)
        return

    # ── cancel ──
    if data == 'cancel':
        pending.pop(uid, None)
        edit_text(cid, mid, 'Cancelled. Use /start to begin again.')
        answer_cb(cb_id)
        return

    # ── ok:<uid>:<plan> — admin confirms ──
    if data.startswith('ok:') and uid == ADMIN_ID:
        parts = data.split(':')
        if len(parts) < 3:
            answer_cb(cb_id, 'Invalid data'); return
        target_uid = int(parts[1])
        pk = parts[2]
        p  = PLANS.get(pk, PLANS['pro'])
        key, exp = save_key(pk, creator=f'bot_admin_{ADMIN_ID}')
        if not key:
            answer_cb(cb_id, f'DB error: {exp}', show_alert=True); return
        # Send key to user
        result = send(target_uid,
            f"Your payment has been confirmed!\n\n"
            f"Thank you for purchasing <b>MAILER v7 PRO</b>\n\n"
            f"Plan: <b>{p['name']}</b> — {p['price']}\n"
            f"Key: <code>{key}</code>\n"
            f"Expires: {exp}\n\n"
            f"Enter this key at the login page to activate.\n"
            f"Contact admin via @RedxMails_Bot if you need help."
        )
        if result and result.get('ok'):
            # Clear admin buttons
            edit_markup(cid, mid, reply_markup=kb_empty())
            # Notify admin
            send(ADMIN_ID,
                f"Key sent to <code>{target_uid}</code>\n"
                f"Key: <code>{key}</code>\n"
                f"Plan: {p['name']} / Expires: {exp}"
            )
            pending.pop(target_uid, None)
            answer_cb(cb_id, 'Key sent successfully!')
        else:
            answer_cb(cb_id, f'Failed to send key to user {target_uid}', show_alert=True)
        return

    # ── no:<uid> — admin rejects ──
    if data.startswith('no:') and uid == ADMIN_ID:
        target_uid = int(data[3:])
        try:
            send(target_uid,
                "Your payment could not be verified.\n"
                "Please send a clearer screenshot or contact admin."
            )
        except Exception: pass
        edit_markup(cid, mid, reply_markup=kb_empty())
        send(ADMIN_ID, f"Rejected user <code>{target_uid}</code>")
        pending.pop(target_uid, None)
        answer_cb(cb_id, 'Rejected')
        return

    # ── reply:<uid> — admin wants to reply ──
    if data.startswith('reply:') and uid == ADMIN_ID:
        target_uid = data[6:]
        edit_markup(cid, mid, reply_markup=kb_empty())
        send(ADMIN_ID,
            f"To reply to user <code>{target_uid}</code>, use:\n"
            f"/reply {target_uid} your message here"
        )
        answer_cb(cb_id)
        return

    # ── stop:<uid> — admin stops chat ──
    if data.startswith('stop:') and uid == ADMIN_ID:
        target_uid = int(data[5:])
        try:
            send(target_uid,
                "This conversation has been closed by admin.\n"
                "Use /start to open a new conversation."
            )
        except Exception: pass
        edit_markup(cid, mid, reply_markup=kb_empty())
        send(ADMIN_ID, f"Stopped chat with <code>{target_uid}</code>")
        answer_cb(cb_id, 'Chat stopped')
        return

    answer_cb(cb_id)

# ── POLLING LOOP ──────────────────────────────────────────────────────────────
def poll():
    offset = None
    log.info(f'Bot started | Admin: {ADMIN_ID} | DB: {DB_PATH}')
    log.info(f'Token: ...{BOT_TOKEN[-8:]}')

    # Delete webhook to ensure polling works
    r = tg('deleteWebhook')
    if r and r.get('ok'):
        log.info('Webhook cleared')

    while not stopped.is_set():
        try:
            params = {
                'timeout': 30,
                'allowed_updates': ['message', 'callback_query'],
            }
            if offset is not None:
                params['offset'] = offset

            result = tg('getUpdates', **params)

            if not result or not result.get('ok'):
                time.sleep(3)
                continue

            updates = result.get('result', [])
            for upd in updates:
                offset = upd['update_id'] + 1
                try:
                    if 'message' in upd:
                        handle_message(upd['message'])
                    elif 'callback_query' in upd:
                        handle_callback(upd['callback_query'])
                except Exception as e:
                    log.error(f'Handler error: {e}')

        except KeyboardInterrupt:
            log.info('Stopped by user')
            stopped.set()
            break
        except Exception as e:
            log.error(f'Poll error: {e} — retry in 5s')
            time.sleep(5)

if __name__ == '__main__':
    # Verify DB exists
    if not os.path.exists(DB_PATH):
        log.error(f'DB not found: {DB_PATH}')
        log.error('Start server.py first to initialize the database, then run bot.py')
        exit(1)
    poll()
