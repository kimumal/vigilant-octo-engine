#!/bin/bash
# =============================================================
#  SETUP SCRIPT — TreTrauNetwork v2
#  Ubuntu 20.04 / 22.04 / 24.04
#  Chay voi quyen root: sudo bash setup.sh
# =============================================================

set -e
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'
info()   { echo -e "${CYAN}[INFO]${NC} $1"; }
ok()     { echo -e "${GREEN}[OK]${NC}   $1"; }
warn()   { echo -e "${YELLOW}[WARN]${NC} $1"; }
die()    { echo -e "${RED}[ERR]${NC}  $1"; exit 1; }
header() { echo -e "\n${BOLD}${CYAN}══════════════════════════════════════════${NC}";
           echo -e "${BOLD}${CYAN}  $1${NC}";
           echo -e "${BOLD}${CYAN}══════════════════════════════════════════${NC}"; }

[[ $EUID -ne 0 ]] && die "Can chay voi quyen root: sudo bash $0"

# ==============================================================
#  CAU HINH — chinh truoc khi chay
# ==============================================================
DOMAIN=""                    # Ten mien hoac IP (VD: tretraunetwork.space)
WEBROOT="/var/www/tretrau"   # Thu muc web
PHP_VERSION="8.2"

DB_HOST="127.0.0.1"
DB_NAME="marketplace_db"
DB_USER="tretrau_user"
DB_PASS=""                   # De trong -> tu sinh ngau nhien

ADMIN_USER="admin"
ADMIN_PASS=""                # De trong -> tu sinh ngau nhien

TELEGRAM_BOT_TOKEN=""        # Token bot Telegram
TELEGRAM_ADMIN_CHAT_ID=""   # Chat ID admin
TELEGRAM_WEBHOOK_SECRET=""   # De trong -> tu sinh

ENABLE_SSL=true
# ==============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG_FILE="/tmp/tretrau_setup_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG_FILE") 2>&1

[[ -z "$DOMAIN" ]] && { DOMAIN=$(curl -s --max-time 5 ifconfig.me 2>/dev/null || hostname -I | awk '{print $1}'); warn "DOMAIN tu dong: $DOMAIN"; }
[[ -z "$DB_PASS" ]]               && DB_PASS="TrePwd_$(openssl rand -hex 8)"
[[ -z "$ADMIN_PASS" ]]            && ADMIN_PASS="Admin_$(openssl rand -hex 6)"
[[ -z "$TELEGRAM_WEBHOOK_SECRET" ]] && TELEGRAM_WEBHOOK_SECRET="tretrau_wh_$(openssl rand -hex 8)"

echo -e "${BOLD}${GREEN}"
echo "  ████████╗██████╗ ███████╗████████╗██████╗  █████╗ ██╗   ██╗"
echo "     ██╔══╝██╔══██╗██╔════╝╚══██╔══╝██╔══██╗██╔══██╗██║   ██║"
echo "     ██║   ██████╔╝█████╗     ██║   ██████╔╝███████║██║   ██║"
echo "     ██║   ██╔══██╗██╔══╝     ██║   ██╔══██╗██╔══██║██║   ██║"
echo "     ██║   ██║  ██║███████╗   ██║   ██║  ██║██║  ██║╚██████╔╝"
echo "     ╚═╝   ╚═╝  ╚═╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝"
echo -e "${NC}"
echo -e "  TreTrauNetwork v2 — Setup Script"
echo -e "  Domain: ${BOLD}$DOMAIN${NC} | Webroot: ${BOLD}$WEBROOT${NC}"
echo ""
sleep 1

# ── 1. Update ──────────────────────────────────────────────
header "1. Cap nhat he thong"
apt-get update -qq && apt-get upgrade -y -qq
ok "He thong da cap nhat."

# ── 2. Cai goi ─────────────────────────────────────────────
header "2. Cai dat goi can thiet"
if ! apt-cache show php${PHP_VERSION}-fpm &>/dev/null; then
  apt-get install -y -qq software-properties-common
  add-apt-repository -y ppa:ondrej/php
  apt-get update -qq
fi
apt-get install -y -qq \
  nginx mariadb-server mariadb-client \
  php${PHP_VERSION}-fpm php${PHP_VERSION}-mysql php${PHP_VERSION}-mbstring \
  php${PHP_VERSION}-xml php${PHP_VERSION}-gd php${PHP_VERSION}-curl \
  php${PHP_VERSION}-zip php${PHP_VERSION}-intl php${PHP_VERSION}-bcmath \
  php${PHP_VERSION}-opcache \
  python3 python3-pip \
  unzip curl git openssl ufw certbot python3-certbot-nginx
ok "Tat ca goi da cai."

# ── 3. Source code ─────────────────────────────────────────
header "3. Giai nen source code"
ZIP_PATH=$(find "$SCRIPT_DIR" -maxdepth 1 -name "tretrau_v2.zip" 2>/dev/null | head -1)
[[ -z "$ZIP_PATH" ]] && ZIP_PATH=$(find "$SCRIPT_DIR" -maxdepth 1 -name "*.zip" 2>/dev/null | head -1)

if [[ -n "$ZIP_PATH" ]]; then
  info "Tim thay: $ZIP_PATH"
  mkdir -p "$WEBROOT"
  TMP=$(mktemp -d)
  unzip -oq "$ZIP_PATH" -d "$TMP"
  SRC=$(find "$TMP" -maxdepth 3 -name "config.php" | head -1 | xargs dirname 2>/dev/null)
  [[ -z "$SRC" ]] && SRC="$TMP"
  cp -r "$SRC/." "$WEBROOT/"
  rm -rf "$TMP"
  ok "Giai nen xong vao $WEBROOT"
elif [[ -f "$SCRIPT_DIR/config.php" ]]; then
  info "Script o trong thu muc source"
  mkdir -p "$WEBROOT"
  [[ "$SCRIPT_DIR" != "$WEBROOT" ]] && cp -r "$SCRIPT_DIR/." "$WEBROOT/"
  ok "Source tai $WEBROOT"
else
  die "Khong tim thay source. Dat tretrau_v2.zip cung thu muc voi setup.sh"
fi

# ── 4. PHP ─────────────────────────────────────────────────
header "4. Cau hinh PHP ${PHP_VERSION}"
PHP_INI="/etc/php/${PHP_VERSION}/fpm/php.ini"
[[ ! -f "$PHP_INI" ]] && die "Khong tim thay $PHP_INI"
sed -i 's/^display_errors.*/display_errors = Off/'            "$PHP_INI"
sed -i 's/^log_errors.*/log_errors = On/'                    "$PHP_INI"
sed -i 's/^output_buffering.*/output_buffering = On/'        "$PHP_INI"
sed -i 's/^upload_max_filesize.*/upload_max_filesize = 10M/' "$PHP_INI"
sed -i 's/^post_max_size.*/post_max_size = 12M/'             "$PHP_INI"
sed -i 's/^max_execution_time.*/max_execution_time = 60/'    "$PHP_INI"
sed -i 's/^memory_limit.*/memory_limit = 256M/'              "$PHP_INI"
sed -i 's|^;date.timezone.*|date.timezone = Asia/Ho_Chi_Minh|' "$PHP_INI"
grep -q "opcache.enable=1" "$PHP_INI" || cat >> "$PHP_INI" << 'OPC'
opcache.enable=1
opcache.memory_consumption=128
opcache.interned_strings_buffer=8
opcache.max_accelerated_files=4000
opcache.revalidate_freq=2
OPC
systemctl restart php${PHP_VERSION}-fpm
systemctl enable  php${PHP_VERSION}-fpm
ok "PHP ${PHP_VERSION} xong."

# ── 5. MariaDB ─────────────────────────────────────────────
header "5. Cau hinh MariaDB"
systemctl start mariadb && systemctl enable mariadb
mysql -u root << MYSQL
DELETE FROM mysql.user WHERE User='';
DROP DATABASE IF EXISTS test;
DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
DROP USER IF EXISTS '${DB_USER}'@'${DB_HOST}';
CREATE USER '${DB_USER}'@'${DB_HOST}' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'${DB_HOST}';
FLUSH PRIVILEGES;
MYSQL
ok "DB '${DB_NAME}' + user '${DB_USER}' da tao."

# ── 6. .env.tretrau ────────────────────────────────────────
header "6. Tao file .env.tretrau"
cat > "${WEBROOT}/.env.tretrau" << ENV
DB_HOST=${DB_HOST}
DB_NAME=${DB_NAME}
DB_USER=${DB_USER}
DB_PASS=${DB_PASS}
SITE_URL=http://${DOMAIN}
TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}
TELEGRAM_ADMIN_CHAT_ID=${TELEGRAM_ADMIN_CHAT_ID}
TELEGRAM_WEBHOOK_SECRET=${TELEGRAM_WEBHOOK_SECRET}
ENV
chmod 600 "${WEBROOT}/.env.tretrau"
ok ".env.tretrau da tao."

# ── 7. Schema DB ───────────────────────────────────────────
header "7. Khoi tao Database Schema"
php -r "chdir('${WEBROOT}'); require '${WEBROOT}/config.php'; installDatabase(); echo 'OK';" \
  && ok "Schema OK." || warn "Loi schema — co the da ton tai."

ADMIN_HASH=$(php -r "echo password_hash('${ADMIN_PASS}', PASSWORD_DEFAULT);")
mysql -u root "${DB_NAME}" << ADMINSQL
INSERT IGNORE INTO users (username, email, password_hash, role, status)
VALUES ('${ADMIN_USER}', 'admin@${DOMAIN}', '${ADMIN_HASH}', 'admin', 'active');
ADMINSQL
ok "Admin account tao xong."

# ── 8. Quyen ───────────────────────────────────────────────
header "8. Phan quyen thu muc"
chown -R www-data:www-data "$WEBROOT"
find "$WEBROOT" -type d -exec chmod 755 {} \;
find "$WEBROOT" -type f -exec chmod 644 {} \;
mkdir -p "${WEBROOT}/uploads/avatars" "${WEBROOT}/logs"
chmod -R 775 "${WEBROOT}/uploads" "${WEBROOT}/logs"
chown -R www-data:www-data "${WEBROOT}/uploads" "${WEBROOT}/logs"
if [[ -f "${WEBROOT}/uploads/.htaccess" ]]; then
  find "${WEBROOT}/uploads" -mindepth 1 -type d | while read -r d; do
    [[ ! -f "$d/.htaccess" ]] && cp "${WEBROOT}/uploads/.htaccess" "$d/.htaccess"
  done
fi
ok "Phan quyen xong."

# ── 9. Nginx ───────────────────────────────────────────────
header "9. Cau hinh Nginx"
cat > "/etc/nginx/sites-available/tretrau" << NGINX
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN} www.${DOMAIN};
    root ${WEBROOT};
    index index.php;
    charset utf-8;
    client_max_body_size 12M;
    server_tokens off;
    access_log /var/log/nginx/tretrau_access.log;
    error_log  /var/log/nginx/tretrau_error.log warn;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    location ~ /\. { deny all; return 404; }
    location ~* \.(sql|log|env|sh|py|rb|bak|installed|md)$ { deny all; return 404; }
    location ~* ^/uploads/.*\.(php|php3|php4|php5|phtml|phar)$ { deny all; return 403; }
    location ^~ /includes/ { deny all; return 403; }
    location ~* ^/admin/(check_admin_token|verify_token)\.php$ { deny all; return 403; }
    location ~ \.php$ {
        try_files \$uri =404;
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/run/php/php${PHP_VERSION}-fpm.sock;
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 60;
        fastcgi_buffers 16 16k;
        fastcgi_buffer_size 32k;
    }
    location ~* \.(jpg|jpeg|png|gif|ico|css|js|webp|svg|woff|woff2|ttf|eot)$ {
        expires 7d;
        add_header Cache-Control "public, immutable";
        access_log off;
    }
    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }
    gzip on;
    gzip_vary on;
    gzip_types text/plain text/css application/json application/javascript text/javascript image/svg+xml;
    gzip_min_length 256;
}
NGINX
ln -sf /etc/nginx/sites-available/tretrau /etc/nginx/sites-enabled/tretrau
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx && systemctl enable nginx
ok "Nginx da cau hinh."

# ── 10. Firewall ───────────────────────────────────────────
header "10. Firewall (UFW)"
ufw --force reset    > /dev/null 2>&1
ufw default deny incoming  > /dev/null
ufw default allow outgoing > /dev/null
ufw allow ssh        > /dev/null
ufw allow 'Nginx Full' > /dev/null
ufw --force enable   > /dev/null
ok "Firewall bat."

# ── 11. SSL ────────────────────────────────────────────────
header "11. SSL (Let's Encrypt)"
IS_IP=false; [[ "$DOMAIN" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] && IS_IP=true
if [[ "$ENABLE_SSL" == true && "$IS_IP" == false && "$DOMAIN" != "localhost" ]]; then
  certbot --nginx -d "$DOMAIN" --non-interactive --agree-tos \
    --email "admin@${DOMAIN}" --redirect 2>&1 \
    && { ok "SSL da cai."; sed -i "s|SITE_URL=http://|SITE_URL=https://|" "${WEBROOT}/.env.tretrau"; systemctl enable certbot.timer 2>/dev/null || true; } \
    || warn "Khong lay duoc SSL — DNS chua tro? Chay sau: certbot --nginx -d $DOMAIN"
else
  warn "Bo qua SSL (IP/localhost). Sau khi DNS tro: certbot --nginx -d $DOMAIN"
fi

# ── 12. Telegram Bot service ───────────────────────────────
header "12. Telegram Bot (systemd)"
if [[ -f "${WEBROOT}/start.py" ]]; then
  pip3 install -q requests 2>/dev/null || true
  cat > /etc/systemd/system/tretrau-bot.service << SERVICE
[Unit]
Description=TreTrau Telegram Bot
After=network.target mariadb.service
[Service]
Type=simple
User=www-data
WorkingDirectory=${WEBROOT}
ExecStart=/usr/bin/python3 ${WEBROOT}/start.py
Restart=always
RestartSec=10
Environment=PYTHONUNBUFFERED=1
[Install]
WantedBy=multi-user.target
SERVICE
  systemctl daemon-reload
  if [[ -n "$TELEGRAM_BOT_TOKEN" ]]; then
    systemctl enable tretrau-bot
    systemctl start  tretrau-bot 2>/dev/null \
      && ok "Bot da khoi dong." \
      || warn "Bot chua start — kiem tra: journalctl -u tretrau-bot -n 20"
  else
    warn "TELEGRAM_BOT_TOKEN trong — bot chua chay. Dien token vao .env.tretrau roi: systemctl start tretrau-bot"
  fi
else
  warn "Khong tim thay start.py"
fi

# ── 13. Don dep ────────────────────────────────────────────
header "13. Don dep file nhay cam"
for f in setup.sh setup.php debug_product.php fix_avatars.php clear_cache.php backup.php; do
  [[ -f "${WEBROOT}/$f" ]] && rm -f "${WEBROOT}/$f" && info "Xoa: $f"
done
rm -f "${WEBROOT}/.installed"
ok "Don dep xong."

# ── 14. Kiem tra ───────────────────────────────────────────
header "14. Kiem tra cuoi"
check() { systemctl is-active "$1" &>/dev/null && ok "$1: RUNNING" || warn "$1: NOT running"; }
check php${PHP_VERSION}-fpm
check nginx
check mariadb
mysql -u "$DB_USER" -p"$DB_PASS" -h "$DB_HOST" "$DB_NAME" -e "SHOW TABLES;" &>/dev/null \
  && ok "Database: ket noi OK" || warn "Database: loi ket noi"
HTTP=$(curl -s -o /dev/null -w "%{http_code}" "http://localhost/" 2>/dev/null || echo 0)
[[ "$HTTP" == "200" || "$HTTP" == "302" ]] && ok "Web: HTTP $HTTP" || warn "Web: HTTP $HTTP"

# ── Tong ket ───────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${GREEN}║        SETUP HOAN TAT — TreTrauNetwork v2               ║${NC}"
echo -e "${BOLD}${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BOLD}Website:${NC}      http://${DOMAIN}"
echo -e "  ${BOLD}Admin:${NC}        http://${DOMAIN}/admin/admin.php"
echo -e "  ${BOLD}Webroot:${NC}      ${WEBROOT}"
echo ""
echo -e "  ${BOLD}${YELLOW}── DANG NHAP ADMIN ──────────────────────────────────${NC}"
echo -e "  Username:    ${BOLD}${ADMIN_USER}${NC}"
echo -e "  Password:    ${BOLD}${RED}${ADMIN_PASS}${NC}"
echo ""
echo -e "  ${BOLD}${YELLOW}── DATABASE ─────────────────────────────────────────${NC}"
echo -e "  DB Name:     ${DB_NAME}"
echo -e "  DB User:     ${DB_USER}"
echo -e "  DB Pass:     ${BOLD}${DB_PASS}${NC}"
echo ""
echo -e "  ${BOLD}${RED}LUU Y:${NC}"
echo -e "  • Luu mat khau admin o tren ngay bay gio!"
echo -e "  • Doi mat khau sau lan dang nhap dau"
[[ -z "$TELEGRAM_BOT_TOKEN" ]] && echo -e "  • Dien TELEGRAM_BOT_TOKEN vao .env.tretrau -> systemctl start tretrau-bot"
echo -e "  • Log: ${LOG_FILE}"
echo ""
