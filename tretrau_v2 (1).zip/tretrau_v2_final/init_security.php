<?php
/**
 * init_security.php — Run ONCE after deployment
 * 
 * This script:
 * 1. Initializes file integrity hashes
 * 2. Creates .env.tretrau from example if not exists
 * 3. Sets proper file permissions
 * 4. Creates MySQL user with limited privileges (optional)
 * 
 * Usage: php init_security.php
 * Then DELETE this file!
 */

if (php_sapi_name() !== 'cli') {
    die("This script must be run from the command line.\n");
}

echo "=== TreTrau Security Initialization ===\n\n";

// 1. Initialize file integrity hashes
require_once __DIR__ . '/security.php';
TreTrauFirewall::initHashes();
echo "[OK] File integrity hashes initialized\n";

// 2. Create .env.tretrau from example
if (!file_exists(__DIR__ . '/.env.tretrau') && file_exists(__DIR__ . '/.env.tretrau.example')) {
    copy(__DIR__ . '/.env.tretrau.example', __DIR__ . '/.env.tretrau');
    echo "[OK] .env.tretrau created from example — EDIT IT WITH REAL CREDENTIALS!\n";
} else {
    echo "[SKIP] .env.tretrau already exists\n";
}

// 3. Set file permissions
$permChanges = [
    'config.php' => 0640,
    'security.php' => 0640,
    '.htaccess' => 0644,
    '.user.ini' => 0640,
    '.env.tretrau' => 0600,
];

foreach ($permChanges as $file => $perm) {
    $path = __DIR__ . '/' . $file;
    if (file_exists($path)) {
        chmod($path, $perm);
        echo "[OK] Set " . decoct($perm) . " on $file\n";
    }
}

// Set directory permissions
$dirs = ['logs', 'uploads', 'backups', 'bot_queue'];
foreach ($dirs as $dir) {
    $path = __DIR__ . '/' . $dir;
    if (is_dir($path)) {
        chmod($path, 0750);
        echo "[OK] Set 750 on $dir/\n";
    }
}

// 4. Create limited MySQL user (display instructions)
echo "\n=== IMPORTANT: Create a limited MySQL user ===\n";
echo "Run these SQL commands to create a restricted database user:\n\n";
echo "  CREATE USER 'tretrau_user'@'localhost' IDENTIFIED BY 'STRONG_PASSWORD_HERE';\n";
echo "  GRANT SELECT, INSERT, UPDATE, DELETE ON marketplace_db.* TO 'tretrau_user'@'localhost';\n";
echo "  REVOKE DROP, ALTER, CREATE, INDEX, LOCK TABLES, FILE ON *.* FROM 'tretrau_user'@'localhost';\n";
echo "  FLUSH PRIVILEGES;\n\n";
echo "Then update .env.tretrau with the new credentials.\n";
echo "This prevents attackers from DROP TABLE or dumping other databases even with SQL injection.\n";

echo "\n=== DONE! DELETE THIS FILE: rm init_security.php ===\n";
