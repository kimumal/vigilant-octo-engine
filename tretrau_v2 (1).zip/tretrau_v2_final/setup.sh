#!/bin/bash
# =============================================================
#  SETUP SCRIPT — TreTrauNetwork v2
#  Ubuntu 20.04 / 22.04 / 24.04 | Nginx + PHP 8.2 + MariaDB
#  Usage: sudo bash setup.sh
# =============================================================

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

info()   { echo -e "${CYAN}[INFO]${NC} $1"; }
ok()     { echo -e "${GREEN}[ OK ]${NC} $1"; }
warn()   { echo -e "${YELLOW}[WARN]${NC} $1"; }
die()    { echo -e "${RED}[ERR]${NC}  $1"; exit 1; }
banner() { echo -e "\n${BOLD}${CYAN}══════════════════════════════════════${NC}"; \
           echo -e "${BOLD}  $1${NC}"; \
           echo -e "${BOLD}${CYAN}══════════════════════════════════════${NC}"; }

[[ $EUID -ne 0 ]] && die "Cần chạy với quyền root: sudo bash $0"

# =============================================================
#  CONFIG — chỉnh tại đây
# =============================================================
DOMAIN="tretraunetwork.space"
WEBROOT="/var/www/tretrau"
PHP_VERSION="8.2"

DB_HOST="127.0.0.1"
DB_NAME="marketplace_db"
DB_USER="tretrau_user"
DB_PASS="TreTrau@$(openssl rand -hex 6)"

ADMIN_USER="phuvanduc"
ADMIN_EMAIL="admin@tretraunetwork.space"
ADMIN_PASS="Admin@$(openssl rand -hex 6)"

TELEGRAM_BOT_TOKEN="8336938728:AAH9QDiLrpb-OLtTj9zWB9ouWKnRV4-UHx4"
TELEGRAM_ADMIN_CHAT_ID="7567975053"
TELEGRAM_WEBHOOK_SECRET="tretrau_webhook_2025_secret_key"
# =============================================================

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
LOG="/tmp/tretrau_setup_$(date +%Y%m%d_%H%M%S).log"
exec > >(tee -a "$LOG") 2>&1

echo -e "${BOLD}${CYAN}"
echo "  ___           _____              _   _      _    "
echo " |_ _|_ _ ___  |_   _| _ ___ __ _| | | |_ _| |_  "
echo "  | || '_/ -_)   | || '_/ _\` | || | |_| ' \\  _/ "
echo " |___|_| \___|   |_||_| \\__,_|\\_,_|\\__/_||_\\__| "
echo -e "${NC}"
echo -e "  TreTrauNetwork v2 — Auto Setup"
echo -e "  Log: $LOG\n"

# =============================================================
banner "1. Update hệ thống"
# =============================================================
apt-get update -qq
apt-get upgrade -y -qq 2>/dev/null || true
ok "Hệ thống updated"

# =============================================================
banner "2. Cài gói"
# =============================================================
info "nginx + PHP${PHP_VERSION} + MariaDB + python3..."
apt-get install -y -qq \
    nginx \
    mariadb-server mariadb-client \
    php${PHP_VERSION}-fpm php${PHP_VERSION}-mysql \
    php${PHP_VERSION}-mbstring php${PHP_VERSION}-xml \
    php${PHP_VERSION}-gd php${PHP_VERSION}-curl \
    php${PHP_VERSION}-zip php${PHP_VERSION}-intl \
    php${PHP_VERSION}-bcmath php${PHP_VERSION}-opcache \
    python3 python3-pip \
    unzip curl git openssl ufw 2>/dev/null
ok "Tất cả gói đã cài"

# =============================================================
banner "3. Giải nén source code"
# =============================================================
ZIP="${SCRIPT_DIR}/tretrau_v2.zip"
[[ ! -f "$ZIP" ]] && die "Không tìm thấy tretrau_v2.zip cạnh setup.sh"

info "Giải nén vào ${WEBROOT}..."
rm -rf /tmp/_ttext
mkdir -p /tmp/_ttext "$WEBROOT"
unzip -oq "$ZIP" -d /tmp/_ttext

SRC=$(find /tmp/_ttext -name "config.php" | head -1 | xargs dirname)
[[ -z "$SRC" ]] && SRC=$(find /tmp/_ttext -maxdepth 3 -type d | tail -1)

cp -rf "${SRC}/." "$WEBROOT/"
rm -rf /tmp/_ttext
ok "Source code → ${WEBROOT}"

# =============================================================
banner "4. PHP ${PHP_VERSION} config"
# =============================================================
PHP_INI=$(find /etc/php -name "php.ini" 2>/dev/null | grep fpm | head -1)
if [[ -n "$PHP_INI" ]]; then
    sed -i 's/^display_errors.*/display_errors = Off/' "$PHP_INI"
    sed -i 's/^log_errors.*/log_errors = On/' "$PHP_INI"
    sed -i 's/^upload_max_filesize.*/upload_max_filesize = 10M/' "$PHP_INI"
    sed -i 's/^post_max_size.*/post_max_size = 12M/' "$PHP_INI"
    sed -i 's/^max_execution_time.*/max_execution_time = 60/' "$PHP_INI"
    sed -i 's/^memory_limit.*/memory_limit = 256M/' "$PHP_INI"
    sed -i "s|^;date.timezone.*|date.timezone = Asia/Ho_Chi_Minh|" "$PHP_INI"
    grep -q "opcache.enable=1" "$PHP_INI" || cat >> "$PHP_INI" << 'OPC'
[opcache]
opcache.enable=1
opcache.memory_consumption=128
opcache.max_accelerated_files=4000
opcache.revalidate_freq=2
OPC
fi
systemctl restart php${PHP_VERSION}-fpm 2>/dev/null || systemctl restart php-fpm 2>/dev/null || true
systemctl enable php${PHP_VERSION}-fpm 2>/dev/null || true
ok "PHP-FPM configured"

# =============================================================
banner "5. MariaDB — Database"
# =============================================================
systemctl start mariadb; systemctl enable mariadb

mysql -u root << MYSQL
DELETE FROM mysql.user WHERE User='';
DROP DATABASE IF EXISTS test;
DELETE FROM mysql.db WHERE Db='test' OR Db='test\\_%';
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
DROP USER IF EXISTS '${DB_USER}'@'${DB_HOST}';
CREATE USER '${DB_USER}'@'${DB_HOST}' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'${DB_HOST}';
FLUSH PRIVILEGES;
MYSQL
ok "DB '${DB_NAME}' + user '${DB_USER}' created"

# =============================================================
banner "6. Ghi config"
# =============================================================
CONFIG="${WEBROOT}/config.php"

# Patch config.php trực tiếp
sed -i "s|define('DB_HOST'.*|define('DB_HOST', '${DB_HOST}');|" "$CONFIG"
sed -i "s|define('DB_NAME'.*|define('DB_NAME', '${DB_NAME}');|" "$CONFIG"
sed -i "s|define('DB_USER'.*|define('DB_USER', '${DB_USER}');|" "$CONFIG"
sed -i "s|define('DB_PASS'.*|define('DB_PASS', '${DB_PASS}');|" "$CONFIG"
sed -i "s|define('SITE_URL'.*|define('SITE_URL', 'https://${DOMAIN}');|" "$CONFIG"
sed -i "s|define('TELEGRAM_BOT_TOKEN'.*|define('TELEGRAM_BOT_TOKEN', '${TELEGRAM_BOT_TOKEN}');|" "$CONFIG"
sed -i "s|define('TELEGRAM_ADMIN_CHAT_ID'.*|define('TELEGRAM_ADMIN_CHAT_ID', '${TELEGRAM_ADMIN_CHAT_ID}');|" "$CONFIG"
sed -i "s|define('TELEGRAM_WEBHOOK_SECRET'.*|define('TELEGRAM_WEBHOOK_SECRET', '${TELEGRAM_WEBHOOK_SECRET}');|" "$CONFIG"

# Backup .env
cat > "${WEBROOT}/.env.tretrau" << ENV
DB_HOST=${DB_HOST}
DB_NAME=${DB_NAME}
DB_USER=${DB_USER}
DB_PASS=${DB_PASS}
SITE_URL=https://${DOMAIN}
TELEGRAM_BOT_TOKEN=${TELEGRAM_BOT_TOKEN}
TELEGRAM_ADMIN_CHAT_ID=${TELEGRAM_ADMIN_CHAT_ID}
TELEGRAM_WEBHOOK_SECRET=${TELEGRAM_WEBHOOK_SECRET}
ENV
ok "config.php + .env.tretrau ghi xong"

# =============================================================
banner "7. Init Database Schema"
# =============================================================
info "Chạy installDatabase()..."
php -r "
\$_ENV['DB_HOST']='${DB_HOST}';
\$_ENV['DB_NAME']='${DB_NAME}';
\$_ENV['DB_USER']='${DB_USER}';
\$_ENV['DB_PASS']='${DB_PASS}';
\$_ENV['SITE_URL']='https://${DOMAIN}';
\$_ENV['TELEGRAM_BOT_TOKEN']='${TELEGRAM_BOT_TOKEN}';
\$_ENV['TELEGRAM_ADMIN_CHAT_ID']='${TELEGRAM_ADMIN_CHAT_ID}';
\$_ENV['TELEGRAM_WEBHOOK_SECRET']='${TELEGRAM_WEBHOOK_SECRET}';
chdir('${WEBROOT}');
require '${WEBROOT}/config.php';
installDatabase();
echo 'Schema OK';
" 2>&1 | grep -v "^$" || warn "Kiểm tra DB schema nếu có lỗi"

# Tạo admin
info "Tạo admin '${ADMIN_USER}'..."
HASH=$(php -r "echo password_hash('${ADMIN_PASS}', PASSWORD_DEFAULT);")
mysql -u root "${DB_NAME}" << ADM
INSERT IGNORE INTO users (username, email, password_hash, role, status)
VALUES ('${ADMIN_USER}', '${ADMIN_EMAIL}', '${HASH}', 'admin', 'active');
ADM
ok "Admin account created"

# =============================================================
banner "8. Phân quyền"
# =============================================================
chown -R www-data:www-data "$WEBROOT"
find "$WEBROOT" -type d -exec chmod 755 {} \;
find "$WEBROOT" -type f -exec chmod 644 {} \;
chmod -R 775 "${WEBROOT}/uploads"
chmod 600 "$CONFIG" "${WEBROOT}/.env.tretrau"
chown www-data:www-data "$CONFIG" "${WEBROOT}/.env.tretrau"
mkdir -p "${WEBROOT}/logs" && chown www-data:www-data "${WEBROOT}/logs" && chmod 775 "${WEBROOT}/logs"

# Copy .htaccess vào subdirs uploads
find "${WEBROOT}/uploads" -mindepth 1 -type d | while read -r d; do
    [[ ! -f "${d}/.htaccess" ]] && cp "${WEBROOT}/uploads/.htaccess" "${d}/.htaccess" 2>/dev/null || true
done
ok "Phân quyền xong"

# =============================================================
banner "9. Nginx"
# =============================================================
SOCK=$(find /run/php -name "php*-fpm.sock" 2>/dev/null | head -1)
[[ -z "$SOCK" ]] && SOCK="/run/php/php${PHP_VERSION}-fpm.sock"

cat > /etc/nginx/sites-available/tretrau << NGINX
server {
    listen 80;
    listen [::]:80;
    server_name ${DOMAIN} www.${DOMAIN};
    root ${WEBROOT};
    index index.php index.html;
    charset utf-8;
    client_max_body_size 12M;
    access_log /var/log/nginx/tretrau_access.log;
    error_log  /var/log/nginx/tretrau_error.log;
    server_tokens off;

    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;

    location ~ /\. { deny all; return 404; }
    location ~* \.(sql|log|env|sh|py|rb|bak|installed|md)$ { deny all; return 404; }
    location ~* ^/uploads/.*\.php$ { deny all; return 403; }
    location ^~ /includes/ { deny all; return 403; }
    location ~* ^/admin/(check_admin_token|verify_token)\.php$ { deny all; return 403; }

    location ~* \.(jpg|jpeg|png|gif|ico|css|js|webp|svg|woff|woff2)$ {
        expires 7d;
        add_header Cache-Control "public, immutable";
        try_files \$uri =404;
    }

    location ~ \.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:${SOCK};
        fastcgi_param SCRIPT_FILENAME \$document_root\$fastcgi_script_name;
        include fastcgi_params;
        fastcgi_read_timeout 60;
        fastcgi_hide_header X-Powered-By;
    }

    location / {
        try_files \$uri \$uri/ /index.php?\$query_string;
    }

    gzip on;
    gzip_vary on;
    gzip_types text/plain text/css application/json application/javascript text/xml image/svg+xml;
    gzip_min_length 256;
}
NGINX

ln -sf /etc/nginx/sites-available/tretrau /etc/nginx/sites-enabled/tretrau
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl restart nginx && systemctl enable nginx
ok "Nginx configured"

# =============================================================
banner "10. Firewall"
# =============================================================
ufw --force reset > /dev/null 2>&1
ufw default deny incoming > /dev/null
ufw default allow outgoing > /dev/null
ufw allow ssh > /dev/null
ufw allow 'Nginx Full' > /dev/null
ufw --force enable > /dev/null
ok "Firewall: SSH + HTTP/HTTPS"

# =============================================================
banner "11. SSL (Let's Encrypt)"
# =============================================================
if [[ "$DOMAIN" != "localhost" && ! "$DOMAIN" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    apt-get install -y -qq certbot python3-certbot-nginx
    certbot --nginx -d "$DOMAIN" -d "www.${DOMAIN}" \
        --non-interactive --agree-tos --email "admin@${DOMAIN}" \
        --redirect 2>&1 || warn "SSL thất bại — DNS chưa trỏ? Chạy certbot sau."
    ok "SSL configured"
else
    warn "Bỏ qua SSL (domain là IP/localhost)"
    warn "Sau khi có domain: certbot --nginx -d YOUR_DOMAIN"
fi

# =============================================================
banner "12. Telegram Bot service"
# =============================================================
if [[ -f "${WEBROOT}/start.py" ]]; then
    pip3 install requests --quiet 2>/dev/null || true
    cat > /etc/systemd/system/tretrau-bot.service << SVC
[Unit]
Description=TreTrau Telegram Bot
After=network.target mariadb.service

[Service]
Type=simple
User=www-data
WorkingDirectory=${WEBROOT}
ExecStart=/usr/bin/python3 ${WEBROOT}/start.py
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
SVC
    systemctl daemon-reload
    systemctl enable tretrau-bot
    systemctl start tretrau-bot 2>/dev/null || warn "Bot chưa khởi động — kiểm tra start.py"
    ok "Telegram bot service created"
fi

# =============================================================
banner "13. Xóa file debug/setup"
# =============================================================
rm -f "${WEBROOT}/setup.php" "${WEBROOT}/debug_product.php" \
      "${WEBROOT}/backup.php" "${WEBROOT}/.installed" \
      "${WEBROOT}/fix_avatars.php" "${WEBROOT}/clear_cache.php"
ok "Debug files removed"

# =============================================================
banner "14. Kiểm tra"
# =============================================================
PHP_OK=$(systemctl is-active php${PHP_VERSION}-fpm 2>/dev/null && echo "✓ RUNNING" || echo "✗ STOPPED")
NGX_OK=$(systemctl is-active nginx 2>/dev/null && echo "✓ RUNNING" || echo "✗ STOPPED")
DB_OK=$(systemctl is-active mariadb 2>/dev/null && echo "✓ RUNNING" || echo "✗ STOPPED")
DB_CONN=$(mysql -u "$DB_USER" -p"$DB_PASS" -h "$DB_HOST" "$DB_NAME" -e "SELECT COUNT(*) FROM users;" 2>/dev/null | tail -1 || echo "FAIL")
echo ""
echo -e "  PHP-FPM  : $PHP_OK"
echo -e "  Nginx    : $NGX_OK"
echo -e "  MariaDB  : $DB_OK"
echo -e "  DB users : $DB_CONN"

# =============================================================
echo ""
echo -e "${BOLD}${GREEN}╔════════════════════════════════════════════════════╗"
echo -e "║     ✅ SETUP HOÀN TẤT — TreTrauNetwork v2          ║"
echo -e "╚════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "  ${BOLD}🌐 Website :${NC}  http://${DOMAIN}"
echo -e "  ${BOLD}🔑 Admin   :${NC}  http://${DOMAIN}/admin/admin.php"
echo ""
echo -e "  ${BOLD}${YELLOW}─── LOGIN ADMIN ─────────────────────────────────${NC}"
echo -e "  Username : ${BOLD}${ADMIN_USER}${NC}"
echo -e "  Password : ${BOLD}${ADMIN_PASS}${NC}"
echo ""
echo -e "  ${BOLD}${YELLOW}─── DATABASE ────────────────────────────────────${NC}"
echo -e "  DB   : ${DB_NAME}   User: ${DB_USER}"
echo -e "  Pass : ${DB_PASS}"
echo ""
echo -e "  ${BOLD}${RED}⚠  Đổi mật khẩu admin ngay sau khi login!${NC}"
echo -e "  📋 Full log: ${LOG}"
echo ""
