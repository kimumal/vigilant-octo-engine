<?php
/**
 * DEBUG PRODUCT — Chạy script này để tìm lỗi "Product not found"
 * 
 * Cách dùng: https://domain.com/debug_product.php?id=X
 * (X = product ID, lấy từ URL sản phẩm)
 * 
 * ⚠️ XÓA FILE NÀY SAU KHI DEBUG XONG!
 */

// Bypass WAF for this debug script
$_skipWAF = true;

// Load config without WAF
ini_set("display_errors", "1");
error_reporting(E_ALL);

// Direct database connection
$envFile = dirname(__DIR__) . '/.env.tretrau';
if (!file_exists($envFile)) $envFile = __DIR__ . '/.env.tretrau';
$env = [];
if (file_exists($envFile)) {
    foreach (file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if (str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$k, $v] = explode('=', $line, 2);
        $env[trim($k)] = trim($v, " \t\n\r\"'");
    }
}

$dbHost = $env['DB_HOST'] ?? '127.0.0.1';
$dbName = $env['DB_NAME'] ?? 'marketplace_db';
$dbUser = $env['DB_USER'] ?? 'root';
$dbPass = $env['DB_PASS'] ?? '';

header('Content-Type: text/plain; charset=utf-8');
echo "=== DEBUG PRODUCT PAGE ===\n";
echo "Time: " . date('Y-m-d H:i:s') . "\n";
echo "PHP Version: " . PHP_VERSION . "\n\n";

// 1. Check product.php file version
echo "--- 1. FILE CHECK ---\n";
$productFile = __DIR__ . '/pages/product.php';
if (file_exists($productFile)) {
    $content = file_get_contents($productFile);
    $hasStatusFilter = str_contains($content, "status='active'") && str_contains($content, "WHERE p.id=? AND");
    $hasNewQuery = str_contains($content, "SELECT p.*, u.username, u.avatar, u.bio, u.role, u.id as seller_id FROM products p JOIN users u ON u.id=p.user_id WHERE p.id=?");
    
    echo "File exists: YES\n";
    echo "File size: " . filesize($productFile) . " bytes\n";
    echo "Last modified: " . date('Y-m-d H:i:s', filemtime($productFile)) . "\n";
    echo "Has OLD status filter (BUG): " . ($hasStatusFilter ? "❌ YES — THIS IS THE PROBLEM!" : "✅ NO — Good") . "\n";
    echo "Has NEW query (FIXED): " . ($hasNewQuery ? "✅ YES — Good" : "❌ NO — File may be wrong") . "\n";
    
    // Show actual query line
    preg_match('/\$stmt\s*=\s*\$db->prepare\("(SELECT.*?WHERE.*?)"\)/', $content, $m);
    echo "Actual query: " . ($m[1] ?? 'NOT FOUND') . "\n";
    
    // Check opcache
    if (function_exists('opcache_get_status')) {
        $status = opcache_get_status(true);
        if (isset($status['scripts'][$productFile])) {
            $cached = $status['scripts'][$productFile];
            echo "\n⚠️  OPCACHE INFO:\n";
            echo "  Cached timestamp: " . date('Y-m-d H:i:s', $cached['timestamp']) . "\n";
            echo "  File timestamp: " . date('Y-m-d H:i:s', filemtime($productFile)) . "\n";
            if ($cached['timestamp'] < filemtime($productFile)) {
                echo "  ❌ OPCACHE IS STALE! Serving old version!\n";
                echo "  FIX: Run opcache_invalidate() or restart PHP-FPM\n";
            } else {
                echo "  ✅ Cache is up to date\n";
            }
        } else {
            echo "OPcache: File not cached\n";
        }
        echo "OPcache enabled: " . ($status['opcache_enabled'] ? 'YES' : 'NO') . "\n";
    } else {
        echo "OPcache: not available\n";
    }
} else {
    echo "File exists: ❌ NO! — pages/product.php MISSING!\n";
}

// 2. Database check
echo "\n--- 2. DATABASE CHECK ---\n";
try {
    $pdo = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4", $dbUser, $dbPass, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    echo "Database connection: ✅ OK\n";
    
    // Show all products
    $allProducts = $pdo->query("SELECT p.id, p.title, p.status, p.user_id, u.username, u.id as uid FROM products p LEFT JOIN users u ON u.id=p.user_id ORDER BY p.id")->fetchAll();
    echo "Total products: " . count($allProducts) . "\n\n";
    
    echo "Products in database:\n";
    foreach ($allProducts as $p) {
        $joinOK = $p['uid'] ? '✅' : '❌ USER MISSING';
        echo "  ID={$p['id']} | status={$p['status']} | title=\"{$p['title']}\" | user_id={$p['user_id']} ({$p['username']}) | JOIN={$joinOK}\n";
    }
    
    // Test specific product if ID given
    $testId = (int)($_GET['id'] ?? 0);
    if ($testId) {
        echo "\n--- 3. TESTING PRODUCT #{$testId} ---\n";
        
        // Test exact same query as product.php
        $stmt = $pdo->prepare("SELECT p.*, u.username, u.avatar, u.bio, u.role, u.id as seller_id FROM products p JOIN users u ON u.id=p.user_id WHERE p.id=?");
        $stmt->execute([$testId]);
        $product = $stmt->fetch();
        
        if ($product) {
            echo "Query result: ✅ FOUND\n";
            echo "  Status: {$product['status']}\n";
            echo "  Title: {$product['title']}\n";
            echo "  Seller: {$product['username']} (ID={$product['seller_id']})\n";
            echo "  Image: {$product['image']}\n";
            
            if ($product['status'] === 'active') {
                echo "\n✅ Product is ACTIVE — should be viewable by everyone!\n";
                echo "If still showing 'not found', the issue is:\n";
                echo "  1. product.php file is OLD (has status filter) → re-upload\n";
                echo "  2. PHP opcache → run: php -r \"opcache_reset();\"\n";
                echo "  3. Browser cache → hard refresh (Ctrl+Shift+R)\n";
            } else {
                echo "\n⚠️  Product is NOT active (status={$product['status']})\n";
                echo "Only owner/admin can view.\n";
            }
        } else {
            echo "Query result: ❌ NOT FOUND\n";
            
            // Debug further — check if product exists without JOIN
            $stmt2 = $pdo->prepare("SELECT * FROM products WHERE id=?");
            $stmt2->execute([$testId]);
            $raw = $stmt2->fetch();
            
            if ($raw) {
                echo "\n  Product EXISTS in products table but JOIN FAILED!\n";
                echo "  Product user_id: {$raw['user_id']}\n";
                
                $stmt3 = $pdo->prepare("SELECT id, username FROM users WHERE id=?");
                $stmt3->execute([$raw['user_id']]);
                $seller = $stmt3->fetch();
                
                if ($seller) {
                    echo "  User EXISTS: id={$seller['id']} name={$seller['username']}\n";
                    echo "  ❌ This shouldn't fail... check data types?\n";
                } else {
                    echo "  ❌ User NOT FOUND! user_id={$raw['user_id']} doesn't exist in users table!\n";
                    echo "  FIX: Either delete orphan product or restore user.\n";
                }
            } else {
                echo "  Product ID={$testId} does not exist in database at all.\n";
            }
        }
    } else {
        echo "\n💡 To test a specific product, add ?id=X to the URL\n";
        echo "   Example: debug_product.php?id=3\n";
    }
    
} catch (PDOException $e) {
    echo "Database error: ❌ " . $e->getMessage() . "\n";
}

// 4. WAF check
echo "\n--- 4. WAF CHECK ---\n";
$secFile = __DIR__ . '/security.php';
if (file_exists($secFile)) {
    echo "security.php: exists\n";
    $logFile = __DIR__ . '/logs/security.log';
    if (file_exists($logFile)) {
        $logs = file($logFile);
        $recent = array_slice($logs, -10);
        echo "Recent WAF blocks (last 10):\n";
        foreach ($recent as $l) echo "  " . trim($l) . "\n";
    } else {
        echo "WAF log: empty (no blocks recorded)\n";
    }
    
    $blockFile = __DIR__ . '/logs/blocked_ips.json';
    if (file_exists($blockFile)) {
        $blocked = json_decode(file_get_contents($blockFile), true) ?: [];
        if ($blocked) {
            echo "\nBlocked IPs:\n";
            foreach ($blocked as $ip => $info) {
                echo "  {$ip} — reason: {$info['reason']} | time: " . date('Y-m-d H:i:s', $info['time']) . "\n";
            }
            echo "\n⚠️  If your IP is blocked, DELETE the file: rm logs/blocked_ips.json\n";
        } else {
            echo "Blocked IPs: none\n";
        }
    }
} else {
    echo "security.php: not found\n";
}

// 5. Clear opcache
echo "\n--- 5. AUTO-FIX: CLEAR OPCACHE ---\n";
if (function_exists('opcache_invalidate')) {
    opcache_invalidate($productFile, true);
    echo "opcache_invalidate(product.php): ✅ done\n";
}
if (function_exists('opcache_reset')) {
    opcache_reset();
    echo "opcache_reset(): ✅ done — all PHP cache cleared\n";
} else {
    echo "opcache_reset: not available\n";
}

echo "\n=== DONE ===\n";
echo "⚠️  XÓA FILE NÀY SAU KHI DEBUG: rm debug_product.php\n";
