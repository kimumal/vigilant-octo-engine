<?php
$db = getDB();
$search   = sanitizeInput($_GET['search'] ?? '');
$category = sanitizeInput($_GET['category'] ?? '');
$page_n   = max(1, (int)($_GET['p'] ?? 1));
$limit    = 12;
$offset   = ($page_n - 1) * $limit;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['hide_product']) && $user) {
    $hideId = (int)$_POST['hide_product'];
    $db->prepare("UPDATE products SET user_hidden=1 WHERE id=? AND user_id=? AND status IN ('pending','rejected','banned')")->execute([$hideId, $user['id']]);
    header('Location: ' . $_SERVER['REQUEST_URI']); exit;
}

$where  = "WHERE p.status='active'";
$params = [];
if ($category) { $where .= " AND p.category=?"; $params[] = $category; }
if ($search)   { $where .= " AND (p.title LIKE ? OR p.description LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }

$myProducts = [];
if ($user) {
    $myStmt = $db->prepare("SELECT p.*, u.username, u.avatar FROM products p JOIN users u ON u.id=p.user_id WHERE p.user_id=? AND p.status IN ('pending','rejected','banned') AND p.user_hidden=0 ORDER BY p.created_at DESC");
    $myStmt->execute([$user['id']]);
    $myProducts = $myStmt->fetchAll();
}

$stmt = $db->prepare("SELECT p.*, u.username, u.avatar FROM products p JOIN users u ON u.id=p.user_id $where ORDER BY p.created_at DESC LIMIT $limit OFFSET $offset");
$stmt->execute($params);
$products = $stmt->fetchAll();

$totalStmt = $db->prepare("SELECT COUNT(*) FROM products p $where");
$totalStmt->execute($params);
$total = (int)$totalStmt->fetchColumn();
$totalPages = ceil($total / $limit);

$categoryKeys = ['electronics','fashion','home','books','sports','games','other'];
?>

<!-- CATEGORY FILTER -->
<div style="margin-bottom: var(--sp-lg);">
  <div style="display:flex; gap:8px; flex-wrap:wrap; align-items:center;">
    <a href="/dashboard<?= $search ? '&search=' . urlencode($search) : '' ?>"
       class="btn btn-sm <?= !$category ? 'btn-primary' : 'btn-ghost' ?>" data-lang="cat_all">All</a>
    <?php foreach ($categoryKeys as $key): ?>
    <a href="/dashboard&category=<?= $key ?><?= $search ? '&search=' . urlencode($search) : '' ?>"
       class="btn btn-sm <?= $category === $key ? 'btn-primary' : 'btn-ghost' ?>" data-lang="cat_<?= $key ?>">
      <?= $key ?>
    </a>
    <?php endforeach; ?>
  </div>
</div>

<!-- MY PRODUCTS STATUS SECTION -->
<?php if ($user && !empty($myProducts)): ?>
<div style="margin-bottom:var(--sp-xl);">
  <div style="display:flex;align-items:center;gap:8px;margin-bottom:12px;">
    <span style="font-size:.85rem;font-weight:700;color:#aaa;text-transform:uppercase;letter-spacing:.06em;" data-lang="home_your_posts">Your Posts</span>
  </div>
  <div style="display:flex;flex-direction:column;gap:8px;">
    <?php foreach ($myProducts as $mp):
      $statusMap = [
        'pending'  => ['icon'=>'⏳', 'langKey'=>'home_status_pending', 'color'=>'#f59e0b', 'bg'=>'rgba(245,158,11,0.06)', 'border'=>'rgba(245,158,11,0.2)'],
        'rejected' => ['icon'=>'❌', 'langKey'=>'home_status_rejected', 'color'=>'#f87171', 'bg'=>'rgba(248,113,113,0.06)', 'border'=>'rgba(248,113,113,0.2)'],
        'banned'   => ['icon'=>'🚫', 'langKey'=>'home_status_banned', 'color'=>'#ef4444', 'bg'=>'rgba(239,68,68,0.06)', 'border'=>'rgba(239,68,68,0.25)'],
      ];
      $si = $statusMap[$mp['status']] ?? null;
      if (!$si) continue;
      $customReason = ($mp['status'] === 'rejected' && !empty($mp['rejection_reason']));
    ?>
    <div style="background:<?= $si['bg'] ?>;border:1px solid <?= $si['border'] ?>;border-radius:12px;padding:10px 14px;display:flex;align-items:center;gap:12px;">
      <a href="/product/<?= $mp['id'] ?>" style="flex-shrink:0;text-decoration:none;">
        <img src="<?= htmlspecialchars(getProductImageUrl($mp['image'] ?? '')) ?>" style="width:48px;height:48px;object-fit:cover;border-radius:8px;display:block;" alt="" onerror="this.src='/assets/default-avatar.png'">
      </a>
      <a href="/product/<?= $mp['id'] ?>" style="flex:1;min-width:0;text-decoration:none;color:inherit;">
        <div style="font-weight:600;font-size:.88rem;color:#e5e5e5;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;"><?= htmlspecialchars($mp['title']) ?></div>
        <div style="display:flex;align-items:center;gap:6px;margin-top:3px;">
          <span style="background:<?= $si['color'] ?>18;border:1px solid <?= $si['color'] ?>33;color:<?= $si['color'] ?>;padding:1px 8px;border-radius:999px;font-size:.72rem;font-weight:600;">
            <?= $si['icon'] ?> <?php if ($customReason): ?><?= htmlspecialchars($mp['rejection_reason']) ?><?php else: ?><span data-lang="<?= $si['langKey'] ?>"><?= $si['langKey'] ?></span><?php endif; ?>
          </span>
        </div>
      </a>
      <form method="post" style="flex-shrink:0;" onsubmit="return confirm(Lang.t('home_hide_confirm'))">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars(generateCSRF()) ?>">
        <input type="hidden" name="hide_product" value="<?= $mp['id'] ?>">
        <input type="hidden" name="hide_any_status" value="1">
        <button type="submit" data-lang-title="home_hide_tooltip" style="background:transparent;border:1px solid rgba(255,255,255,.1);color:#555;width:32px;height:32px;border-radius:8px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:.15s;" onmouseover="this.style.borderColor='rgba(255,255,255,.25)';this.style.color='#aaa'" onmouseout="this.style.borderColor='rgba(255,255,255,.1)';this.style.color='#555'">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></svg>
        </button>
      </form>
    </div>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- HEADER ROW -->
<div class="section-header">
  <div class="section-title" id="section-title-home">
    <?php if ($search): ?>
      <span data-lang="home_search_results">Results for</span> "<strong><?= htmlspecialchars($search) ?></strong>" — <?= $total ?> <span data-lang="home_products_count">products</span>
    <?php elseif ($category): ?>
      <span data-lang="cat_<?= $category ?>"><?= $category ?></span>
    <?php else: ?>
      <span data-lang="home_latest_products">Latest Products</span>
    <?php endif; ?>
  </div>
  <?php if ($user): ?>
  <a href="/post" class="btn btn-primary btn-sm">
    <span class="icon-plus"></span> <span data-lang="post_sell">Post for Sale</span>
  </a>
  <?php endif; ?>
</div>

<!-- PRODUCT GRID -->
<div id="product-grid-wrap">
<?php if ($products): ?>
<div class="product-grid">
  <?php foreach ($products as $p): ?>
  <a href="/product/<?= $p['id'] ?>" class="product-card">
    <div class="product-thumb-wrap">
      <img src="<?= htmlspecialchars(getProductImageUrl($p['image'])) ?>" class="product-thumb" alt="" loading="lazy" onerror="this.src='/assets/default-avatar.png'">
      <span class="product-category-badge" data-lang="cat_<?= $p['category'] ?>"><?= $p['category'] ?></span>
    </div>
    <div class="product-card-body">
      <div class="product-card-title"><?= htmlspecialchars($p['title']) ?></div>
      <div class="product-card-price"><?= formatPrice($p['price'], $p['currency']) ?></div>
      <div class="product-card-seller">
        <img src="<?= htmlspecialchars(getAvatarUrl($p['avatar'])) ?>" class="seller-mini-avatar" alt="">
        <?= htmlspecialchars($p['username']) ?> · <?= timeAgo($p['created_at']) ?>
      </div>
    </div>
  </a>
  <?php endforeach; ?>
</div>

<!-- PAGINATION -->
<?php if ($totalPages > 1): ?>
<div style="display:flex; justify-content:center; gap:8px; margin-top:var(--sp-xl);">
  <?php for ($i = 1; $i <= $totalPages; $i++): ?>
  <a href="?page=home&p=<?= $i ?><?= $category ? '&category=' . urlencode($category) : '' ?><?= $search ? '&search=' . urlencode($search) : '' ?>"
     class="btn btn-sm <?= $i === $page_n ? 'btn-primary' : 'btn-ghost' ?>">
    <?= $i ?>
  </a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php else: ?>
<div class="empty-state">
  <div class="empty-icon"><span class="icon-box"></span></div>
  <div class="empty-title" data-lang="home_no_products">No products yet</div>
  <div class="empty-desc">
    <?php if ($search): ?>
      <span data-lang="home_no_search_results">No products found matching</span> "<?= htmlspecialchars($search) ?>"
    <?php else: ?>
      <span data-lang="home_be_first">Be the first to post!</span>
    <?php endif; ?>
  </div>
  <?php if ($user): ?>
  <a href="/post" class="btn btn-primary">
    <span class="icon-plus"></span> <span data-lang="home_post_product">Post Product</span>
  </a>
  <?php endif; ?>
</div>
<?php endif; ?>
</div><!-- /product-grid-wrap -->
