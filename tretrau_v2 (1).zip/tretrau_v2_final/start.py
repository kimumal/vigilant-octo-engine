#!/usr/bin/env python3
"""
TreTrauNetwork — Telegram Bot Server
=====================================
Chạy: python3 start.py

Chức năng:
  • Poll pending_notifications từ DB (qua api.php) → gửi TG với nút bấm
  • Admin vào panel → nút [Verify] [Block] → gọi verify_token.php
  • Bài đăng mới   → nút [Duyệt] [Từ chối] → gọi api.php

Yêu cầu: pip install requests
"""

import requests
import time
import json
import sys
import signal
from datetime import datetime

# ═══════════════════════════════════════════════════════════════
# CẤU HÌNH
# ═══════════════════════════════════════════════════════════════
BOT_TOKEN      = "8336938728:AAH9QDiLrpb-OLtTj9zWB9ouWKnRV4-UHx4"
ADMIN_CHAT_ID  = "-5159343258"
WEBHOOK_SECRET = "tretrau_webhook_2025_secret_key"
SERVER_URL     = "http://0.0.0.0:8081"

POLL_INTERVAL       = 1    # giây giữa mỗi lần long-poll Telegram
NOTIF_POLL_INTERVAL = 2    # giây giữa mỗi lần poll DB notifications
LONG_POLL_SECS      = 30

BASE_TG = f"https://api.telegram.org/bot{BOT_TOKEN}"

# ═══════════════════════════════════════════════════════════════
# LOG
# ═══════════════════════════════════════════════════════════════
class C:
    R = "\033[0m"; G = "\033[92m"; Y = "\033[93m"
    RED = "\033[91m"; B = "\033[94m"; CY = "\033[96m"
    BOLD = "\033[1m"; DIM = "\033[2m"

def log(level: str, msg: str):
    now = datetime.now().strftime("%H:%M:%S")
    colors = {"INFO": C.B, "OK": C.G, "WARN": C.Y,
               "ERROR": C.RED, "BOT": C.CY, "ACTION": C.G + C.BOLD}
    color = colors.get(level, C.R)
    print(f"{C.DIM}[{now}]{C.R} {color}[{level}]{C.R} {msg}", flush=True)

# ═══════════════════════════════════════════════════════════════
# TELEGRAM HELPERS
# ═══════════════════════════════════════════════════════════════
def tg_call(method: str, data: dict = None, timeout: int = 12) -> dict:
    try:
        r = requests.post(f"{BASE_TG}/{method}", json=data or {}, timeout=timeout)
        return r.json()
    except requests.exceptions.Timeout:
        return {"ok": False, "description": "timeout"}
    except Exception as e:
        return {"ok": False, "description": str(e)}

def send_msg(chat_id: str, text: str, keyboard: list = None) -> dict:
    payload = {"chat_id": chat_id, "text": text, "parse_mode": "HTML"}
    if keyboard:
        payload["reply_markup"] = {"inline_keyboard": keyboard}
    return tg_call("sendMessage", payload)

def send_photo(chat_id: str, photo_path_or_url: str, caption: str, keyboard: list = None) -> dict:
    """Gửi ảnh kèm caption. Upload file local hoặc dùng URL. Fallback sang text nếu lỗi."""
    import os
    reply_markup = json.dumps({"inline_keyboard": keyboard}) if keyboard else None

    try:
        # Nếu là đường dẫn file local → upload multipart
        if os.path.isfile(photo_path_or_url):
            url = f"{BASE_TG}/sendPhoto"
            with open(photo_path_or_url, "rb") as f:
                files = {"photo": f}
                data = {
                    "chat_id": chat_id,
                    "caption": caption,
                    "parse_mode": "HTML",
                }
                if reply_markup:
                    data["reply_markup"] = reply_markup
                r = requests.post(url, data=data, files=files, timeout=30)
                res = r.json()
        else:
            # URL remote
            payload = {
                "chat_id": chat_id,
                "photo": photo_path_or_url,
                "caption": caption,
                "parse_mode": "HTML",
            }
            if keyboard:
                payload["reply_markup"] = {"inline_keyboard": keyboard}
            res = tg_call("sendPhoto", payload)

        if not res.get("ok"):
            log("WARN", f"sendPhoto failed: {res.get('description','')}, fallback to text")
            return send_msg(chat_id, caption, keyboard)
        return res
    except Exception as e:
        log("WARN", f"sendPhoto exception: {e}, fallback to text")
        return send_msg(chat_id, caption, keyboard)

def answer_cb(cb_id: str, text: str = "", alert: bool = False):
    tg_call("answerCallbackQuery", {
        "callback_query_id": cb_id,
        "text": text,
        "show_alert": alert,
    })

def edit_msg(chat_id: str, msg_id: int, text: str):
    tg_call("editMessageText", {
        "chat_id": chat_id,
        "message_id": msg_id,
        "text": text,
        "parse_mode": "HTML",
    })

def get_updates(offset: int = 0) -> list:
    res = tg_call("getUpdates", {
        "offset": offset,
        "timeout": LONG_POLL_SECS,
        "limit": 10,
        "allowed_updates": ["callback_query"],
    }, timeout=LONG_POLL_SECS + 5)
    if not res.get("ok"):
        return []
    updates = res.get("result", [])
    return updates

def delete_webhook():
    return tg_call("deleteWebhook", {"drop_pending_updates": False})

def get_me() -> dict:
    return tg_call("getMe")

# ═══════════════════════════════════════════════════════════════
# SERVER HELPERS
# ═══════════════════════════════════════════════════════════════
def api_call(action: str, extra: dict = None) -> dict:
    data = {"action": action, "secret": WEBHOOK_SECRET}
    if extra:
        data.update(extra)
    try:
        r = requests.post(f"{SERVER_URL}/api.php", data=data, timeout=8)
        return r.json()
    except Exception as e:
        return {"error": str(e)}

def admin_verify(token: str) -> dict:
    try:
        r = requests.post(
            f"{SERVER_URL}/admin/verify_token.php",
            data={"token": token, "secret": WEBHOOK_SECRET, "action": "verify"},
            timeout=8
        )
        return r.json()
    except Exception as e:
        return {"error": str(e)}

def admin_deny(token: str) -> dict:
    try:
        r = requests.post(
            f"{SERVER_URL}/admin/verify_token.php",
            data={"token": token, "secret": WEBHOOK_SECRET, "action": "deny"},
            timeout=8
        )
        return r.json()
    except Exception as e:
        return {"error": str(e)}

def get_pending_notifications() -> list:
    """Poll pending_notifications từ DB"""
    try:
        r = requests.post(
            f"{SERVER_URL}/api.php",
            data={"action": "get_pending_notifications", "secret": WEBHOOK_SECRET},
            timeout=8
        )
        data = r.json()
        return data.get("notifications", [])
    except Exception as e:
        log("ERROR", f"get_pending_notifications: {e}")
        return []

# ═══════════════════════════════════════════════════════════════
# NOTIFICATION PROCESSOR — đọc từ DB và gửi TG với nút bấm
# ═══════════════════════════════════════════════════════════════
def _find_image(payload: dict) -> str:
    """Lấy ảnh từ bot_queue/ — PHP đã copy vào đây chắc chắn."""
    import os
    image_path = payload.get("image_path", "").strip()
    if image_path and os.path.isfile(image_path):
        log("INFO", f"✅ Ảnh: {image_path}")
        return image_path
    if image_path:
        log("WARN", f"❌ Không tìm thấy ảnh: {image_path}")
    return ""



def process_notification(notif: dict):
    ntype = notif.get("type", "")
    try:
        payload = notif.get("payload")
        if isinstance(payload, str):
            payload = json.loads(payload)
    except Exception:
        log("ERROR", f"Invalid payload: {notif.get('payload')}")
        return

    if ntype == "admin_access":
        token    = payload.get("token", "")
        username = payload.get("username", "?")
        ip       = payload.get("ip", "?")
        ts       = payload.get("time", datetime.now().strftime("%d/%m/%Y %H:%M:%S"))

        # Validate token length for Telegram callback_data (max 64 bytes)
        # "verify_admin:" = 13 chars, so token must be <= 51 chars
        if len(token) > 51:
            log("ERROR", f"Token quá dài ({len(token)} chars), bỏ qua. Cần <= 51 chars.")
            return

        text = (
            f"🔐 <b>YÊU CẦU VÀO ADMIN PANEL</b>\n\n"
            f"👤 User: <code>{username}</code>\n"
            f"🌐 IP: <code>{ip}</code>\n"
            f"📅 {ts}\n\n"
            f"⚠️ <b>Hết hạn sau 5 phút</b>"
        )
        keyboard = [[
            {"text": "✅ Cho phép", "callback_data": f"verify_admin:{token}"},
            {"text": "❌ Từ chối",  "callback_data": f"deny_admin:{token}"},
        ]]
        res = send_msg(ADMIN_CHAT_ID, text, keyboard)
        if res.get("ok"):
            log("OK", f"✅ Đã gửi xác thực admin [{username}]")
        else:
            log("ERROR", f"Gửi admin_access thất bại: {res.get('description','?')}")

    elif ntype == "new_product":
        pid      = payload.get("id", "?")
        title    = payload.get("title", "?")
        user     = payload.get("username", "?")
        price    = payload.get("price_fmt", "?")
        cat      = payload.get("category", "?")
        desc     = payload.get("description", "")[:120]
        tier     = payload.get("tier", "Free")
        ts       = payload.get("time", datetime.now().strftime("%d/%m/%Y %H:%M:%S"))
        b64      = payload.get("image_b64", "")
        mime     = payload.get("image_mime", "image/jpeg")

        caption = (
            f"🛒 <b>BÀI ĐĂNG MỚI - CHỜ XÉT DUYỆT</b>\n\n"
            f"📦 <b>{title}</b>\n"
            f"👤 Người đăng: <code>{user}</code>\n"
            f"💰 Giá: <b>{price}</b>\n"
            f"🏷 Danh mục: {cat}\n"
            f"📝 {desc}\n"
            f"🆔 ID: <code>{pid}</code>\n"
            f"🍀 Tier: {tier}\n"
            f"⏰ {ts}\n\n"
            f"👇 Chọn hành động:"
        )
        keyboard = [[
            {"text": "✅ Duyệt bài", "callback_data": f"approve_product:{pid}"},
            {"text": "❌ Từ chối",   "callback_data": f"reject_product:{pid}"},
        ]]
        reply_markup = json.dumps({"inline_keyboard": keyboard})

        sent = False
        if b64:
            try:
                import base64 as _b64
                img_bytes = _b64.b64decode(b64)
                ext = "jpg" if "jpeg" in mime else mime.split("/")[-1]
                url = f"{BASE_TG}/sendPhoto"
                files = {"photo": (f"product_{pid}.{ext}", img_bytes, mime)}
                data  = {
                    "chat_id":      ADMIN_CHAT_ID,
                    "caption":      caption,
                    "parse_mode":   "HTML",
                    "reply_markup": reply_markup,
                }
                r = requests.post(url, data=data, files=files, timeout=30)
                res = r.json()
                if res.get("ok"):
                    sent = True
                    log("OK", f"✅ Gửi sản phẩm #{pid} + ảnh")
                else:
                    log("ERROR", f"sendPhoto FAIL: {res.get('description','?')}")
            except Exception as e:
                log("ERROR", f"sendPhoto exception: {e}")

        if not sent:
            res = send_msg(ADMIN_CHAT_ID, caption, keyboard)
            if res.get("ok"):
                log("OK", f"✅ Gửi sản phẩm #{pid} (text only{'- no image data' if not b64 else '- photo failed'})")
            else:
                log("ERROR", f"send_msg FAIL: {res.get('description','?')}")

    else:
        log("WARN", f"Unknown notification type: {ntype}")

# ═══════════════════════════════════════════════════════════════
# CALLBACK HANDLERS
# ═══════════════════════════════════════════════════════════════
def handle_approve_product(pid: int, cb_id: str, chat_id: str, msg_id: int, from_name: str):
    log("ACTION", f"Duyệt bài #{pid} bởi {from_name}")
    res = api_call("approve_product", {"product_id": pid})
    if res.get("status") == "approved":
        answer_cb(cb_id, "✅ Đã duyệt bài đăng!")
        edit_msg(chat_id, msg_id,
            f"✅ <b>ĐÃ DUYỆT BÀI ĐĂNG</b>\n\n"
            f"🆔 ID: <code>{pid}</code>\n"
            f"✅ Duyệt bởi: {from_name}\n"
            f"🕐 {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
        )
        log("OK", f"Product #{pid} duyệt thành công")
    elif "error" in res:
        answer_cb(cb_id, f"❌ Lỗi: {res['error']}", alert=True)
    else:
        answer_cb(cb_id, "⚠️ Bài đăng không tồn tại hoặc đã xử lý!", alert=True)

def handle_reject_product(pid: int, cb_id: str, chat_id: str, msg_id: int, from_name: str):
    log("ACTION", f"Từ chối bài #{pid} bởi {from_name}")
    res = api_call("reject_product", {"product_id": pid})
    if res.get("status") == "rejected":
        answer_cb(cb_id, "❌ Đã từ chối bài đăng!")
        edit_msg(chat_id, msg_id,
            f"❌ <b>ĐÃ TỪ CHỐI BÀI ĐĂNG</b>\n\n"
            f"🆔 ID: <code>{pid}</code>\n"
            f"❌ Từ chối bởi: {from_name}\n"
            f"🕐 {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
        )
        log("OK", f"Product #{pid} từ chối thành công")
    elif "error" in res:
        answer_cb(cb_id, f"❌ Lỗi: {res['error']}", alert=True)
    else:
        answer_cb(cb_id, "⚠️ Bài đăng không tồn tại hoặc đã xử lý!", alert=True)

def handle_verify_admin(token: str, cb_id: str, chat_id: str, msg_id: int, from_name: str):
    log("ACTION", f"Verify admin bởi {from_name}")
    res = admin_verify(token)
    if res.get("ok") or res.get("success"):
        answer_cb(cb_id, "✅ Đã xác thực! Admin đang vào panel...")
        edit_msg(chat_id, msg_id,
            f"✅ <b>ĐÃ XÁC THỰC ADMIN</b>\n"
            f"🔑 Token: <code>{token[:16]}...</code>\n"
            f"✅ Bởi: {from_name}\n"
            f"🕐 {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
        )
        log("OK", f"Admin verified bởi {from_name}")
    elif "error" in res:
        answer_cb(cb_id, f"❌ Lỗi: {res['error']}", alert=True)
    else:
        answer_cb(cb_id, "⚠️ Token đã hết hạn hoặc đã dùng!", alert=True)

def handle_deny_admin(token: str, cb_id: str, chat_id: str, msg_id: int, from_name: str):
    log("ACTION", f"Từ chối admin bởi {from_name}")
    res = admin_deny(token)
    if res.get("ok") or res.get("success"):
        answer_cb(cb_id, "❌ Đã từ chối truy cập!")
        edit_msg(chat_id, msg_id,
            f"❌ <b>ĐÃ TỪ CHỐI ADMIN</b>\n"
            f"🔑 Token: <code>{token[:16]}...</code>\n"
            f"❌ Bởi: {from_name}\n"
            f"🕐 {datetime.now().strftime('%d/%m/%Y %H:%M:%S')}"
        )
        log("OK", f"Admin denied bởi {from_name}")
    else:
        answer_cb(cb_id, "⚠️ Lỗi hoặc token đã hết hạn!", alert=True)

# ═══════════════════════════════════════════════════════════════
# UPDATE PROCESSOR
# ═══════════════════════════════════════════════════════════════
def process_update(update: dict):
    cb = update.get("callback_query")
    if not cb:
        return

    cb_id    = cb["id"]
    data     = cb.get("data", "")
    chat_id  = str(cb["message"]["chat"]["id"])
    msg_id   = int(cb["message"]["message_id"])
    from_u   = cb.get("from", {})
    from_name = "@" + (from_u.get("username") or from_u.get("first_name", "Admin"))

    if chat_id != ADMIN_CHAT_ID:
        answer_cb(cb_id, "Không có quyền!", alert=True)
        return

    log("BOT", f"Callback: '{data[:80]}' từ {from_name}")

    try:
        if data.startswith("approve_product:"):
            handle_approve_product(int(data.split(":", 1)[1]), cb_id, chat_id, msg_id, from_name)
        elif data.startswith("reject_product:"):
            handle_reject_product(int(data.split(":", 1)[1]), cb_id, chat_id, msg_id, from_name)
        elif data.startswith("verify_admin:"):
            handle_verify_admin(data.split(":", 1)[1].strip(), cb_id, chat_id, msg_id, from_name)
        elif data.startswith("deny_admin:"):
            handle_deny_admin(data.split(":", 1)[1].strip(), cb_id, chat_id, msg_id, from_name)
        else:
            answer_cb(cb_id, "Lệnh không xác định", alert=True)
    except Exception as e:
        log("ERROR", f"process_update error: {e}")
        try:
            answer_cb(cb_id, "Lỗi xử lý! Thử lại sau.", alert=True)
        except:
            pass

# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════
def _exit(sig, frame):
    print()
    log("INFO", "Bot dừng.")
    sys.exit(0)

signal.signal(signal.SIGINT, _exit)
signal.signal(signal.SIGTERM, _exit)

def main():
    import os, sys

    # ── Chỉ cho phép 1 instance chạy (PID lock) ──────────────
    pid_file = "/tmp/tretrau_bot.pid"
    if os.path.exists(pid_file):
        try:
            old_pid = int(open(pid_file).read().strip())
            # Kiểm tra process có còn sống không
            os.kill(old_pid, 0)
            log("ERROR", f"Bot đã chạy rồi! PID={old_pid}. Dùng: kill {old_pid}")
            sys.exit(1)
        except (ProcessLookupError, ValueError):
            pass  # Process chết rồi, tiếp tục
    open(pid_file, 'w').write(str(os.getpid()))

    import atexit
    atexit.register(lambda: os.path.exists(pid_file) and os.remove(pid_file))

    log("INFO", "Khởi động bot...")

    r = delete_webhook()
    log("OK" if r.get("ok") else "WARN",
        "Đã xóa webhook cũ" if r.get("ok") else f"delete_webhook: {r.get('description','?')}")

    info = get_me()
    if not info.get("ok"):
        log("ERROR", f"Không kết nối được Telegram: {info.get('description','?')}")
        sys.exit(1)

    name = info["result"].get("first_name", "Bot")
    user = info["result"].get("username", "?")
    print(f"\n{C.CY}{C.BOLD}╔══════════════════════════════════════════════╗{C.R}")
    print(f"{C.CY}{C.BOLD}║   TreTrauNetwork — Telegram Bot Server       ║{C.R}")
    print(f"{C.CY}{C.BOLD}╚══════════════════════════════════════════════╝{C.R}")
    print(f"  {C.G}Bot:{C.R}    {name} (@{user})")
    print(f"  {C.G}Admin:{C.R}  {ADMIN_CHAT_ID}")
    print(f"  {C.G}Server:{C.R} {SERVER_URL}")
    print(f"  {C.G}Mode:{C.R}   Long Polling + DB Notifications (poll mỗi {NOTIF_POLL_INTERVAL}s)\n")

    # KHÔNG gửi "Bot khởi động" nữa → tránh spam
    log("OK", "Bot sẵn sàng. Poll DB mỗi 2s, poll Telegram liên tục...")

    offset = 0
    err_count = 0
    last_notif_poll = 0

    while True:
        try:
            # ── Poll pending notifications từ DB ──────────────────
            now = time.time()
            if now - last_notif_poll >= NOTIF_POLL_INTERVAL:
                last_notif_poll = now
                try:
                    notifs = get_pending_notifications()
                    for n in notifs:
                        try:
                            process_notification(n)
                        except Exception as e:
                            log("ERROR", f"process_notification: {e}")
                except Exception as e:
                    log("ERROR", f"Notification poll error: {e}")

            # ── Poll Telegram callbacks ────────────────────────────
            updates = get_updates(offset)
            err_count = 0

            for u in updates:
                uid = u.get("update_id", 0)
                offset = uid + 1
                try:
                    process_update(u)
                except Exception as e:
                    log("ERROR", f"Update {uid}: {e}")

            time.sleep(POLL_INTERVAL)

        except KeyboardInterrupt:
            break
        except requests.exceptions.ConnectionError as e:
            err_count += 1
            log("ERROR", f"Lỗi kết nối ({err_count}): {e}")
            time.sleep(min(5 * err_count, 30))
        except Exception as e:
            err_count += 1
            log("ERROR", f"Lỗi: {e}")
            time.sleep(5)

if __name__ == "__main__":
    main()
