// ================================================================
// CHAT.JS — Clean Telegram-style, no emoji btn
// ================================================================
const QUICK_REACTIONS = ['❤️','👍','😂','😮','😢','🔥'];

class ChatApp {
  constructor(config) {
    this.config = config;
    this.lastMsgId = 0;
    this.polling = null;
    this.selectedFile = null;
    this.replyTo = null;
    // Support custom element IDs for multiple instances on same page
    const ids = config.elIds || {};
    this.el = {
      messages:       document.getElementById(ids.messages       || 'chat-messages'),
      textarea:       document.getElementById(ids.textarea       || 'chat-input'),
      sendBtn:        document.getElementById(ids.sendBtn        || 'chat-send'),
      fileInput:      document.getElementById(ids.fileInput      || 'chat-file'),
      previewWrap:    document.getElementById(ids.previewWrap    || 'chat-preview'),
      previewImg:     document.getElementById(ids.previewImg     || 'chat-preview-img'),
      replyBar:       document.getElementById(ids.replyBar       || 'chat-reply-bar'),
      replyText:      document.getElementById(ids.replyText      || 'chat-reply-text'),
      replyCancelBtn: document.getElementById(ids.replyCancelBtn || 'chat-reply-cancel'),
      // Store ID string so we can re-query after DOM resets
      typingIndicatorId: ids.typingIndicator || null,
    };
    this.init();
  }

  init() { this.loadHistory(); this.setupEvents(); this.startPolling(); }

  async loadHistory() {
    const msgs = await this.fetchMessages(0);
    msgs.forEach(m => this.renderMessage(m, false));
    this.scrollBottom();
  }

  startPolling() {
    this.polling = setInterval(async () => {
      const msgs = await this.fetchMessages(this.lastMsgId);
      if (msgs.length) { msgs.forEach(m => this.renderMessage(m, true)); this.scrollBottom(); }
    }, 1800);
  }
  stopPolling() { clearInterval(this.polling); }

  async fetchMessages(after) {
    const p = new URLSearchParams({ action:'get_messages', after, channel_id:this.config.channelId||0, is_global:this.config.isGlobal?1:0, is_dm:this.config.isDm?1:0, peer_id:this.config.peerId||0 });
    try {
      const res = await fetch('/api.php?' + p);
      const text = await res.text();
      let data; try { data = JSON.parse(text); } catch(e) { return []; }
      const msgs = data.messages || [];
      if (msgs.length) this.lastMsgId = Math.max(...msgs.map(m => m.id));
      return msgs;
    } catch(e) { return []; }
  }

  renderMessage(msg, animate = true) {
    if (!this.el.messages) return;
    if (document.getElementById('msg-' + msg.id)) return;
    // Always query fresh — typingIndicator may be re-created after clearConvMessages()
    const typingEl = (this.el.typingIndicatorId && document.getElementById(this.el.typingIndicatorId))
      || this.el.messages.querySelector('.typing-indicator-wrap');
    const isMine = parseInt(msg.sender_id) === parseInt(this.config.currentUserId);
    const wrapper = document.createElement('div');
    wrapper.id = 'msg-' + msg.id;
    wrapper.className = 'msg-row ' + (isMine ? 'mine' : 'theirs');
    if (!animate) wrapper.style.animation = 'none';

    if (msg.type === 'system') {
      wrapper.innerHTML = '<div class="msg-system">' + escHtml(msg.content || '') + '</div>';
      if (typingEl) this.el.messages.insertBefore(wrapper, typingEl);
      else this.el.messages.appendChild(wrapper);
      return;
    }
    if (parseInt(msg.recalled)) {
      wrapper.innerHTML = `<img src="${msg.avatar||'assets/default-avatar.png'}" class="msg-avatar" onclick="if(typeof showUserProfile==='function')showUserProfile(${msg.sender_id})" alt=""><div class="msg-bubble">${!isMine?'<div class="msg-sender-name">'+escHtml(msg.username||'')+'</div>':''}<div class="msg-content"><span class="msg-recalled"><span class="icon-undo"></span> Tin nhắn đã bị thu hồi</span></div></div>`;
      if (typingEl) this.el.messages.insertBefore(wrapper, typingEl);
      else this.el.messages.appendChild(wrapper);
      return;
    }

    const tickHtml = (typeof getRoleBadgeSmall==='function') ? getRoleBadgeSmall(msg.sender_role||'') : '';
    const avatarHtml = `<img src="${msg.avatar||'assets/default-avatar.png'}" class="msg-avatar" onclick="if(typeof showUserProfile==='function')showUserProfile(${msg.sender_id})" alt="">`;
    let replyHtml = '';
    if (msg.reply_to && msg.reply_username) {
      const rc = msg.reply_type==='image' ? '<span class="icon-image"></span> Hình ảnh' : escHtml((msg.reply_content||'').substring(0,60));
      replyHtml = `<div class="msg-reply-preview" onclick="document.getElementById('msg-${msg.reply_to}')?.scrollIntoView({behavior:'smooth',block:'center'})"><div class="msg-reply-bar-line"></div><div class="msg-reply-body"><span class="msg-reply-name">${escHtml(msg.reply_username)}</span><span class="msg-reply-content">${rc}</span></div></div>`;
    }
    let contentHtml;
    if (msg.type==='image' && msg.image) {
      contentHtml = `<div class="msg-content" style="padding:4px;">${replyHtml}<img src="${msg.image}" class="msg-image" data-lightbox="${msg.image}" alt=""></div>`;
    } else {
      contentHtml = `<div class="msg-content">${replyHtml}${this.formatText(msg.content||'')}</div>`;
    }
    const time = new Date(msg.created_at).toLocaleTimeString('vi-VN',{hour:'2-digit',minute:'2-digit'});
    const statusIcon = isMine ? '<span class="icon-check" style="font-size:.6rem;"></span>' : '';
    wrapper.innerHTML = `${!isMine?avatarHtml:''}<div class="msg-bubble" data-msg-id="${msg.id}">${!isMine&&(this.config.isGlobal||this.config.isDm)?'<div class="msg-sender-name">'+escHtml(msg.username||'')+tickHtml+'</div>':''}${contentHtml}<div class="msg-meta"><span>${time}</span>${statusIcon}</div><div class="msg-reactions" id="reactions-${msg.id}"></div></div>${isMine?avatarHtml:''}`;

    const bubble = wrapper.querySelector('.msg-bubble');
    if (bubble) {
      bubble.addEventListener('contextmenu', e => { e.preventDefault(); this.showContextMenu(e, msg, isMine); });
      let pressTimer;
      bubble.addEventListener('touchstart', () => { pressTimer = setTimeout(() => { const r = bubble.getBoundingClientRect(); this.showContextMenu({clientX:r.left+r.width/2,clientY:r.top}, msg, isMine); }, 500); }, {passive:true});
      bubble.addEventListener('touchend', () => clearTimeout(pressTimer));
      bubble.addEventListener('touchmove', () => clearTimeout(pressTimer));
    }
    if (typingEl) this.el.messages.insertBefore(wrapper, typingEl);
    else this.el.messages.appendChild(wrapper);
  }

  formatText(text) {
    let html = escHtml(text);
    html = html.replace(/\*([^*]+)\*/g,'<strong>$1</strong>');
    html = html.replace(/_([^_]+)_/g,'<em>$1</em>');
    html = html.replace(/(https?:\/\/[^\s]+)/g,'<a href="$1" target="_blank" rel="noopener" style="color:inherit;text-decoration:underline;">$1</a>');
    return html;
  }

  showContextMenu(event, msg, isMine) {
    document.querySelector('.msg-ctx-menu')?.remove();
    const menu = document.createElement('div');
    menu.className = 'msg-ctx-menu';
    let reactionsHtml = '<div class="msg-ctx-reactions">';
    QUICK_REACTIONS.forEach(e => { reactionsHtml += `<button class="msg-ctx-reaction-btn" data-reaction="${e}">${e}</button>`; });
    reactionsHtml += '</div>';
    const items = [];
    if (!parseInt(msg.recalled)) items.push({icon:'icon-reply',label:'Trả lời',fn:()=>this.setReply(msg)});
    if (!parseInt(msg.recalled)&&msg.content) items.push({icon:'icon-copy',label:'Sao chép',fn:()=>{navigator.clipboard?.writeText(msg.content);Toast.success('Đã sao chép');}});
    if (msg.image) items.push({icon:'icon-eye',label:'Xem ảnh',fn:()=>openLightbox(msg.image)});
    if (isMine&&!parseInt(msg.recalled)) {
      const age=(Date.now()-new Date(msg.created_at).getTime())/1000;
      if (age<3600) items.push({icon:'icon-undo',label:'Thu hồi',fn:()=>this.recallMessage(msg.id)});
      items.push({icon:'icon-trash',label:'Xóa',fn:()=>this.deleteMessage(msg.id),danger:true});
    }
    menu.innerHTML = reactionsHtml + items.map(it => `<button class="msg-ctx-item ${it.danger?'danger':''}"><span class="${it.icon}"></span> ${it.label}</button>`).join('');
    const x = Math.min(event.clientX||20,window.innerWidth-200);
    const y = Math.max(Math.min(event.clientY||100,window.innerHeight-(items.length*44+60)-20),60);
    menu.style.cssText = `position:fixed;left:${x}px;top:${y}px;z-index:9999;`;
    document.body.appendChild(menu);
    menu.querySelectorAll('.msg-ctx-reaction-btn').forEach(btn => { btn.addEventListener('click',()=>{this.addReaction(msg.id,btn.dataset.reaction);menu.remove();}); });
    menu.querySelectorAll('.msg-ctx-item').forEach((btn,i) => { btn.addEventListener('click',()=>{items[i].fn();menu.remove();}); });
    setTimeout(()=>{document.addEventListener('click',function h(){menu.remove();document.removeEventListener('click',h);});},10);
  }

  addReaction(msgId, emoji) {
    const c = document.getElementById('reactions-'+msgId); if (!c) return;
    const ex = c.querySelector(`[data-emoji="${emoji}"]`); if (ex){ex.remove();return;}
    const el = document.createElement('span'); el.className='msg-reaction mine'; el.dataset.emoji=emoji;
    el.innerHTML=`${emoji} <span class="msg-reaction-count">1</span>`; el.onclick=()=>el.remove(); c.appendChild(el);
  }

  setReply(msg) {
    this.replyTo={id:msg.id,username:msg.username,content:msg.content,type:msg.type};
    if(this.el.replyBar){this.el.replyBar.classList.add('show');this.el.replyBar.style.display='flex';}
    if(this.el.replyText){const p=msg.type==='image'?'📷 Hình ảnh':(msg.content||'').substring(0,60);this.el.replyText.innerHTML='<strong>'+escHtml(msg.username)+'</strong>: '+escHtml(p);}
    this.el.textarea?.focus();
  }
  clearReply(){this.replyTo=null;if(this.el.replyBar){this.el.replyBar.classList.remove('show');this.el.replyBar.style.display='none';}}

  async recallMessage(msgId){try{const f=new FormData();f.append('action','recall_message');f.append('message_id',msgId);await fetch('/api.php',{method:'POST',body:f});const el=document.getElementById('msg-'+msgId);if(el){const b=el.querySelector('.msg-content');if(b)b.innerHTML='<span class="msg-recalled"><span class="icon-undo"></span> Đã thu hồi</span>';}}catch(e){Toast.error(e.message);}}
  async deleteMessage(msgId){try{const f=new FormData();f.append('action','delete_message_self');f.append('message_id',msgId);await fetch('/api.php',{method:'POST',body:f});document.getElementById('msg-'+msgId)?.remove();}catch(e){Toast.error(e.message);}}

  async sendMessage() {
    const content=this.el.textarea?.value.trim()||'';
    if(!content&&!this.selectedFile)return;
    const btn=this.el.sendBtn;if(btn)btn.disabled=true;
    try{
      const form=new FormData();form.append('action','send_message');form.append('channel_id',this.config.channelId||0);form.append('receiver_id',this.config.peerId||0);form.append('is_global',this.config.isGlobal?1:0);form.append('is_dm',this.config.isDm?1:0);
      if(this.replyTo)form.append('reply_to',this.replyTo.id);if(content)form.append('content',content);if(this.selectedFile)form.append('image',this.selectedFile);
      const res=await fetch('/api.php',{method:'POST',body:form});const text=await res.text();let data;try{data=JSON.parse(text);}catch(e){throw new Error('Lỗi server');}
      if(data.error)throw new Error(data.error);if(data.message){this.renderMessage(data.message,true);this.scrollBottom();}
      if(this.el.textarea){this.el.textarea.value='';this.el.textarea.style.height='auto';}this.clearReply();this.clearPreview();
    }catch(e){Toast.error(e.message);}finally{if(btn)btn.disabled=false;}
  }

  setupEvents(){
    this.el.sendBtn?.addEventListener('click',()=>this.sendMessage());
    this.el.textarea?.addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();this.sendMessage();}});
    this.el.fileInput?.addEventListener('change',()=>{const file=this.el.fileInput.files[0];if(!file)return;const reader=new FileReader();reader.onload=e=>{this.selectedFile=file;if(this.el.previewImg)this.el.previewImg.src=e.target.result;if(this.el.previewWrap)this.el.previewWrap.style.display='block';};reader.readAsDataURL(file);});
    this.el.replyCancelBtn?.addEventListener('click',()=>this.clearReply());
  }

  clearPreview(){this.selectedFile=null;if(this.el.fileInput)this.el.fileInput.value='';if(this.el.previewWrap)this.el.previewWrap.style.display='none';if(this.el.previewImg)this.el.previewImg.src='';}
  scrollBottom(){if(this.el.messages)this.el.messages.scrollTop=this.el.messages.scrollHeight;}
}

function escHtml(s){const d=document.createElement('div');d.textContent=String(s);return d.innerHTML;}

// ── GROUP INFO MODAL ──
function showGroupInfo(memberData) {
  const members = memberData || [];
  const overlay = document.createElement('div');
  overlay.className = 'glass-overlay';
  overlay.onclick = e => { if (e.target === overlay) overlay.remove(); };
  let memberHtml = '';
  members.forEach(m => {
    const tick = m.role==='admin' ? '<svg viewBox="0 0 14 14" fill="none" width="12" height="12"><circle cx="7" cy="7" r="7" fill="#e8192c"/><path d="M3.5 7.2l2 2 4-4" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>' : m.role==='premium' ? '<svg viewBox="0 0 14 14" fill="none" width="12" height="12"><circle cx="7" cy="7" r="7" fill="#1877f2"/><path d="M3.5 7.2l2 2 4-4" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>' : '';
    const roleLabel = m.role==='admin' ? '<span class="gi-member-role">Admin</span>' : '';
    memberHtml += `<div class="gi-member" onclick="showUserProfile(${m.id});document.querySelector('.glass-overlay')?.remove();"><img src="${m.avatar}" alt=""><div class="gi-member-info"><div class="gi-member-name">${escHtml(m.username)} ${tick}</div><div class="gi-member-status">trực tuyến</div></div>${roleLabel}</div>`;
  });
  overlay.innerHTML = `<div class="glass-modal"><button class="gi-close" onclick="this.closest('.glass-overlay').remove()"><span class="icon-x"></span></button><div class="gi-banner"><div class="gi-banner-pattern"></div><div class="gi-banner-grad"></div></div><div class="gi-avatar-wrap"><img src="${window._communityAvatar||'assets/dragon-icon.jpg'}" class="gi-avatar" alt=""></div><div class="gi-body"><div class="gi-name">TreTrau Network</div><div class="gi-sub">${members.length} thành viên online</div><div class="gi-actions"><div class="gi-action-btn" onclick="Toast.info('Bật âm')"><div class="gi-icon"><span class="icon-chat"></span></div>Nhắn tin</div><div class="gi-action-btn" onclick="Toast.info('Tắt âm')"><div class="gi-icon">🔔</div>Bật âm</div><div class="gi-action-btn" onclick="showGroupStats()"><div class="gi-icon"><span class="icon-activity"></span></div>Thống kê</div></div><div class="gi-desc">Cộng đồng TreTrau Network — nơi trao đổi, mua bán và kết nối thành viên.</div><div class="gi-link" onclick="Toast.info('Đã sao chép link');navigator.clipboard?.writeText(window.location.origin)"><span class="icon-global" style="font-size:.9rem;"></span><div style="flex:1;"><div style="font-size:.82rem;color:var(--text-primary);">tretrau.network</div><div style="font-size:.68rem;color:var(--text-muted);">Link mời</div></div></div><div class="gi-section-label">Thành viên online (${members.length})</div><div class="gi-member-list">${memberHtml||'<div style="padding:12px;text-align:center;color:var(--text-muted);font-size:.8rem;">Chưa có ai online</div>'}</div></div></div>`;
  document.body.appendChild(overlay);
}

function showGroupStats() {
  document.querySelector('.glass-overlay')?.remove();
  const overlay = document.createElement('div');
  overlay.className = 'glass-overlay';
  overlay.onclick = e => { if (e.target === overlay) overlay.remove(); };
  overlay.innerHTML = `<div class="glass-modal"><button class="gi-close" onclick="this.closest('.glass-overlay').remove()"><span class="icon-x"></span></button><div style="padding:24px;"><div style="font-size:1.1rem;font-weight:800;color:var(--text-primary);margin-bottom:16px;display:flex;align-items:center;gap:8px;"><span class="icon-activity"></span> Thống kê nhóm</div><div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px;"><div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:12px;padding:16px;text-align:center;"><div style="font-size:1.5rem;font-weight:900;color:var(--text-primary);">—</div><div style="font-size:.65rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-top:4px;">Tổng tin nhắn</div></div><div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:12px;padding:16px;text-align:center;"><div style="font-size:1.5rem;font-weight:900;color:var(--text-primary);">—</div><div style="font-size:.65rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-top:4px;">Thành viên</div></div><div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:12px;padding:16px;text-align:center;"><div style="font-size:1.5rem;font-weight:900;color:var(--text-primary);">—</div><div style="font-size:.65rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-top:4px;">Ảnh gửi</div></div><div style="background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:12px;padding:16px;text-align:center;"><div style="font-size:1.5rem;font-weight:900;color:#4caf50;">—</div><div style="font-size:.65rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:.06em;margin-top:4px;">Online</div></div></div><div style="font-size:.78rem;color:var(--text-muted);text-align:center;">Thống kê chi tiết sẽ được cập nhật sớm</div></div></div>`;
  document.body.appendChild(overlay);
}

// ── 3-DOT MENU ──
function toggle3DotMenu(btn) {
  const existing = document.querySelector('.chat-3dot-dropdown');
  if (existing) { existing.remove(); return; }
  const menu = document.createElement('div');
  menu.className = 'chat-3dot-dropdown';
  menu.innerHTML = `<button class="chat-3dot-item" onclick="showGroupInfoFromMenu();this.closest('.chat-3dot-dropdown').remove();"><span class="icon-user"></span> Thông tin nhóm</button><button class="chat-3dot-item" onclick="showGroupStats();this.closest('.chat-3dot-dropdown').remove();"><span class="icon-activity"></span> Thống kê nhóm</button>`;
  btn.parentElement.style.position = 'relative';
  btn.parentElement.appendChild(menu);
  setTimeout(() => { document.addEventListener('click', function h(e) { if (!e.target.closest('.chat-3dot-dropdown')) { menu.remove(); document.removeEventListener('click', h); } }); }, 10);
}

function showGroupInfoFromMenu() {
  const members = (window._globalOnlineUsers || []).map(m => ({
    id: m.id, username: m.username,
    avatar: m.avatar || 'assets/default-avatar.png', role: m.role || 'user'
  }));
  showGroupInfo(members);
}
